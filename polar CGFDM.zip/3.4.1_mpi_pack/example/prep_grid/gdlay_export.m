function gdlay_export(gdlay_file, num_of_interfaces, nc, ...
                      num_of_cell_per_layer, dr_is_equal_of_layer, ...
                      c2d, r2d, xx, yy)

% This function exports grid interfaces to gdlay file
%  gdlay_file: string, the file name
%  num_of_interfaces: an integer representing number of total interfaces
%  nx: number of sampling points along x-axis
%  ny: number of sampling points along y-axis
%  num_of_cell_per_layer: [1:num_of_interfaces-1] array, number of cells between each two ingerfaces
%  dz_is_equal_of_layer: [1:num_of_interfaces-1] array, either 1 or 0, indicating if the cell length is equal or smooth varying for that layer
%  x3d: [nx,ny,num_of_interfaces] array, the x-coordinates of each point of the interfaces
%  y3d: [nx,ny,num_of_interfaces] array, the y-coordinates of each point of the interfaces
%  z3d: [nx,ny,num_of_interfaces] array, the z-coordinates of each point of the interfaces

fid=fopen(gdlay_file,'w'); % Output file name 

%-- first line: how many interfaces
fprintf(fid,'%6d\n',num_of_interfaces);

%-- second line: how many cells
for ilay = 1 : num_of_interfaces - 1
  fprintf(fid,' %6d',num_of_cell_per_layer(ilay) );
end
fprintf(fid,'\n');

%-- third line: is dz equal of each layer
for ilay = 1 : num_of_interfaces - 1
  fprintf(fid,' %6d',dr_is_equal_of_layer(ilay) );
end
fprintf(fid,'\n');

%-- 4th line: nx
fprintf(fid,'%6d \n',nc);

%-- others: z of interfaces
for n = 1 : num_of_interfaces
for i = 1 : nc
    %-- seems the first layer is the deepest one
    fprintf(fid,'%12.6f %12.6f\n', ...
        c2d(i,n), r2d(i,n));
end
end

%-- last:cartesian grid xx and yy
for i = 1 : size(xx,1)
    fprintf(fid,'%12.6f %12.6f\n', ...
        xx(i,1), yy(i,1));
end

fclose(fid);

end % function
