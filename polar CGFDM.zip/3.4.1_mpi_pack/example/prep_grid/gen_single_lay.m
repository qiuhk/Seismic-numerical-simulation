%------------------------------------------------------------------------------
%-- Example of generating the interface file 
%------------------------------------------------------------------------------

clear;
clc;

%------------------------------------------------------------------------------
%-- generate x and y
%------------------------------------------------------------------------------

%-- should 6 more than FD points due to ghosts points
nghost = 3;
%pi=vpa(pi,7);
dc = 1/5/180*pi;
nc = 2*pi/dc+ 6 +1;
c0 = 0/180*pi;
c1d = [0 : nc-1] * dc + c0 - nghost * dc;

if (fix(nc)~=nc)
    error('please ensure ntheta is an integer');
end
%------------------------------------------------------------------------------
%-- generate or load topography
%------------------------------------------------------------------------------

for i=1:nc
  topo(i) = sin(2*(i-4)/180*pi) * 1000;
end

%------------------------------------------------------------------------------
%-- generate grid interfaces
%------------------------------------------------------------------------------

%-- note: from bottom to top

num_of_interfaces = 2; 

% 1 less than num_of_interfaces, total cell should be nghost more than FD points
num_of_cell_per_layer = [ 210 ];
dr_is_equal_of_layer  = [ 1 ]; % 1:The grid spacing is equal; 0: Is not.
avg_dr_of_layer       = [ 50 ];
smooth_length         = [ 40,1];

%-- suppose r of sector is a half
%-- last elem is the free surface
r_of_interfaces(num_of_interfaces) = 17200;%2*avg_dr_of_layer*num_of_cell_per_layer;%surface
r_of_interfaces(1) = (r_of_interfaces(2) ...
        - avg_dr_of_layer(1) * num_of_cell_per_layer(1));


%-- construct grid interfaces from free_topo and z_of_interfaces
c2d = zeros(nc,num_of_interfaces);
r2d = zeros(nc,num_of_interfaces);

%-- set x2d
for n = 1 : num_of_interfaces
  c2d(:,n) = c1d;
end

%- first same to free surface
r2d(:,num_of_interfaces) = r_of_interfaces(num_of_interfaces) + 0;%topo';

for ic = 1 : 1 : nc
  r2d(ic,1) = r_of_interfaces(1);  
  %r2d(ic,1) = 2*r_of_interfaces(1)/(abs(cos(c1d(ic))+sin(c1d(ic)))+abs(cos(c1d(ic))-sin(c1d(ic))));%square interface
end

%==============================================================================
%-- change c and r of 6 ghost
%==============================================================================

c2d(1,:) = c2d(nc-6,:)-2*pi;
c2d(2,:) = c2d(nc-5,:)-2*pi;
c2d(3,:) = c2d(nc-4,:)-2*pi;
r2d(1,:) = r2d(nc-6,:);
r2d(2,:) = r2d(nc-5,:);
r2d(3,:) = r2d(nc-4,:);
c2d(nc-2,:) = c2d(5,:)+2*pi;
c2d(nc-1,:) = c2d(6,:)+2*pi;
c2d(nc,:)   = c2d(7,:)+2*pi;
r2d(nc-2,:) = r2d(5,:);
r2d(nc-1,:) = r2d(6,:);
r2d(nc,:)   = r2d(7,:);

%==============================================================================
%--strcture cartesian grid
%==============================================================================
nchange = 0; %3 is enough usually
avg_dr_of_layer = avg_dr_of_layer ;%dh of cartesian
dr = 1e4;
nxy = 2 * dr/ avg_dr_of_layer +1 + 2* (nghost+nchange);%contains ghost points
xx = -( dr + (nchange+3) *avg_dr_of_layer) : avg_dr_of_layer : (dr + (nchange+3)*avg_dr_of_layer);
yy = xx;
[x,y]=meshgrid(xx,yy);

%==============================================================================
%--plot
%==============================================================================

[X,Y]=pol2cart(c2d,r2d);
hid = figure;
set(hid,'BackingStore','on');

%if you want,you can drop these 6 point when plot without impact 
% X=X(4:nc-3,:);%avoid extra 6 point
% Y=Y(4:nc-3,:);

plot(X,Y,'k-',X',Y','k-');
hold on;
plot(x,y,'k',x',y','c');
axis equal;  
xlabel(['X axis m']);
ylabel(['Z axis m']);

%==============================================================================
%-- write .gdlay file
%==============================================================================
xx = xx';
yy = yy';
gdlay_file = 'random_topo_single.gdlay';
gdlay_export(gdlay_file, ...
             num_of_interfaces, nc, ...
             num_of_cell_per_layer, ...
             dr_is_equal_of_layer, ...
             c2d, r2d, xx, yy);

