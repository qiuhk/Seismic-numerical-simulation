#!/bin/bash

#set -x
set -e

date

#-- program related dir
EXEC_WAVE=`pwd`/../main_curv_col_2d
echo "EXEC_WAVE=$EXEC_WAVE"

#-- input dir
CUR_DIR=`pwd`

#-- output and conf
PROJDIR=`pwd`/../project
PAR_FILE=${PROJDIR}/test.json
GRID_DIR=${PROJDIR}/output
MEDIA_DIR=${PROJDIR}/output
SOURCE_DIR=${PROJDIR}/output
OUTPUT_DIR=${PROJDIR}/output

RUN_SCRIPT_FILE=${PROJDIR}/runscript.lsf
echo "RUN_SCRIPT_FILE  = ${RUN_SCRIPT_FILE}"

rm -rf $PROJDIR

#-- create dir
mkdir -p $PROJDIR
mkdir -p $OUTPUT_DIR
mkdir -p $GRID_DIR
mkdir -p $MEDIA_DIR

EVTNM=circular

NPROCS=10

#----------------------------------------------------------------------
#-- create main conf
#----------------------------------------------------------------------
cat << ieof > $PAR_FILE
{
  "number_of_total_grid_points_theta" : 1801,
  "number_of_total_grid_points_rho" : 211,
  "number_of_cartesian_grid_points": 401,
  "size_of_interp": 2,
  "number_of_mpiprocs" : $NPROCS ,

  "size_of_time_step" : 0.005,
  "number_of_time_steps" :2000,
  "#time_window_length" : 4,
  "check_stability" : 1,

  "boundary_r_top" : {
      "free" : "timg"
      },

  "grid_generation_method" : {
      "#import" : "$GRID_DIR",
      "#cartesian" : {
         "origin"  : [0.0, -29900.0 ],
         "inteval" : [ 100.0, 100.0 ]
      },
      "layer_interp" : {
        "in_grid_layer_file" : "$CUR_DIR/prep_grid/random_topo_single.gdlay",
        "refine_factor" : [ 1, 1 ],
        "horizontal_start_index" : [ 3],
        "vertical_last_to_top" : 0
      }
  },
  "is_export_grid" : 1,
  "grid_export_dir"   : "$GRID_DIR",

  "metric_calculation_method" : {
      "#import" : "$GRID_DIR",
      "calculate" : 1
  },
  "is_export_metric" : 1,

  "medium" : {
      "type" : "elastic_iso",
      "#input_way" : "infile_layer",
      "#input_way" : "binfile",
      "input_way" : "code",
      "#binfile" : {
        "size"    : [1101, 1447, 1252],
        "spacing" : [-10, 10, 10],
        "origin"  : [0.0,0.0,0.0],
        "dim1" : "z",
        "dim2" : "x",
        "dim3" : "y",
        "Vp" : "$CUR_DIR/prep_medium/seam_Vp.bin",
        "Vs" : "$CUR_DIR/prep_medium/seam_Vs.bin",
        "rho" : "$CUR_DIR/prep_medium/seam_rho.bin"
      },
      "code" : "func_name_here",
      "#import" : "$MEDIA_DIR",
      "#infile_layer" : "$CUR_DIR/prep_medium/basin_el_iso.md3lay",
      "#infile_grid" : "$CUR_DIR/prep_medium/topolay_el_iso.md3grd",
      "#equivalent_medium_method" : "loc",
      "#equivalent_medium_method" : "har"
  },

  "is_export_media" : 1,
  "media_export_dir"  : "$MEDIA_DIR",

  "#visco_config" : {
      "type" : "gmb",
      "Qs_freq" : 2.0,
      "number_of_maxwell" : 3,
      "max_freq" : 10.0,
      "min_freq" : 0.1,
      "refer_freq" : 1.0
  },

  "in_source_file" : "$CUR_DIR/prep_source/test_source.src",
  "source_region": 0,
  "is_export_source" : 1,
  "source_export_dir"  : "$SOURCE_DIR",

  "output_dir" : "$OUTPUT_DIR",

  "in_station_file" : "$CUR_DIR/prep_station/station.list",

  "receiver_line" : [
    {
      "name" : "line_x_1",
      "grid_index_start"    : [  50, 40 ],
      "grid_index_incre"    : [  5,  0 ],
      "grid_index_count"    : 2
    }
  ],

  "snapshot" : [
    {
      "name" : "volume_vel",
      "grid_index_start" : [ 0,   0 ],
      "grid_index_count" : [ 1801, 211],
      "grid_index_incre" : [  1,  1 ],
      "time_index_start" : 0,
      "time_index_incre" : 1,
      "save_velocity" : 1,
      "save_stress"   : 0,
      "save_strain"   : 0
    }
  ],

  "check_nan_every_nummber_of_steps" :10,
  "output_all" : 0 
}
ieof

echo "+ created $PAR_FILE"

#-------------------------------------------------------------------------------
#-- generate run script
#-------------------------------------------------------------------------------
#
create_script_lsf()
{
cat << ieof > ${RUN_SCRIPT_FILE}
#!/bin/bash

#BSUB -J ${EVTNM}
#BSUB -q smp
#BSUB -n ${NPROCS}
#BSUB -R "span[ptile=192]"
##BSUB -e %J.err
#BSUB -o %J.out

MPI_CMD="mpirun -np ${NPROCS} ${EXEC_WAVE} ${PAR_FILE} 100"

printf "%s\n\n" "\${MPI_CMD}";

time \${MPI_CMD} 2>&1 | tee log;
if [ \$? -ne 0 ]; then
    printf "\nSimulation fail! stop!\n"
    exit 1
fi
ieof

}

#-------------------------------------------------------------------------------
#-- start run
#-------------------------------------------------------------------------------
echo "submit to lsf ..."
create_script_lsf;
bsub < ${RUN_SCRIPT_FILE}

date

# vim:ft=conf:ts=4:sw=4:nu:et:ai:
