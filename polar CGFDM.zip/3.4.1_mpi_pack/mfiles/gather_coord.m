function [x,z,xx,zz] = gather_coord(par,output_dir,subs,subc,subt)

%% read paras from parfile
 NP = par.number_of_mpiprocs;
 NC = par.number_of_total_grid_points_theta;
 NR = par.number_of_total_grid_points_rho;
 NXZ = par.number_of_cartesian_grid_points;
 
 X = zeros(NC,NR);
 Z = zeros(NC,NR);
 XX = zeros(NXZ,NXZ);
 ZZ = zeros(NXZ,NXZ);
 
%% load in loop to get whole mat
 for n = 0:NP-1
        fnm_coord= [output_dir, '/coord_NO.',num2str(n,'%d'),'.nc'];    
        if ~ exist(fnm_coord,'file')
           error([mfilename ': file ' fnm_coord 'does not exist']);
        end
        
        lxzs = nc_attget(fnm_coord,nc_global,'local_index_of_first_physical_points');%equal nghost
        gxzs = nc_attget(fnm_coord,nc_global,'global_index_of_first_physical_points');%gni1,gnk1
        gxxzzs =nc_attget(fnm_coord,nc_global,'car_global_index_of_first_physical_points');%gnii1,kk1
        lxzc = nc_attget(fnm_coord,nc_global,'count_of_physical_points_polar');%count of mpi_block_gd
        lxxzzc = nc_attget(fnm_coord,nc_global,'count_of_physical_points_car');%count of mpi_block_gd
        
        %serial for whole mat
        i1 = gxzs(1) +1;    i2 = i1 + lxzc(1) -1;
        k1 = gxzs(2) +1;    k2 = k1 + lxzc(2) -1;
        ii1 = gxxzzs(1) +1;    ii2 = ii1 + lxxzzc(1) -1;
        kk1 = gxxzzs(2) +1;    kk2 = kk1 + lxxzzc(2) -1;
        
        %mpi block mat,involve ghost layer
        x1 = squeeze(ncread(fnm_coord, 'x'));
        z1 = squeeze(ncread(fnm_coord, 'z'));
        xx1 = squeeze(ncread(fnm_coord, 'xx'));
        zz1 = squeeze(ncread(fnm_coord, 'zz'));

        X(i1:i2,k1:k2) = x1(lxzs(1)+1 : lxzs(1)+lxzc(1),lxzs(2)+1 : lxzs(2)+lxzc(2));
        Z(i1:i2,k1:k2) = z1(lxzs(1)+1 : lxzs(1)+lxzc(1),lxzs(2)+1 : lxzs(2)+lxzc(2));
        XX(ii1:ii2,kk1:kk2) = xx1(lxzs(1)+1 : lxzs(1)+lxxzzc(1),lxzs(2)+1 : lxzs(2)+lxxzzc(2));
        ZZ(ii1:ii2,kk1:kk2) = zz1(lxzs(1)+1 : lxzs(1)+lxxzzc(1),lxzs(2)+1 : lxzs(2)+lxxzzc(2));
 end

%% sample from whole x/z with subs/c
%start
 xs = subs(1) ;
 zs = subs(2) ;

%count
if(subc(1) == -1)
  xc = floor(NC/subt(1))-subs(1)+1;
else
  xc = subc(1);%if not fig all points,then plot subc.
end
if(subc(2) == -1)
  zc = floor(NR/subt(2))-subs(2)+1;
else
  zc = subc(2);
end

%terminal
xt = subt(1);
zt = subt(2);

%get selected mat

x = X (xs:xt:(xs+xt*(xc-1)),zs:zt:(zs+zt*(zc-1)));
z = Z (xs:xt:(xs+xt*(xc-1)),zs:zt:(zs+zt*(zc-1)));
xx=XX;
zz=ZZ;

end
