function [v,v_car] = gather_media(par,output_dir,varnm,subs,subc,subt)

%% read paras from parfile
 NP = par.number_of_mpiprocs;
 NC = par.number_of_total_grid_points_theta;
 NR = par.number_of_total_grid_points_rho;
 
%% load in loop to get whole mat
 for n = 0:NP-1
    fnm_media    =[output_dir, '/media_NO.',num2str(n,'%d'),'.nc'];
    fnm_media_car=[output_dir, '/media_car_NO.',num2str(n,'%d'),'.nc'];
    
    if ~ exist(fnm_media,'file')||~ exist(fnm_media_car,'file')
       error([mfilename ': file ' fnm_media 'does not exist']);
    end

    lxzs = nc_attget(fnm_media,nc_global,'local_index_of_first_physical_points');%equal nghost
    gxzs = nc_attget(fnm_media,nc_global,'global_index_of_first_physical_points');%gni1,gnk1
    lxzc = nc_attget(fnm_media,nc_global,'count_of_physical_points');%count of mpi block
    gxxzzs = nc_attget(fnm_media_car,nc_global,'global_index_of_first_physical_points');%gni1,gnk1
    lxxzzc = nc_attget(fnm_media_car,nc_global,'count_of_physical_points');

    %serial for whole mat
    i1 = gxzs(1) +1;    i2 = i1 + lxzc(1) -1;  ii1 = gxxzzs(1) +1;  ii2 = ii1 + lxxzzc(1) -1;
    k1 = gxzs(2) +1;    k2 = k1 + lxzc(2) -1;  kk1 = gxxzzs(2) +1;  kk2 = kk1 + lxxzzc(2) -1;

    %mpi block mat,involve ghost layer
    var1 = squeeze(ncread(fnm_media, varnm));
    var2 = squeeze(ncread(fnm_media_car, varnm));
    
    V(i1:i2,k1:k2) = var1(lxzs(1)+1 : lxzs(1)+lxzc(1),lxzs(2)+1 : lxzs(2)+lxzc(2));
    VV(ii1:ii2,kk1:kk2) = var2(lxzs(1)+1 : lxzs(1)+lxxzzc(1),lxzs(2)+1 : lxzs(2)+lxxzzc(2));
 end
 
 %% sample from whole mat with subs/c
%start
 xs = subs(1) ;
 zs = subs(2) ;

%count
if(subc(1) == -1)
  xc = floor(NC/subt(1))-subs(1)+1;
else
  xc = subc(1);%if not fig all points,then plot subc.
end
if(subc(2) == -1)
  zc = floor(NR/subt(2))-subs(2)+1;
else
  zc = subc(2);
end

%terminal
xt = subt(1);
zt = subt(2);

%get selected mat

v = V (xs:xt:(xs+xt*(xc-1)),zs:zt:(zs+zt*(zc-1)));
v_car = VV;

end
