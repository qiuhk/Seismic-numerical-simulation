clear all;
close all;
clc;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project/test.json';
output_dir='../project/output';

% which snapshot to plot
id=1;

% variable and time to plot
varnm='Vr';
ns=1000;
ne=2000;
nt=1000;

% which grid profile to plot
subs=[1,1];     % start from index '1'
subc=[-1,-1];   % '-1' to plot all points in this dimension
subt=[1,1];

if strcmp(varnm,'Vc')
    varnm_car='Vx';%Vx or Vz
elseif strcmp(varnm,'Vr')
    varnm_car='Vz';
else
    error('Please add vaenm of T');
end

% figure control parameters
flag_km     = 0;
flag_emlast = 1;
flag_print  = 0;
savegif = 1;
plot_all =1; %if plot 2 gd snap

scl_caxis=[-5*1e3 5*1e3];
filename1 = [varnm_car,'.gif'];
scl_daspect =[1 1 1];
clrmp       = 'jetwr';
taut=1;%pause

% read parameters file
par=loadjson(parfnm);
snap_subs=par.snapshot{1}.grid_index_start;
snap_subc=par.snapshot{1}.grid_index_count;
snap_subt=par.snapshot{1}.grid_index_incre;
snap_subs = double(snap_subs);
snap_subc = double(snap_subc);
snap_subt = double(snap_subt);

% get grid info
subs1(1) = snap_subs(1) + subs(1);
subs1(2) = snap_subs(2) + subs(2);
subt1(1) = snap_subt(1) * subt(1); %stride
subt1(2) = snap_subt(2) * subt(2);

if(subc(1) == -1)
  subc1(1) = floor(snap_subc(1)/subt(1))-subs(1)+1;
else
  subc1(1) = subc(1);
end

if(subc(2) == -1)
  subc1(2) = floor(snap_subc(2)/subt(2))-subs(2)+1;
else
  subc1(2) = subc(2);
end
%-----------------------------------------------------------
%-- load coord
%-----------------------------------------------------------
par=loadjson(parfnm);
[x,z,xx,zz]=gather_coord(par,output_dir,subs1,subc1,subt1);
x(size(x,1),:)=x(1,:);%force start and end alignment
% coordinate unit
[X,Y]=pol2cart(x,z);

str_unit='m';
if flag_km
   X=X/1e3;
   Y=Y/1e3;
   xx=xx/1e3;
   zz=zz/1e3;
   str_unit='km';
end

% figure plot
hid=figure;
set(hid,'BackingStore','on');

% snapshot show
for nlayer=ns:nt:ne
    
    [vc,~]=gather_snap(par,output_dir,nlayer,'Vc',subs,subc,subt);
    [vr,t]=gather_snap(par,output_dir,nlayer,'Vr',subs,subc,subt);

    % change to xz
    if strcmp(varnm,'Vc')
        v=cos(x).*vr - sin(x).*vc;
    end
    if strcmp(varnm,'Vr')
        v=sin(x).*vr + cos(x).*vc;
    end
    
    disp([ '  draw ' num2str(nlayer) 'th time step (t=' num2str(t) ')']);
    
    plot(X(:,size(X,2)),Y(:,size(Y,2)),'-b','linewidth',3);
    hold on;
    plot(X(:,1),Y(:,1),'-c','linewidth',3);
    hold on
    
    pcolor(X,Y,v);
    xlabel(['X axis (' str_unit ')']);
    ylabel(['Z axis (' str_unit ')']);
    
    if plot_all ==1
        vv=gather_snap_car(par,output_dir,nlayer,varnm_car);
        pcolor(xx,zz,vv);
        hold on;
    end
       
    set(gca,'layer','top');
    set(gcf,'color','white','renderer','painters');

    % axis image
    % shading
    % shading interp;
    shading flat;
    % colorbar range/scale
    if exist('scl_caxis')
        caxis(scl_caxis);
    end
    % axis daspect
    if exist('scl_daspect')
        daspect(scl_daspect);
    end
    % colormap and colorbar
    if exist('clrmp')
        colormap(clrmp);
    end
    colorbar('vert');
    
    %title
    titlestr=['Snapshot of ' varnm_car ' at ' ...
              '{\fontsize{12}{\bf ' ...
              num2str((t),'%7.3f') ...
              '}}s'];
    title(titlestr);
    
    drawnow;
    pause(taut);
    %save gif
    if savegif
      im=frame2im(getframe(gcf));
      [imind,map]=rgb2ind(im,256);
      if nlayer==ns
        imwrite(imind,map,filename1,'gif','LoopCount',Inf,'DelayTime',0.5);
      else
        imwrite(imind,map,filename1,'gif','WriteMode','append','DelayTime',0.5);
      end
    end
    
    % save and print figure
    if flag_print==1
        width= 500;
        height=500;
        set(gcf,'paperpositionmode','manual');
        set(gcf,'paperunits','points');
        set(gcf,'papersize',[width,height]);
        set(gcf,'paperposition',[0,0,width,height]);
        fnm_out=[varnm '_ndim_',num2str(nlayer,'%5.5i')];
        print(gcf,[fnm_out '.png'],'-dpng');
    end
    
end



