function v=gather_snap_car(par,output_dir,nlayer,varnm)

%% read paras from parfile
NP = par.number_of_mpiprocs;
NXZ = par.number_of_cartesian_grid_points;
v = zeros(NXZ,NXZ);
%% load in loop to get whole mat
for n = 0:NP-1
    fnm_snap=[output_dir, '/volume_vel_NO.',num2str(n,'%d'),'.nc'];

    if ~ exist(fnm_snap,'file')
       error([mfilename ': file ' fnm_snap 'does not exist']);
    end
    
    tdim=nc_getdiminfo(fnm_snap,'time');
    if tdim.Length==0 || (nlayer-1)-1>=tdim.Length
       error([num2str(nlayer) 'th layer is beyond current time dim (' ...
            num2str(tdim.Length) ') in ' fnm_snap]);
    end
    
    gxzs = nc_attget(fnm_snap,nc_global,'first_index_to_snapshot_output_car');%gni1,gnk1
    lxzc = nc_attget(fnm_snap,nc_global,'count_of_physical_points_car');%count of mpi block

    %serial for whole mat
    i1 = gxzs(1) +1;    i2 = i1 + lxzc(1) -1;
    k1 = gxzs(2) +1;    k2 = k1 + lxzc(2) -1;

    %mpi block mat,involve ghost layer
    %use nc_varget because ncread can't get 2 dimension var1
    var1 = nc_varget(fnm_snap,varnm, ...
                  [nlayer-1,0,0],[1,lxzc(2),lxzc(1)],[1,1,1]);%[1,zt,xt]
    var1 = var1';
    v(i1:i2,k1:k2) = var1;
end
