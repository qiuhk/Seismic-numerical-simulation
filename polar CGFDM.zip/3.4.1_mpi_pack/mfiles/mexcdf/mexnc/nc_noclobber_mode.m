function mode = nc_noclobber_mode()
% NC_NOCLOBBER_MODE:  returns integer mnemonic for NC_NOCLOBBER
%
% USAGE:  mode = nc_noclobber_mode;
mode = 4;
return


