function [v,t]=gather_snap(par,output_dir,nlayer,varnm,subs,subc,subt)

%% read paras from parfile
 NP = par.number_of_mpiprocs;
 
 snap_subc=par.snapshot{1}.grid_index_count;
 snap_subc = double(snap_subc);

%% load in loop to get whole mat
 for n = 0:NP-1
    fnm_snap=[output_dir, '/volume_vel_NO.',num2str(n,'%d'),'.nc'];

    if ~ exist(fnm_snap,'file')
       error([mfilename ': file ' fnm_snap 'does not exist']);
    end
    
    tdim=nc_getdiminfo(fnm_snap,'time');
    if tdim.Length==0 || (nlayer-1)-1>=tdim.Length
       error([num2str(nlayer) 'th layer is beyond current time dim (' ...
            num2str(tdim.Length) ') in ' fnm_snap]);
    end
    
    gxzs = nc_attget(fnm_snap,nc_global,'first_index_to_snapshot_output');%gni1,gnk1
    lxzc = nc_attget(fnm_snap,nc_global,'count_of_physical_points_polar');%count of mpi block

    %serial for whole mat
    i1 = gxzs(1) +1;    i2 = i1 + lxzc(1) -1;
    k1 = gxzs(2) +1;    k2 = k1 + lxzc(2) -1;

    %mpi block mat,involve ghost layer
    %use nc_varget because ncread can't get 2 dimension var1
    var1 = nc_varget(fnm_snap,varnm, ...
                  [nlayer-1,0,0],[1,lxzc(2),lxzc(1)],[1,1,1]);%[1,zt,xt]
    var1 = var1';
    V(i1:i2,k1:k2) = var1;
    t=nc_varget(fnm_snap,'time',[nlayer-1],[1]);
 end

 %% sample from whole mat with subs/c
%start
 xs = subs(1) ;
 zs = subs(2) ;

%count
if(subc(1) == -1)
  xc = floor(snap_subc(1)/subt(1))-subs(1)+1;
else
  xc = subc(1);%if not fig all points,then plot subc.
end
if(subc(2) == -1)
  zc = floor(snap_subc(2)/subt(2))-subs(2)+1;
else
  zc = subc(2);
end

%terminal
xt = subt(1);
zt = subt(2);

%get selected mat

v = V (xs:xt:(xs+xt*(xc-1)),zs:zt:(zs+zt*(zc-1)));

end
