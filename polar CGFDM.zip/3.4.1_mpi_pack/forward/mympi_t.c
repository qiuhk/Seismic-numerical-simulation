/*********************************************************************
 * mpi for this package
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "mympi_t.h"

//
// set grid size
//
int
mympi_set(mympi_t *mympi,
          int number_of_mpiprocs,
          MPI_Comm comm, 
          const int myid, const int verbose)
{
  int ierr = 0;
  //fprintf(stdout,"num of mpi is %d\n",number_of_mpiprocs);
  //fprintf(stdout,"address of myid is %p\n",&(mympi->myid));
  //fprintf(stdout,"address of nproc is %p\n",&(mympi->nproc));
  mympi->nproc = number_of_mpiprocs;

  fprintf(stdout,"num of nproc is %d\n",mympi->nproc);

  mympi->myid = myid;
  mympi->comm = comm;
  mympi->displs_polar = (int *)malloc(number_of_mpiprocs * sizeof(int));
  mympi->displs_car   = (int *)malloc(number_of_mpiprocs * sizeof(int));
  mympi->allCount_polar = (int *)malloc(number_of_mpiprocs * sizeof(int));
  mympi->allCount_car   = (int *)malloc(number_of_mpiprocs * sizeof(int));

  // mpi topo, only consider 2d topo
  int pdims[1]   = {number_of_mpiprocs};
  int periods[1] = {0};

  // create Cartesian topology
  MPI_Cart_create(comm, 1, pdims, periods, 0, &(mympi->topocomm));

  // get my local x,y coordinates
  MPI_Cart_coords(mympi->topocomm, myid, 1, mympi->topoid);

  // neighour
  MPI_Cart_shift(mympi->topocomm, 0, 1, &(mympi->neighid[0]), &(mympi->neighid[1]));//0,1 is dimension and direction

  // set y dir for bdry condition
  mympi->neighid[2] = MPI_PROC_NULL;
  mympi->neighid[3] = MPI_PROC_NULL;

  return ierr;
}
