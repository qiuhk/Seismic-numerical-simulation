/*********************************************************************
 * setup fd operators
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fdlib_mem.h"
#include "constants.h"
#include "gd_info.h"

//
// set grid size
//

int
gd_info_set(gdinfo_t *const gdinfo,
            const mympi_t *const mympi,
            const int number_of_total_grid_points_x,
            const int number_of_total_grid_points_z,
            const int number_of_cartesian_grid_points,
            const int size_of_interp,
            const int fdx_nghosts,
            const int fdz_nghosts,
            const int verbose)
{
  int ierr = 0;

  // determine ni
  int nx_et = number_of_total_grid_points_x ;

  int nx_avg  = nx_et / mympi->nproc;
  int nx_left = nx_et % mympi->nproc;

  if (nx_avg < 2 * fdx_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size less than 2*ghost\n");// error
    exit(-1);
  }

  int ni = nx_avg;

  gdinfo->gni1 = mympi->topoid[0] * nx_avg ;

  if (mympi->topoid[0] < nx_left) {
    ni++;
  }
  
  if (nx_left != 0) {
    gdinfo->gni1 += (mympi->topoid[0] < nx_left)? mympi->topoid[0] : nx_left;
  }


  // determine nk
  int nk = number_of_total_grid_points_z;
  gdinfo->gnk1 = 0;


  // determine nii
  int nx_car_et = number_of_cartesian_grid_points ;

  int nx_car_avg  = nx_car_et / mympi->nproc;
  int nx_car_left = nx_car_et % mympi->nproc;

  if (nx_car_avg < 2 * fdx_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size less than 2*ghost\n");// error
    exit(-1);
  }

  int nii = nx_car_avg;

  gdinfo->gnii1 = mympi->topoid[0] * nx_car_avg ;

  if (mympi->topoid[0] < nx_car_left) {
    nii++;
  }
  
  if (nx_car_left != 0) {
    gdinfo->gnii1 += (mympi->topoid[0] < nx_car_left)? mympi->topoid[0] : nx_car_left;
  }


  // determine nkk
  int nkk = number_of_cartesian_grid_points;
  gdinfo->gnkk1 = 0;
  
  // add ghost points for polar
  int nx = ni + 2 * fdx_nghosts;
  int nz = nk + 2 * fdz_nghosts;

  gdinfo->ni = ni;
  gdinfo->nk = nk;

  gdinfo->nx = nx;
  gdinfo->nz = nz;

  gdinfo->ni1 = fdx_nghosts;
  gdinfo->ni2 = gdinfo->ni1 + ni - 1;

  gdinfo->nk1 = fdz_nghosts;
  gdinfo->nk2 = gdinfo->nk1 + nk - 1;

  gdinfo->gni2 = gdinfo->gni1 + gdinfo->ni - 1;
  gdinfo->gnk2 = gdinfo->gnk1 + gdinfo->nk - 1;

  gdinfo->ni1_to_glob_phys0 = gdinfo->gni1;
  gdinfo->ni2_to_glob_phys0 = gdinfo->gni2;
  gdinfo->nk1_to_glob_phys0 = gdinfo->gnk1;
  gdinfo->nk2_to_glob_phys0 = gdinfo->gnk2;
  
  // add ghost points for polar
  int nxx = nii + 2 * fdx_nghosts;
  int nzz = nkk + 2 * fdx_nghosts;
  gdinfo->nii = nii;
  gdinfo->nkk = nkk;

  gdinfo->nxx = nxx;
  gdinfo->nzz = nzz; 

  gdinfo->nii1 = fdx_nghosts;
  gdinfo->nii2 = gdinfo->nii1 + nii - 1;

  gdinfo->nkk1 = fdz_nghosts;
  gdinfo->nkk2 = gdinfo->nkk1 + nkk - 1;

  gdinfo->gnii2 = gdinfo->gnii1 + gdinfo->nii - 1;
  gdinfo->gnkk2 = gdinfo->gnkk1 + gdinfo->nkk - 1;

  gdinfo->nii1_to_glob_phys0 = gdinfo->gnii1;
  gdinfo->nii2_to_glob_phys0 = gdinfo->gnii2;
  gdinfo->nkk1_to_glob_phys0 = gdinfo->gnkk1;
  gdinfo->nkk2_to_glob_phys0 = gdinfo->gnkk2;

  // x dimention varies first
  gdinfo->siz_slice  = nx; 
  gdinfo->siz_volume = nx * nz;

  // new var, will replace above old naming
  gdinfo->siz_iz   = gdinfo->siz_slice;
  gdinfo->siz_icmp = gdinfo->siz_volume;

  // set npoint_ghosts according to fdz_nghosts
  gdinfo->npoint_ghosts = fdz_nghosts;

  gdinfo->fdx_nghosts = fdx_nghosts;
  gdinfo->fdz_nghosts = fdz_nghosts;

  gdinfo->num_total_grid_x = number_of_total_grid_points_x;
  gdinfo->num_total_grid_z = number_of_total_grid_points_z;
  gdinfo->num_total_grid_car = number_of_cartesian_grid_points;
  gdinfo->size_of_interp   = size_of_interp;

  gdinfo->index_name = fdlib_mem_malloc_2l_char(
                        CONST_NDIM, CONST_MAX_STRLEN, "gdinfo name");

  // grid coord name
  sprintf(gdinfo->index_name[0],"%s","i");
  sprintf(gdinfo->index_name[1],"%s","k");

  return ierr;
}

/*
 * give a local index ref, check if in this thread
 */

int
gd_info_lindx_is_inner(int i,  int k, gdinfo_t *gdinfo)
{
  int is_in = 0;

  if (   i >= gdinfo->ni1 && i <= gdinfo->ni2
      && k >= gdinfo->nk1 && k <= gdinfo->nk2)
  {
    is_in = 1;
  }

  return is_in;
}  

int
gd_car_lindx_is_inner(int i,  int k, gdinfo_t *gdinfo)
{
  int is_in = 0;

  if (   i >= gdinfo->nii1 && i <= gdinfo->nii2
      && k >= gdinfo->nkk1 && k <= gdinfo->nkk2)
  {
    is_in = 1;
  }

  return is_in;
}  

/*
 * give a global index ref to phys0, check if in this thread
 */

int
gd_info_gindx_is_inner(int gi, int gk, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gi >= gdinfo->ni1_to_glob_phys0 && gi <= gdinfo->ni2_to_glob_phys0 &&
       gk >= gdinfo->nk1_to_glob_phys0 && gk <= gdinfo->nk2_to_glob_phys0 )
  {
    ishere = 1;
  }

  return ishere;
}

/*
 * glphyinx, glextind, gp,ge
 * lcphyind, lcextind
 * gl: global
 * lc: local
 * inx: index
 * phy: physical points only, do not count ghost
 * ext: include extended points, with ghots points
 */

int
gd_info_gindx_is_inner_i(int gi, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gi >= gdinfo->ni1_to_glob_phys0 && gi <= gdinfo->ni2_to_glob_phys0)
  {
    ishere = 1;
  }

  return ishere;
}


int
gd_info_gindx_is_inner_k(int gk, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gk >= gdinfo->nk1_to_glob_phys0 && gk <= gdinfo->nk2_to_glob_phys0)
  {
    ishere = 1;
  }

  return ishere;
}

/*
 * convert global index to local
 */

int
gd_info_ind_glphy2lcext_i(int gi, gdinfo_t *gdinfo)
{
  return gi - gdinfo->ni1_to_glob_phys0 + gdinfo->npoint_ghosts;
}



int
gd_info_ind_glphy2lcext_k(int gk, gdinfo_t *gdinfo)
{
  return gk - gdinfo->nk1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_car_ind_glphy2lcext_i(int gi, gdinfo_t *gdinfo)
{
  return gi - gdinfo->nii1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_car_ind_glphy2lcext_k(int gk, gdinfo_t *gdinfo)
{
  return gk - gdinfo->nkk1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

/*
 * convert local index to global
 */

int
gd_info_ind_lcext2glphy_i(int i, gdinfo_t *gdinfo)
{
  return i - gdinfo->npoint_ghosts + gdinfo->ni1_to_glob_phys0;
}


int
gd_info_ind_lcext2glphy_k(int k, gdinfo_t *gdinfo)
{
  return k - gdinfo->npoint_ghosts + gdinfo->nk1_to_glob_phys0;
}


