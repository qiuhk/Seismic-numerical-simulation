// todo:
//  check : abs_set_ablexp
//  convert fortrn to c: abs_ablexp_cal_damp

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#include "fdlib_math.h"
#include "fdlib_mem.h"
#include "bdry_t.h"

//- may move to par file
#define CONSPD 2.0f // power for d
#define CONSPB 2.0f // power for beta
#define CONSPA 1.0f // power for alpha

/*
 * init bdry_t
 */

int
bdry_init(bdry_t *bdry, int nx, int nz)
{
  bdry->is_enable_pml  = 0;
  bdry->is_enable_mpml = 0;
  bdry->is_enable_ablexp  = 0;
  bdry->is_enable_free = 0;

  bdry->nx = nx;
  bdry->nz = nz;

  return 0;
}

/*
 * matrix for velocity gradient conversion
 *  only implement z2 (top) right now
 */

int
bdry_free_set(gd_t    *gd,
              bdry_t      *bdryfree,
              int   in_is_sides[][2],
              int visco_type,
              const int verbose)
{
  int ierr = 0;

  size_t siz_iz  = gd->siz_iz;

  // default disable
  bdryfree->is_enable_free = 0;

  // check each side
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      int ind_1d = iside + idim * 2;

      bdryfree->is_sides_free[idim][iside] = in_is_sides[idim][iside];

      // enable if any side valid
      if (bdryfree->is_sides_free  [idim][iside] == 1) {
        bdryfree->is_enable_free = 1;
      }
    } // iside
  } // idim

  float *vecVx2Vz1= NULL;
  float *vecVx2Vz2= NULL;
  float *vecA = NULL;
  if (bdryfree->is_enable_free == 1)
  {
    // following only implement z2 (top) right now
    vecVx2Vz1 = (float *)fdlib_mem_calloc_1d_float(
                                        siz_iz * CONST_NDIM * CONST_NDIM,
                                        0.0,
                                        "bdry_free_set");
    vecVx2Vz2 = (float *)fdlib_mem_calloc_1d_float(
                                        siz_iz * CONST_NDIM * CONST_NDIM,
                                        0.0,
                                        "bdry_free_set");                                        
    // vecA is malloc for vis
    if (visco_type == CONST_VISCO_GMB)
    {
      vecA = (float *)fdlib_mem_calloc_1d_float(
                                       siz_iz * CONST_NDIM * CONST_NDIM,
                                       0.0,
                                       "bdry_free_set");
    }
  }
  bdryfree->vecA = vecA;
  bdryfree->vecVx2Vz1 = vecVx2Vz1;
  bdryfree->vecVx2Vz2 = vecVx2Vz2;


  return ierr;
}


int
bdry_pml_set(gdinfo_t *gdinfo,
             gd_t     *gd,
             wav_t    *wav,
             bdry_t   *bdrypml,
             int   in_is_sides[][2],
             int   in_num_layers[][2],
             float in_alpha_max[][2], //
             float in_beta_max[][2], //
             float in_velocity[][2], //
             int verbose)//par->cfspml_is_sides,abs_num_of_layers
{
  int    ni1 = gdinfo->ni1;
  int    ni2 = gdinfo->ni2;
  int    nk1 = gdinfo->nk1;
  int    nk2 = gdinfo->nk2;
  int    nx  = gd->nx ;
  int    nz  = gd->nz ;
  int    siz_iz = gd->siz_iz;

  // default disable
  bdrypml->is_enable_pml = 0;

  // check each side
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      int ind_1d = iside + idim * 2;//ind_1d no use

      // default set to input
      bdrypml->is_sides_pml [idim][iside] = in_is_sides[idim][iside];
      bdrypml->num_of_layers[idim][iside] = in_num_layers[idim][iside];

      // default loop index
      bdrypml->ni1[idim][iside] = ni1;
      bdrypml->ni2[idim][iside] = ni2;
      bdrypml->nk1[idim][iside] = nk1;
      bdrypml->nk2[idim][iside] = nk2;

      // shrink to actual size
      if (idim == 0 && iside ==0) { // x1
        bdrypml->ni2[idim][iside] = ni1 + bdrypml->num_of_layers[idim][iside];
      }
      if (idim == 0 && iside ==1) { // x2
        bdrypml->ni1[idim][iside] = ni2 - bdrypml->num_of_layers[idim][iside];
      }
      if (idim == 1 && iside ==0) { // z1
        bdrypml->nk2[idim][iside] = nk1 + bdrypml->num_of_layers[idim][iside];
      }
      if (idim == 1 && iside ==1) { // z2
        bdrypml->nk1[idim][iside] = nk2 - bdrypml->num_of_layers[idim][iside];//for free surface,nk1=nk2
      }

      // ensure at least one bdry match pml
      if (bdrypml->is_sides_pml  [idim][iside] == 1) {
        bdrypml->is_enable_pml = 1;
      }

    } // iside
  } // idim

  // alloc coef
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      if (bdrypml->is_sides_pml[idim][iside] == 1) {//for pml bdry
        int npoints = bdrypml->num_of_layers[idim][iside] + 1;
        bdrypml->A[idim][iside] = (float *)malloc( npoints * sizeof(float));
        bdrypml->B[idim][iside] = (float *)malloc( npoints * sizeof(float));
        bdrypml->D[idim][iside] = (float *)malloc( npoints * sizeof(float));
      } else {
        bdrypml->A[idim][iside] = NULL;
        bdrypml->B[idim][iside] = NULL;
        bdrypml->D[idim][iside] = NULL;
      }
    }
  }

  // cal coef for free surface
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      // skip if not pml
      if (bdrypml->is_sides_pml[idim][iside] == 0) continue;

      float *A = bdrypml->A[idim][iside];
      float *B = bdrypml->B[idim][iside];
      float *D = bdrypml->D[idim][iside];

      // esti L0 and dh,only for free surface 
      float L0, dh;
      bdry_cal_abl_len_dh(gd,bdrypml->ni1[idim][iside],
                             bdrypml->ni2[idim][iside],
                             bdrypml->nk1[idim][iside],
                             bdrypml->nk2[idim][iside],
                             idim,
                             &L0, &dh);//idim=1

      // para
      int npoints = bdrypml->num_of_layers[idim][iside] + 1;
      float num_lay = npoints - 1;
      float Rpp  = bdry_pml_cal_R(num_lay);
      float dmax = bdry_pml_cal_dmax(L0, in_velocity[idim][iside], Rpp);
      float amax = in_alpha_max[idim][iside];
      float bmax = in_beta_max[idim][iside];

      // from PML-interior to outer side
      for (int n=0; n<npoints; n++)
      {
        // first point has non-zero value
        float L = n * dh;
        int i;

        // convert to grid index from left to right
        if (iside == 0) { // x1/y1/z1
          i = npoints - 1 - n;
        } else { // x2/y2/z2.yes
          i = n; 
        }

        D[i] = bdry_pml_cal_d( L, L0, dmax );
        A[i] = bdry_pml_cal_a( L, L0, amax );
        B[i] = bdry_pml_cal_b( L, L0, bmax );

        // convert d_x to d_x/beta_x since only d_x/beta_x needed
        D[i] /= B[i];
        // covert ax = a_x + d_x/beta_x 
        A[i] += D[i];
        // covert bx = 1.0/bx 
        B[i] = 1.0 / B[i];
      }

    } // iside
  } // idim

  // alloc auxvar
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      int nx = (bdrypml->ni2[idim][iside] - bdrypml->ni1[idim][iside] + 1);
      int nz = (bdrypml->nk2[idim][iside] - bdrypml->nk1[idim][iside] + 1);

      bdry_pml_auxvar_init(nx,nz,wav,
                           &(bdrypml->auxvar[idim][iside]),verbose);
    } // iside
  } // idim

  return 0;
}

/*
 * set up abs_coefs for cfs-pml
 */

float
bdry_pml_cal_R(float num_lay)
{
  // use corrected Rpp
  return (float) (pow(10, -( (log10((double)num_lay)-1.0)/log10(2.0) + 4.0)));
}

float
bdry_pml_cal_dmax(float L, float Vp, float Rpp)
{
  return (float) (-Vp / (2.0 * L) * log(Rpp) * (CONSPD + 1.0));
}

float
bdry_pml_cal_amax(float fc)
{return PI*fc;}

float
bdry_pml_cal_d(float x, float L, float dmax)
{
  return (x<0) ? 0.0f : (float) (dmax * pow(x/L, CONSPD));
}

float
bdry_pml_cal_a(float x, float L, float amax)
{
  return (x<0) ? 0.0f : (float) (amax * (1.0 - pow(x/L, CONSPA)));
}

float
bdry_pml_cal_b(float x, float L, float bmax)
{
  return (x<0) ? 1.0f : (float) (1.0 + (bmax-1.0) * pow(x/L, CONSPB));
}

// alloc auxvar for 4 region
int
bdry_pml_auxvar_init(int nx, int nz, 
                     wav_t *wav,
                     bdrypml_auxvar_t *auxvar,
                     const int verbose)
{
  auxvar->nx   = nx;
  auxvar->nz   = nz;
  auxvar->ncmp = wav->ncmp;
  auxvar->nlevel = wav->nlevel;

  auxvar->siz_iz   = auxvar->nx;
  auxvar->siz_icmp = auxvar->nx * auxvar->nz;
  auxvar->siz_ilevel = auxvar->siz_icmp * auxvar->ncmp;

  auxvar->Vx_pos  = wav->Vx_seq  * auxvar->siz_icmp;
  auxvar->Vz_pos  = wav->Vz_seq  * auxvar->siz_icmp;
  auxvar->Txx_pos = wav->Txx_seq * auxvar->siz_icmp;
  auxvar->Tzz_pos = wav->Tzz_seq * auxvar->siz_icmp;
  auxvar->Txz_pos = wav->Txz_seq * auxvar->siz_icmp;

  // vars
  // contain all vars at each side, include rk scheme 4 levels vars
  if (auxvar->siz_icmp> 0 ) { // valid pml layer
    auxvar->var = (float *) fdlib_mem_calloc_1d_float( 
                 auxvar->siz_ilevel * auxvar->nlevel,
                 0.0, "bdry_pml_auxvar_init");
  } else { // nx,ny,nz has 0
    auxvar->var = NULL;
  }

  return 0;
}

/*
 * esti L and dh along idim damping layers
 */

int
bdry_cal_abl_len_dh(gd_t *gd, 
                    int abs_ni1, int abs_ni2,
                    int abs_nk1, int abs_nk2,
                    int idim,
                    float *avg_L, float *avg_dh)//for each region of 4
{
  int ierr = 0;

  int siz_iz = gd->siz_iz;

  // cartesian grid is simple
  if (gd->type == GD_TYPE_CART)//must not,because type is defined as curv in gd_t.c
  {
    if (idim == 0) { // x-axis
      *avg_dh = gd->dx;
      *avg_L  = gd->dx * (abs_ni2 - abs_ni1);
    } else if (idim == 1) { // z-axis
      *avg_dh = gd->dz;
      *avg_L  = gd->dz * (abs_nk2 - abs_nk1);
    }
  }
  // curv grid needs avg
  else if (gd->type == GD_TYPE_CURV)
  {
    float *x2d = gd->x2d;
    float *z2d = gd->z2d;

    double L  = 0.0;
    double dh = 0.0;
    int    num = 0;

    if (idim == 0) // x-axis,no
    {
      for (int k=abs_nk1; k<=abs_nk2; k++)
      {
        int iptr = abs_ni1 + k * siz_iz;
        double x0 = x2d[iptr];
        double z0 = z2d[iptr];
        for (int i=abs_ni1+1; i<=abs_ni2; i++)
        {
          int iptr = i + k * siz_iz;

          double x1 = x2d[iptr];
          double z1 = z2d[iptr];

          L += sqrt( (x1-x0)*(x1-x0) + (z1-z0)*(z1-z0) );//get sum of distance between each two point of every line

          x0 = x1;
          z0 = z1;
          num += 1;
        }
      }

      *avg_dh = (float)( L / num );//average dh
      *avg_L = (*avg_dh) * (abs_ni2 - abs_ni1);//average length of each line
    } 
    else // z-axis
    { 
      for (int i=abs_ni1; i<=abs_ni2; i++)
      {
        int iptr = i + abs_nk1 * siz_iz;
        double x0 = x2d[iptr];
        double z0 = z2d[iptr];
        for (int k=abs_nk1+1; k<=abs_nk2; k++)
        {
          int iptr = i + k * siz_iz;

          double x1 = x2d[iptr];
          double z1 = z2d[iptr];

          L += sqrt( (x1-x0)*(x1-x0) + (z1-z0)*(z1-z0) );

          x0 = x1;
          z0 = z1;
          num += 1;
        }
      }

      *avg_dh = (float)( L / num );
      *avg_L = (*avg_dh) * (abs_nk2 - abs_nk1);
    } // idim

  } // gd type

  return ierr;
}

/*
 * setup ablexp parameters
 */

int
bdry_ablexp_set(gdinfo_t *gdinfo,
                gd_t *gd,
                wav_t *wav,
                bdry_t *bdryexp,
                int   in_is_sides[][2],
                int   in_num_layers[][2],
                float in_velocity[][2], //
                float dt,
                int verbose)
{
  int    ierr = 0;

  int    ni1 = gdinfo->ni1;
  int    ni2 = gdinfo->ni2;
  int    nk1 = gdinfo->nk1;
  int    nk2 = gdinfo->nk2;
  int    ni  = gdinfo->ni ;
  int    nk  = gdinfo->nk ;
  int    nx  = gd->nx ;
  int    nz  = gd->nz ;
  int    siz_iz = gd->siz_iz;
  int    abs_number[CONST_NDIM][2];

  int n;

  // default disable
  bdryexp->is_enable_ablexp = 0;

  // check each side
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      int ind_1d = iside + idim * 2;

      // default set to input
      bdryexp->is_sides_ablexp  [idim][iside] = in_is_sides[idim][iside];
      bdryexp->num_of_layers[idim][iside] = in_num_layers[idim][iside];

      // enable if any side valid
      if (bdryexp->is_sides_ablexp  [idim][iside] == 1) {
        bdryexp->is_enable_ablexp = 1;
      }
    } // iside
  } // idim

  // block index for ablexp, default inactive
  bdry_block_t *D = bdryexp->bdry_blk;
  for (n=0; n < CONST_NDIM_2; n++)
  {
     D[n].enable = 0;
     D[n].ni1 =  0;
     D[n].ni2 = -1;
     D[n].ni  =  0;

     D[n].nk1 =  0;
     D[n].nk2 = -1;
     D[n].nk  =  0;
  }

  // alloc coef
  bdryexp->ablexp_Ex = (float *)malloc( nx * sizeof(float));
  bdryexp->ablexp_Ez = (float *)malloc( nz * sizeof(float));
  for (int i=0; i<nx; i++) bdryexp->ablexp_Ex[i] = 1.0;
  for (int k=0; k<nz; k++) bdryexp->ablexp_Ez[k] = 1.0;

  // x1
  n=0;
  D[n].ni=bdryexp->num_of_layers[0][0]; D[n].ni1=ni1; D[n].ni2=D[n].ni1+D[n].ni-1; 
  D[n].nk=nk                       ; D[n].nk1=nk1; D[n].nk2=D[n].nk1+D[n].nk-1; 
  if (D[n].ni>0 && D[n].nk>0)
  {
     D[n].enable = 1;

     // esti L0 and dh
     float L0, dh;
     bdry_cal_abl_len_dh(gd,D[n].ni1,
                            D[n].ni2,
                            D[n].nk1,
                            D[n].nk2,
                            0,
                            &L0, &dh);

     for (int i=D[n].ni1; i<=D[n].ni2; i++)
     {
        // the first point of layer is the first dh damping
        bdryexp->ablexp_Ex[i] = bdry_ablexp_cal_mask(D[n].ni - (i - D[n].ni1),
                                                     in_velocity[0][0], dt,
                                                     D[n].ni, dh);
     }
  }

  // x2
  n += 1;
  D[n].ni=bdryexp->num_of_layers[0][1];D[n].ni1=ni2 - D[n].ni + 1; D[n].ni2=D[n].ni1+D[n].ni-1; 
  D[n].nk=nk                       ;D[n].nk1=nk1               ; D[n].nk2=D[n].nk1+D[n].nk-1; 
  if (D[n].ni>0 && D[n].nk>0)
  {
     D[n].enable = 1;

     // esti L0 and dh
     float L0, dh;
     bdry_cal_abl_len_dh(gd,D[n].ni1,
                            D[n].ni2,
                            D[n].nk1,
                            D[n].nk2,
                            0,
                            &L0, &dh);

     for (int i=D[n].ni1; i<=D[n].ni2; i++)
     {
        bdryexp->ablexp_Ex[i] = bdry_ablexp_cal_mask(i - D[n].ni1 + 1,
                                                     in_velocity[0][1], dt,
                                                     D[n].ni, dh);
     }
  }

  int ni_x = bdryexp->num_of_layers[0][0] + bdryexp->num_of_layers[0][1];

  // z1
  n += 1;
  D[n].ni = ni - ni_x;
  D[n].ni1= ni1 + bdryexp->num_of_layers[0][0];
  D[n].ni2= D[n].ni1 + D[n].ni - 1; 
  D[n].nk = bdryexp->num_of_layers[1][0];
  D[n].nk1= nk1;
  D[n].nk2= D[n].nk1 + D[n].nk - 1; 
  if (D[n].ni>0 && D[n].nk>0)
  {
     D[n].enable = 1;
     // esti L0 and dh
     float L0, dh;
     bdry_cal_abl_len_dh(gd,D[n].ni1,
                            D[n].ni2,
                            D[n].nk1,
                            D[n].nk2,
                            1,
                            &L0, &dh);

     for (int k=D[n].nk1; k<=D[n].nk2; k++)
     {
        bdryexp->ablexp_Ez[k] = bdry_ablexp_cal_mask(D[n].nk - (k - D[n].nk1),
                                                     in_velocity[1][0], dt,
                                                     D[n].nk, dh);
     }
  }

  // z2
  n += 1;
  D[n].ni = ni - ni_x;
  D[n].ni1= ni1 + bdryexp->num_of_layers[0][0];
  D[n].ni2= D[n].ni1 + D[n].ni - 1; 
  D[n].nk = bdryexp->num_of_layers[1][1];
  D[n].nk1= nk2 - D[n].nk + 1;
  D[n].nk2= D[n].nk1 + D[n].nk - 1; 
  if (D[n].ni>0 && D[n].nk>0)
  {
     D[n].enable = 1;
     // esti L0 and dh
     float L0, dh;
     bdry_cal_abl_len_dh(gd,D[n].ni1,
                            D[n].ni2,
                            D[n].nk1,
                            D[n].nk2,
                            1,
                            &L0, &dh);

     for (int k=D[n].nk1; k<=D[n].nk2; k++)
     {
        bdryexp->ablexp_Ez[k] = bdry_ablexp_cal_mask(k - D[n].nk1 + 1,
                                                     in_velocity[1][1], dt,
                                                     D[n].nk, dh);
     }
  }

  return ierr;
}

float
bdry_ablexp_cal_mask(int i, float vel, float dt, int num_lay, float dh)
{
  float len = num_lay * dh;

  int num_step  = (int) (len / vel / dt);

  float total_damp=0.0;
  for (int n=0; n<num_step; n++) {
     total_damp += powf((n*dt*vel)/len, 2.0);
  }

  float alpha = 0.6 / total_damp;

  float mask_val = expf( -alpha * powf((float)i/num_lay, 2.0 ) );

  return mask_val;
}

int
bdry_ablexp_apply(bdry_t *bdry, float *w_end, int ncmp, size_t siz_icmp)
{
  float *Ex = bdry->ablexp_Ex;
  float *Ez = bdry->ablexp_Ez;

  int nx = bdry->nx;
  int nz = bdry->nz;

  size_t siz_iz = nx;
  size_t iptr;
  float mask;

  bdry_block_t *D = bdry->bdry_blk;
  
  for (int ivar=0; ivar<ncmp; ivar++)
  {
    float *W = w_end + ivar * siz_icmp;

    for (int n=0; n < CONST_NDIM_2; n++)
    {
      if (D[n].enable == 1)
      {
        for (int k = D[n].nk1; k <= D[n].nk2; k++)
        {
            for (int i = D[n].ni1; i <= D[n].ni2; i++)
            {
              iptr = k * siz_iz + i;
              mask = (Ex[i]<Ez[k]) ? Ex[i] : Ez[k];

              W[iptr] *= mask;
            }

          }
        }
      }
    }

  return 0;
}
