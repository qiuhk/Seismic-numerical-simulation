#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "fdlib_mem.h"
#include "fdlib_math.h"

#include "fd_t.h"
#include "gd_t.h"
#include "md_t.h"
#include "wav_t.h"
#include "src_t.h"
#include "bdry_t.h"
/*
 * implement traction image boundary 
 */

int
sv_curv_col_el_rhs_timg_z2(
                    float *restrict  Txx, float *restrict  Tzz,
                    float *restrict  Txz, 
                    float *restrict hVx , float *restrict hVz ,
                    float *restrict xi_x, float *restrict xi_z,
                    float *restrict zt_x, float *restrict zt_z,
                    float *restrict jac3d, float *restrict z2d,float *restrict slw3d,
                    int ni1, int ni2, int nk1, int nk2,
                    size_t siz_iz, 
                    int fdx_len, int *restrict fdx_indx, float *restrict fdx_coef,
                    int fdz_len, int *restrict fdz_indx, float *restrict fdz_coef,
                    fd_op_t *fdz_op, int fdz_max_len,
                    const int verbose)//new,new
{
  // use local stack array for speedup
  float  lfdx_coef [fdx_len];
  int lfdx_shift[fdx_len];
  float  lfdz_coef [fdz_len];
  int lfdz_shift[fdz_len];

  float  jzfdz_coef [fdz_max_len];//used for compact differ
  int    jzfdz_shift[fdz_max_len];

  // put fd op into local array
  for (int i=0; i < fdx_len; i++) {
    lfdx_coef [i] = fdx_coef[i];
    lfdx_shift[i] = fdx_indx[i];
  }
  for (int k=0; k < fdz_len; k++) {
    lfdz_coef [k] = fdz_coef[k];
    lfdz_shift[k] = fdz_indx[k] * siz_iz;
  }

  // loop var for fd
  int n_fd; // only used for fd loop

  float DcTz,DrTz;//nk2 eta differ
  float xix,xiz,ztx,ztz,z2d_point;
  float *restrict Txx_ptr;
  float *restrict Txz_ptr;
  float *restrict Tzz_ptr;
  float DxTxx,DxTxz,DxTzz;
  float DzTxx,DzTxz,DzTzz;
  // n for loop of 5 ; iptr4vec for near points
  int n, iptr4vec;
  float jac,slw;

  // first layer that near bdry
  int k_min = nk2 - fdz_indx[fdz_len-1];
  // point unusual fd
  for (size_t k=k_min +1 ; k <= nk2; k++)
  {
    
   if (k==nk2)//nk2 need image
    {

      int n_free =  - fdz_indx[0]; // nk2 in fd indx
      float vecTc[fdz_len];
      float vecTr[fdz_len];
      float vecABS[fdz_len];
      float tmpc[fdz_len];
      float tmpr[fdz_len];

      size_t iptr_k = k * siz_iz;
      size_t iptr = iptr_k + ni1;

      for (size_t i=ni1; i<=ni2; i++)//each column
        {
          // metric
            xix = xi_x[iptr];
            xiz = xi_z[iptr];
            ztx = zt_x[iptr];
            ztz = zt_z[iptr];
            z2d_point = z2d [iptr];

            jac = jac3d[iptr];
            slw = slw3d[iptr];

            //under surface
            for (n=0; n<n_free; n++) {
              iptr4vec = iptr + fdz_indx[n] * siz_iz;//nk2-1 layer

              vecTc[n] =  zt_z[iptr4vec] * Txz[iptr4vec]
                        + zt_x[iptr4vec] * Txx[iptr4vec] /z2d[iptr4vec];
              vecTr[n] =  zt_z[iptr4vec] * Tzz[iptr4vec]
                        + zt_x[iptr4vec] * Txz[iptr4vec] /z2d[iptr4vec];  
            vecABS[n]  =  sqrt(zt_z[iptr4vec]*zt_z[iptr4vec] + zt_x[iptr4vec]/z2d[iptr4vec] *zt_x[iptr4vec]/z2d[iptr4vec] );                    
            }


            vecTc[n_free] =0;
            vecTr[n_free] =0;
            vecABS[n_free]  =sqrt(ztz*ztz + ztx/z2d_point *ztx/z2d_point );

            //image layer
            for (n=n_free+1; n<fdz_len; n++)
            {
              int n_img = fdz_indx[n] - 2*(n-n_free);
              int iptrout =iptr + fdz_indx[n] * siz_iz; //used for cal vecABS only

              iptr4vec = iptr + n_img * siz_iz; 
              vecTc[n] =  -zt_z[iptr4vec] * Txz[iptr4vec]
                        - zt_x[iptr4vec] * Txx[iptr4vec] /z2d[iptr4vec];
              vecTr[n] =  -zt_z[iptr4vec] * Tzz[iptr4vec]
                        - zt_x[iptr4vec] * Txz[iptr4vec] /z2d[iptr4vec];  
            vecABS[n]  =  sqrt(zt_z[iptrout]*zt_z[iptrout] + zt_x[iptrout]/z2d[iptrout] *zt_x[iptrout]/z2d[iptrout] );
            }
            
            //cal vecTc/vecABS
            for (int i=0; i < fdz_len; i++) {
               tmpc[i] = vecTc[i]/vecABS[i];
               tmpr[i] = vecTr[i]/vecABS[i];
            }
            M_FD_NOINDX(DcTz, tmpc , fdz_len, lfdz_coef, n_fd);
            M_FD_NOINDX(DrTz, tmpr , fdz_len, lfdz_coef, n_fd);

            Txx_ptr = Txx + iptr;
            Tzz_ptr = Tzz + iptr;
            Txz_ptr = Txz + iptr;
            
            M_FD_SHIFT_PTR_MACDRP(DxTxx, Txx_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTzz, Tzz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTxz, Txz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            
            float absT =sqrt(ztz*ztz + ztx/z2d_point *ztx/z2d_point );
            hVx[iptr] = slw*( xiz*DxTxz +(2**Txz_ptr + xix*DxTxx)/z2d_point 
                              - ztx*xix/z2d_point/z2d_point*jac**Txx_ptr + absT*DcTz
                              + ztx*ztx*xix/z2d_point/z2d_point/z2d_point/absT/absT*jac*(ztz**Txz_ptr + ztx**Txx_ptr/z2d_point));
            hVz[iptr] = slw*( xiz*DxTzz +(*Tzz_ptr + xix*DxTxz - *Txx_ptr)/z2d_point
                              - ztx*xix/z2d_point/z2d_point*jac**Txz_ptr + absT*DrTz
                              + ztx*ztx*xix/z2d_point/z2d_point/z2d_point/absT/absT*jac*(ztz**Tzz_ptr + ztx**Txz_ptr/z2d_point));
            // next
            iptr += 1;           
        }
    }//end k==nk2
   else
    {
      n = nk2 - k;//indx of layer under surface , to get fd sheme

      int  lfdz_len  = fdz_op[n].total_len;//len is 2 or 3
      // point to indx/coef for this point
      int   *p_fdz_indx  = fdz_op[n].indx;
      float *p_fdz_coef  = fdz_op[n].coef;
      for (n_fd = 0; n_fd < lfdz_len ; n_fd++) {
        jzfdz_shift[n_fd] = p_fdz_indx[n_fd] * siz_iz;
        jzfdz_coef[n_fd]  = p_fdz_coef[n_fd];
      }

      size_t iptr_k = k * siz_iz;
      size_t iptr = iptr_k + ni1;

      for (size_t i=ni1; i<=ni2; i++)//each column
        {
          // metric
            xix = xi_x[iptr];
            xiz = xi_z[iptr];
            ztx = zt_x[iptr];
            ztz = zt_z[iptr];
            z2d_point = z2d [iptr];

            slw = slw3d[iptr];

            M_FD_SHIFT(DxTxx, Txx, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT(DxTzz, Tzz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT(DxTxz, Txz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT(DzTxx, Txx, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
            M_FD_SHIFT(DzTzz, Tzz, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
            M_FD_SHIFT(DzTxz, Txz, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);

            hVx[iptr] = slw*( xiz*DxTxz + ztz*DzTxz  
                            +(2*Txz[iptr] + xix*DxTxx + ztx*DzTxx)/z2d_point );
            hVz[iptr] = slw*( xiz*DxTzz + ztz*DzTzz  
                            +(Tzz[iptr] + xix*DxTxz + ztx*DzTxz - Txx[iptr])/z2d_point );
      
            iptr += 1;
        }
    }
   

  }
  return 0;
}



/*******************************************************************************
 * add source terms
 ******************************************************************************/

int
sv_curv_col_el_rhs_src(
            float *restrict hVx , float *restrict hVz ,
            float *restrict hTxx, float *restrict hTzz,
            float *restrict hTxz, 
            float *restrict jac3d, float *restrict slw3d,float *restrict z2d,float dxz,
            src_t *src, // short nation for reference member
            const int verbose)
{
  int ierr = 0;

  // local var
  int si,sk, iptr;

  // for easy coding and efficiency
  int max_ext = src->max_ext;

  // get fi / mij
  float fx, fz;
  float Mxx,Mzz,Mxz;

  int it     = src->it;
  int istage = src->istage;//it/istage is value of main program

  // add src; is is a commont iterater var
  for (int is=0; is < src->total_number; is++)
  {
    int   it_start = src->it_begin[is];
    int   it_end   = src->it_end  [is];

    if (it >= it_start && it <= it_end)
    {
      int   *ptr_ext_indx = src->ext_indx + is * max_ext;
      float *ptr_ext_coef = src->ext_coef + is * max_ext;
      int it_to_it_start = it - it_start;
      int iptr_cur_stage =   is * src->max_nt * src->max_stage // skip other src
                           + it_to_it_start * src->max_stage // skip other time step
                           + istage;//iptr_cur_stage is  stage indx of F/M 
      if (src->force_actived == 1) {
        fx  = src->Fx [iptr_cur_stage];
        fz  = src->Fz [iptr_cur_stage];
      }
      if (src->moment_actived == 1) {
        Mxx = src->Mxx[iptr_cur_stage];
        Mzz = src->Mzz[iptr_cur_stage];
        Mxz = src->Mxz[iptr_cur_stage];
      }
      
      // for extend points
      for (int i_ext=0; i_ext < src->ext_num[is]; i_ext++)
      {
        int   iptr = ptr_ext_indx[i_ext];
        float coef = ptr_ext_coef[i_ext];
        //fprintf(stdout,"-----> src_iptr=%d,src_ceof=%g\n",iptr,coef);
        if (src->source_region == 0) //polar region
        {
          if (src->force_actived == 1) {
            float V = coef * slw3d[iptr] / jac3d[iptr]/z2d[iptr];
            hVx[iptr] += fx * V;
            hVz[iptr] += fz * V;
          }

          if (src->moment_actived == 1) {
            float rjac = coef / jac3d[iptr] /z2d[iptr];
            hTxx[iptr] -= Mxx * rjac;
            hTzz[iptr] -= Mzz * rjac;
            hTxz[iptr] -= Mxz * rjac;
          }
        }
        else if(src->source_region == 1) //src in cartesian region
        {
          if (src->force_actived == 1) {
            float V = coef * slw3d[iptr] / dxz / dxz;
            hVx[iptr] += fx * V;
            hVz[iptr] += fz * V;
          }

          if (src->moment_actived == 1) {
            float rjac = coef  / dxz / dxz;
            hTxx[iptr] -= Mxx * rjac;
            hTzz[iptr] -= Mzz * rjac;
            hTxz[iptr] -= Mxz * rjac;
          }
        }
      } // i_ext

    } // it
  } // is

  return ierr;
}

int
sv_curv_graves_Qs(float *w, int ncmp, float dt, gdinfo_t *gdinfo, md_t *md)
{
  int ierr = 0;

  float coef = - PI * md->visco_Qs_freq * dt;

  for (int icmp=0; icmp<ncmp; icmp++)
  {
    float *restrict var = w + icmp * (gdinfo->siz_icmp + gdinfo->nxx * gdinfo->nzz);

    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
        for (int i = gdinfo->ni1; i <= gdinfo->ni2; i++)
        {
          size_t iptr = i + k * gdinfo->siz_iz;

          float Qatt = expf( coef / md->Qs[iptr] );

          var[iptr] *= Qatt;
        }
    }

    for (int k = gdinfo->nkk1; k <= gdinfo->nkk2; k++)
    {
        for (int i = gdinfo->nii1; i <= gdinfo->nii2; i++)
        {
          size_t iptr = i + k * gdinfo->nxx + gdinfo->nx * gdinfo->nz;

          float Qatt = expf( coef / md->Qs[iptr] );

          var[iptr] *= Qatt;
        }
    }
  }

  return ierr;
}
