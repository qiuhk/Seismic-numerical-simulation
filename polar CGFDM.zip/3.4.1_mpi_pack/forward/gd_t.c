/*
********************************************************************************
* Curve grid metric calculation using MacCormack scheme                        *
********************************************************************************
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "netcdf.h"

#include "fdlib_mem.h"
#include "fdlib_math.h"
#include "fd_t.h"
#include "gd_t.h"

// used in read grid file
#define M_gd_INDEX( i, k, ni ) ( ( i ) + ( k ) * ( ni ) )

void 
gd_curv_init(gdinfo_t *gdinfo,gd_t *gdcurv)
{
  /*
   * 0-2: x2d, z2d
   */

  gdcurv->type = GD_TYPE_CURV;
  
  gdcurv->nx   = gdinfo->nx;
  gdcurv->nz   = gdinfo->nz;
  gdcurv->nxx   = gdinfo->nxx;
  gdcurv->nzz   = gdinfo->nzz;
  gdcurv->ncmp = CONST_NDIM;
  gdcurv->size_of_interp = gdinfo->size_of_interp;
  
  gdcurv->fdx_nghosts = gdinfo->fdx_nghosts;
  gdcurv->fdz_nghosts = gdinfo->fdz_nghosts;
  gdcurv->npoint_ghosts = gdinfo->npoint_ghosts;

  gdcurv->siz_iz   = gdcurv->nx;
  gdcurv->siz_icmp = gdcurv->nx * gdcurv->nz;
  
  // vars
  gdcurv->v3d = (float *) fdlib_mem_calloc_1d_float(
                  (gdcurv->siz_icmp + gdcurv->nxx *gdcurv->nzz) * gdcurv->ncmp, 0.0, "gd_curv_init");
  if (gdcurv->v3d == NULL) {
      fprintf(stderr,"Error: failed to alloc coord vars\n");
      fflush(stderr);
  }
  
  // position of each v3d
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(gdcurv->ncmp*2,
                                                         0,
                                                         "gd_curv_init");
  
  // name of each v3d
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(gdcurv->ncmp*2,
                                                       CONST_MAX_STRLEN,
                                                       "gd_curv_init");
  
  // set value
  int icmp = 0;
  cmp_pos[icmp] = icmp * gdcurv->siz_icmp;
  sprintf(cmp_name[icmp],"%s","x");
  gdcurv->x2d = gdcurv->v3d + cmp_pos[icmp];

  icmp += 1;
  cmp_pos[icmp] = icmp * gdcurv->siz_icmp;
  sprintf(cmp_name[icmp],"%s","z");
  gdcurv->z2d = gdcurv->v3d + cmp_pos[icmp];

  icmp += 1;
  cmp_pos[icmp] = icmp * gdcurv->siz_icmp + gdcurv->nxx *gdcurv->nzz * (icmp-2) ;
  sprintf(cmp_name[icmp],"%s","xx");
  gdcurv->xx2d = gdcurv->v3d + cmp_pos[icmp];

  icmp += 1;
  cmp_pos[icmp] = (icmp-1) * gdcurv->siz_icmp + gdcurv->nxx *gdcurv->nzz * (icmp-2);
  sprintf(cmp_name[icmp],"%s","zz");
  gdcurv->zz2d = gdcurv->v3d + cmp_pos[icmp];
  
  // set pointer
  gdcurv->cmp_pos  = cmp_pos;
  gdcurv->cmp_name = cmp_name;

  return;
}

void 
gd_curv_metric_init(gdinfo_t        *gdinfo,
                    gdcurv_metric_t *metric)
{
  const int num_grid_vars = 5; 
  /*
   * 0: jac
   * 1-2: xi_x,  xi_z
   * 3-4: zeta_x, zeta_z
   */

  metric->nx   = gdinfo->nx;
  metric->nz   = gdinfo->nz;
  metric->ncmp = num_grid_vars;

  metric->siz_iz   = metric->nx;
  metric->siz_icmp  = metric->nx * metric->nz;
  
  // vars
  metric->v3d = (float *) fdlib_mem_calloc_1d_float(
                  metric->siz_icmp * metric->ncmp, 0.0, "gd_curv_init_g3d");
  if (metric->v3d == NULL) {
      fprintf(stderr,"Error: failed to alloc metric vars\n");
      fflush(stderr);
  }
  
  // position of each v3d
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(metric->ncmp,
                                                         0, 
                                                         "gd_curv_metric_init");
  
  // name of each v3d
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(metric->ncmp,
                                                       CONST_MAX_STRLEN,
                                                       "gd_curv_metric_init");
  
  // set value
  for (int icmp=0; icmp < metric->ncmp; icmp++)
  {
    cmp_pos[icmp] = icmp * metric->siz_icmp;
  }

  int icmp = 0;
  sprintf(cmp_name[icmp],"%s","jac");
  metric->jac = metric->v3d + cmp_pos[icmp];

  icmp += 1;
  sprintf(cmp_name[icmp],"%s","xi_x");
  metric->xi_x = metric->v3d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","xi_z");
  metric->xi_z = metric->v3d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","zeta_x");
  metric->zeta_x = metric->v3d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","zeta_z");
  metric->zeta_z = metric->v3d + cmp_pos[icmp];
  
  // set pointer
  metric->cmp_pos  = cmp_pos;
  metric->cmp_name = cmp_name;
}

//
// need to change to use fdlib_math.c
//
void
gd_curv_metric_cal(gdinfo_t        *gdinfo,
                   gd_t        *gdcurv,
                   gdcurv_metric_t *metric,
                   int fd_len, int *restrict fd_indx, float *restrict fd_coef)
{
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int nz  = gdinfo->nz;
  size_t siz_iz  = gdinfo->siz_iz;

  // point to each var
  float *restrict x2d  = gdcurv->x2d;
  float *restrict z2d  = gdcurv->z2d;
  float *restrict jac2d= metric->jac;
  float *restrict xi_x = metric->xi_x;
  float *restrict xi_z = metric->xi_z;
  float *restrict zt_x = metric->zeta_x;
  float *restrict zt_z = metric->zeta_z;

  float x_xi, x_zt;
  float z_xi, z_zt;
  float jac;
  float vec1[3], vec2[3], vec3[3], vecg[3];
  int n_fd;

  // use local stack array for speedup
  float  lfd_coef [fd_len];
  int    lfdx_shift[fd_len];
  int    lfdz_shift[fd_len];
  // put fd op into local array
  for (int k=0; k < fd_len; k++) {
    lfd_coef [k] = fd_coef[k];
    lfdx_shift[k] = fd_indx[k]            ;
    lfdz_shift[k] = fd_indx[k] * siz_iz;
  }

  for (size_t k = nk1; k <= nk2; k++){
      for (size_t i = ni1; i <= ni2; i++)
      {
        size_t iptr = i + k * siz_iz;

        x_xi = 0.0; x_zt = 0.0;
        z_xi = 0.0; z_zt = 0.0;

        M_FD_SHIFT(x_xi, x2d, iptr, fd_len, lfdx_shift, lfd_coef, n_fd);
        M_FD_SHIFT(z_xi, z2d, iptr, fd_len, lfdx_shift, lfd_coef, n_fd);

        M_FD_SHIFT(x_zt, x2d, iptr, fd_len, lfdz_shift, lfd_coef, n_fd);
        M_FD_SHIFT(z_zt, z2d, iptr, fd_len, lfdz_shift, lfd_coef, n_fd);

        vec1[0] = x_xi; vec1[1] = z_xi; vec1[2] = 0.0;
        vec2[0] = x_zt; vec2[1] = z_zt; vec2[2] = 0.0;
        vec3[0] = 0.0 ; vec3[1] = 0.0 ; vec3[2] = 1.0;

        // jac
        fdlib_math_cross_product(vec1, vec2, vecg);
        jac = fdlib_math_dot_product(vecg, vecg);
        jac = sqrt(jac);//eqa 4.4(Zhang)
        jac2d[iptr]  = jac;

        // xi_i
        fdlib_math_cross_product(vec2, vec3, vecg);
        xi_x[iptr] = vecg[0] / jac;
        xi_z[iptr] = vecg[1] / jac;

        // zt_i
        fdlib_math_cross_product(vec3, vec1, vecg);
        zt_x[iptr] = vecg[0] / jac;
        zt_z[iptr] = vecg[1] / jac;
      }
  }
    
  // extend to ghosts. may replaced by mpi exchange
  // x1, mirror
  for (size_t k = 0; k < nz; k++){
      for (size_t i = 0; i < ni1; i++)
      {
        size_t iptr = i + k * siz_iz;
        jac2d[iptr] = jac2d[iptr + (ni1-i)*2 -1 ];
         xi_x[iptr] =  xi_x[iptr + (ni1-i)*2 -1 ];
         xi_z[iptr] =  xi_z[iptr + (ni1-i)*2 -1 ];
         zt_x[iptr] =  zt_x[iptr + (ni1-i)*2 -1 ];
         zt_z[iptr] =  zt_z[iptr + (ni1-i)*2 -1 ];
      }
  }
  // x2, mirror
  for (size_t k = 0; k < nz; k++){
      for (size_t i = ni2+1; i < nx; i++)
      {
        size_t iptr = i + k * siz_iz;
        jac2d[iptr] = jac2d[iptr - (i-ni2)*2 +1 ];
         xi_x[iptr] =  xi_x[iptr - (i-ni2)*2 +1 ];
         xi_z[iptr] =  xi_z[iptr - (i-ni2)*2 +1 ];
         zt_x[iptr] =  zt_x[iptr - (i-ni2)*2 +1 ];
         zt_z[iptr] =  zt_z[iptr - (i-ni2)*2 +1 ];
      }
  }
  // z1, mirror
  for (size_t k = 0; k < nk1; k++) {
      for (size_t i = 0; i < nx; i++) {
        size_t iptr = i + k * siz_iz;
        jac2d[iptr] = jac2d[iptr + ((nk1-k)*2 -1) * siz_iz ];
         xi_x[iptr] =  xi_x[iptr + ((nk1-k)*2 -1) * siz_iz ];
         xi_z[iptr] =  xi_z[iptr + ((nk1-k)*2 -1) * siz_iz ];
         zt_x[iptr] =  zt_x[iptr + ((nk1-k)*2 -1) * siz_iz ];
         zt_z[iptr] =  zt_z[iptr + ((nk1-k)*2 -1) * siz_iz ];
      }
  }
  // z2, mirror
  for (size_t k = nk2+1; k < nz; k++) {
      for (size_t i = 0; i < nx; i++) {
        size_t iptr = i + k * siz_iz;
        jac2d[iptr] = jac2d[iptr - ((k-nk2)*2 -1) * siz_iz ];
         xi_x[iptr] =  xi_x[iptr - ((k-nk2)*2 -1) * siz_iz ];
         xi_z[iptr] =  xi_z[iptr - ((k-nk2)*2 -1) * siz_iz ];
         zt_x[iptr] =  zt_x[iptr - ((k-nk2)*2 -1) * siz_iz ];
         zt_z[iptr] =  zt_z[iptr - ((k-nk2)*2 -1) * siz_iz ];
      }
  }

  return;
}

void
gd_curv_metric_exchange(gdinfo_t        *gdinfo,
                        gdcurv_metric_t *metric,
                        int             *neighid,
                        MPI_Comm        topocomm)
{
  int nx  = gdinfo->nx;
  int nz  = gdinfo->nz;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;

  size_t siz_slice  = gdinfo->siz_iz;
  size_t siz_volume = gdinfo->siz_icmp;
  float *restrict g3d = metric->v3d;

  // extend to ghosts, using mpi exchange
  // NOTE in different myid, nx(or ny) may not equal
  // so send type DTypeXL not equal recv type DTypeXL
  int s_iptr;
  int r_iptr;

  MPI_Status status;
  MPI_Datatype DTypeXL;

  MPI_Type_vector(nz,
                  3,
                  nx,
                  MPI_FLOAT,
                  &DTypeXL); 
  MPI_Type_commit(&DTypeXL);

  for(int i=0; i<metric->ncmp; i++)
  {
    // to X1
    s_iptr = ni1 + i * siz_volume;        //sendbuff point (ni1,ny1,nz1)
    r_iptr = (ni2+1) + i * siz_volume;    //recvbuff point (ni2+1,ny1,nz1)
    MPI_Sendrecv(&g3d[s_iptr],1,DTypeXL,neighid[0],110,
                 &g3d[r_iptr],1,DTypeXL,neighid[1],110,
                 topocomm,&status);//sendbuf, sendcount, sendtype, dest, sendtag
    // to X2
    s_iptr = (ni2-3+1) + i * siz_volume;    //sendbuff point (ni2-3+1,ny1,nz1)
    r_iptr = (ni1-3) + i * siz_volume;      //recvbuff point (ni1-3,ny1,nz1)
    MPI_Sendrecv(&g3d[s_iptr],1,DTypeXL,neighid[1],120,
                 &g3d[r_iptr],1,DTypeXL,neighid[0],120,
                 topocomm,&status);
  }

}



/*
 * generate cartesian grid for curv struct
 */
void
gd_curv_gen_cart(gd_t *gdcurv,
                 float dx, float x0_glob,
                 float dz, float z0_glob)
{
  float *x2d = gdcurv->x2d;
  float *z2d = gdcurv->z2d;

  float x0 = x0_glob + (0 - gdcurv->fdx_nghosts) * dx;
  float z0 = z0_glob + (0 - gdcurv->fdz_nghosts) * dz;

  size_t iptr = 0;
  for (size_t k=0; k<gdcurv->nz; k++)
  {
      for (size_t i=0; i<gdcurv->nx; i++)
      {
        x2d[iptr] = x0 + i * dx;
        z2d[iptr] = z0 + k * dz;

        iptr++;
      }
  }

  return;
}

/*
 * generate cartesian grid , of no use
 */

void 
gd_cart_init_set(gd_t *gdcart,
                 float dx, float x0_glob,
                 float dz, float z0_glob)
{
  /*
   * 0-2: x2d, z2d
   */

  gdcart->type = GD_TYPE_CART;

  gdcart->nx   = gdcart->nx;
  gdcart->nz   = gdcart->nz;
  gdcart->ncmp = CONST_NDIM;

  gdcart->siz_iz   = gdcart->nx;
  gdcart->siz_icmp = gdcart->nx * gdcart->nz;
  
  // vars
  float *x1d = (float *) fdlib_mem_calloc_1d_float(
                  gdcart->nx, 0.0, "gd_cart_init");
  float *z1d = (float *) fdlib_mem_calloc_1d_float(
                  gdcart->nz, 0.0, "gd_cart_init");
  if (z1d == NULL) {
      fprintf(stderr,"Error: failed to alloc coord vars\n");
      fflush(stderr);
  }

  float x0 = x0_glob + (0 - gdcart->fdx_nghosts) * dx;
  float z0 = z0_glob + (0 - gdcart->fdz_nghosts) * dz;

  for (size_t k=0; k< gdcart->nz; k++)
  {
        z1d[k] = z0 + k * dz;
  }
  for (size_t i=0; i< gdcart->nx; i++)
  {
        x1d[i] = x0 + i * dx;
  }

  gdcart->dx = dx;
  gdcart->dz = dz;

  gdcart->xmin = x0;
  gdcart->zmin = z0;
  gdcart->xmax = x0 + (gdcart->nx-1) * dx;
  gdcart->zmax = z0 + (gdcart->nz-1) * dz;

  gdcart->x0_glob = x0_glob;
  gdcart->z0_glob = z0_glob;

  gdcart->x1d = x1d;
  gdcart->z1d = z1d;
  
  return;
}

//
// input/output
//
void
gd_curv_coord_export(gdinfo_t *gdinfo,
                     gd_t *gdcurv,
                     char *fname_coords,
                     char *output_dir)
{
  size_t *restrict c3d_pos   = gdcurv->cmp_pos;
  char  **restrict c3d_name  = gdcurv->cmp_name;
  int number_of_vars = gdcurv->ncmp;
  int  nx = gdcurv->nx;
  int  nz = gdcurv->nz;
  int  nxx = gdcurv->nxx;
  int  nzz = gdcurv->nzz;

  int  ni1 = gdinfo->ni1;
  int  nk1 = gdinfo->nk1;
  int  ni  = gdinfo->ni;
  int  nk  = gdinfo->nk;
  int  gni1 = gdinfo->ni1_to_glob_phys0;
  int  gnk1 = gdinfo->nk1_to_glob_phys0;
  int  nii1 = gdinfo->nii1;
  int  nkk1 = gdinfo->nkk1;
  int  nii  = gdinfo->nii;
  int  nkk  = gdinfo->nkk;
  int  gnii1 = gdinfo->nii1_to_glob_phys0;
  int  gnkk1 = gdinfo->nkk1_to_glob_phys0;

  // construct file name
  char ou_file[CONST_MAX_STRLEN];
  sprintf(ou_file, "%s/coord_%s.nc", output_dir,fname_coords);
  
  // read in nc
  int ncid;
  int varid[gdcurv->ncmp*2];
  int dimid[CONST_NDIM *2];
  int a[2];
  int b[2];

  int ierr = nc_create(ou_file, NC_CLOBBER, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"creat coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // define dimension
  ierr = nc_def_dim(ncid, "nxx", nxx, &dimid[3]);
  ierr = nc_def_dim(ncid, "nzz", nzz, &dimid[2]);
  ierr = nc_def_dim(ncid, "theta", nx, &dimid[1]);
  ierr = nc_def_dim(ncid, "rho", nz, &dimid[0]);
  a[0] = dimid[0];
  a[1] = dimid[1];
  b[0] = dimid[2];
  b[1] = dimid[3];

  // define vars
  for (int ivar=0; ivar<gdcurv->ncmp; ivar++) {
    ierr = nc_def_var(ncid, gdcurv->cmp_name[ivar], NC_FLOAT, CONST_NDIM, a, &varid[ivar]);
    ierr = nc_def_var(ncid, gdcurv->cmp_name[ivar+2], NC_FLOAT, CONST_NDIM, b, &varid[ivar+2]);
  }

  // attribute: index in output snapshot, index w ghost in thread
  int l_start[] = { ni1, nk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"local_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,l_start);
        
  int g_start[] = { gni1,  gnk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,g_start);

  int l_count[] = { ni, nk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points_polar",
                   NC_INT,CONST_NDIM,l_count);

  int car_count[] = { nii, nkk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points_car",
                   NC_INT,CONST_NDIM,car_count);

  int car_g_start[] = { gnii1,  gnkk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"car_global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,car_g_start);


  // end def
  ierr = nc_enddef(ncid);

  // add vars
  for (int ivar=0; ivar<gdcurv->ncmp; ivar++) {
    float *ptr = gdcurv->v3d + gdcurv->cmp_pos[ivar];
    ierr = nc_put_var_float(ncid, varid[ivar],ptr);
    float *ptr1 = gdcurv->v3d + gdcurv->cmp_pos[ivar+2];
    ierr = nc_put_var_float(ncid, varid[ivar+2],ptr1);
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

void
gd_curv_coord_import(gd_t *gdcurv, char *import_dir)
{
  // construct file name
  char in_file[CONST_MAX_STRLEN];
  sprintf(in_file, "%s/coord.nc", import_dir);
  
  // read in nc
  int ncid;
  int varid;

  int ierr = nc_open(in_file, NC_NOWRITE, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"open coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // read vars
  for (int ivar=0; ivar<gdcurv->ncmp; ivar++)
  {
    float *ptr = gdcurv->v3d + gdcurv->cmp_pos[ivar];

    ierr = nc_inq_varid(ncid, gdcurv->cmp_name[ivar], &varid);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }

    ierr = nc_get_var(ncid, varid, ptr);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

void
gd_curv_metric_export(gdinfo_t        *gdinfo,
                      gdcurv_metric_t *metric,
                      char *fname_coords,
                      char *output_dir)
{
  size_t *restrict g3d_pos   = metric->cmp_pos;
  char  **restrict g3d_name  = metric->cmp_name;
  int  number_of_vars = metric->ncmp;
  int  nx = metric->nx;
  int  nz = metric->nz;
  int  ni1 = gdinfo->ni1;
  int  nk1 = gdinfo->nk1;
  int  ni  = gdinfo->ni;
  int  nk  = gdinfo->nk;
  int  gni1 = gdinfo->ni1_to_glob_phys0;
  int  gnk1 = gdinfo->nk1_to_glob_phys0;

  // construct file name
  char ou_file[CONST_MAX_STRLEN];
  sprintf(ou_file, "%s/metric_%s.nc", output_dir,fname_coords);
  
  // read in nc
  int ncid;
  int varid[number_of_vars];
  int dimid[CONST_NDIM];

  int ierr = nc_create(ou_file, NC_CLOBBER, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"creat coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // define dimension
  ierr = nc_def_dim(ncid, "theta", nx, &dimid[1]);
  ierr = nc_def_dim(ncid, "rho", nz, &dimid[0]);

  // define vars
  for (int ivar=0; ivar<number_of_vars; ivar++) {
    ierr = nc_def_var(ncid, g3d_name[ivar], NC_FLOAT, CONST_NDIM, dimid, &varid[ivar]);
  }

  // attribute: index in output snapshot, index w ghost in thread
  int l_start[] = { ni1, nk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"local_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,l_start);

  int g_start[] = { gni1, gnk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,g_start);

  int l_count[] = { ni, nk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points",
                   NC_INT,CONST_NDIM,l_count);

  // end def
  ierr = nc_enddef(ncid);

  // add vars
  for (int ivar=0; ivar<number_of_vars; ivar++) {
    float *ptr = metric->v3d + g3d_pos[ivar];
    ierr = nc_put_var_float(ncid, varid[ivar],ptr);
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }
}

void
gd_curv_metric_import(gdcurv_metric_t *metric, char *import_dir)
{
  // construct file name
  char in_file[CONST_MAX_STRLEN];
  sprintf(in_file, "%s/metric.nc", import_dir);
  
  // read in nc
  int ncid;
  int varid;

  int ierr = nc_open(in_file, NC_NOWRITE, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"open coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // read vars
  for (int ivar=0; ivar<metric->ncmp; ivar++)
  {
    float *ptr = metric->v3d + metric->cmp_pos[ivar];

    ierr = nc_inq_varid(ncid, metric->cmp_name[ivar], &varid);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }

    ierr = nc_get_var(ncid, varid, ptr);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

/*
 * generate grid from a input grid layer file
 * code by SunWenliang  2021/06/14
 */
int
gd_curv_gen_layer(char *in_grid_layer_file,
                      int *grid_layer_resample_factor,
                      int *grid_layer_start,
                      int n_total_grid_x,
                      int n_total_grid_z,
                      int n_total_grid_car,
                      float *restrict x2d,
                      float *restrict z2d,
                      float *restrict xx2d,
                      float *restrict zz2d,float *dxz,
                      int nx, int ni, int gni1, int nxx, int gnii1, int fdx_nghosts, 
                      int nz, int nk, int gnk1, int nzz, int gnkk1, int fdz_nghosts)
{
  int ierr = 0;

  int nLayers;
  int n_Interfaces;
  int nx_layers;
  int nx_first;
  int nz_first;
  int nx_interp;
  int nz_interp;
  size_t iptr1 ;
  size_t iptr2 ;

//
// read data from layer file
//

  FILE * fp;
  fp = fopen( in_grid_layer_file, "r");
  if (!fp){
    fprintf(stderr,"Failed to open input file of interface!!\n");
    exit(-1);
  }

  // read number of interface
  fscanf(fp,"%d", &n_Interfaces);

  nLayers = n_Interfaces - 1;
  int NCellPerlay_IN[nLayers];
  int NCellPerlay[nLayers];
  int VmapSpacingIsequal[nLayers];

  // read cells and is_equal of each layer
  for ( int i=0; i<nLayers; i++)
  {
    fscanf(fp,"%d",&NCellPerlay_IN[i]);
  }
  for ( int i=0; i<nLayers; i++)
  {
    fscanf(fp,"%d",&VmapSpacingIsequal[i]);
  }

  // read number of horizontal sampling
  fscanf(fp,"%d",&nx_layers);

  size_t siz_icmp_layerIn = nx_layers * (nLayers+1) ;  
  float * layer2d_In        = NULL;
  layer2d_In = (float *)fdlib_mem_malloc_1d(siz_icmp_layerIn * 2 * sizeof(float), 
                                                              "gd_curv_gen_layer"); //layer2d_In contains x2d and z2d
  for ( int i=0; i<siz_icmp_layerIn; i++)
  {
    // read x,z of each sample
    fscanf(fp,"%f",&layer2d_In[i                     ]);
    fscanf(fp,"%f",&layer2d_In[i + siz_icmp_layerIn ]);
  }

  float * grid2d_In        = NULL;
  grid2d_In = (float *)fdlib_mem_malloc_1d( nzz * 2 * sizeof(float), 
                                                              "gd_curv_gen_cartesian"); //layer2d_In contains x2d and z2d
  for ( int i=0; i<nzz; i++)
  {
    // read x,z of each sample
    fscanf(fp,"%f",&grid2d_In[i        ]);
    fscanf(fp,"%f",&grid2d_In[i +  nzz ]);
  }
  //fprintf(stdout, "grid2d_In of iptr 1 and 0 is %f and %f\n",grid2d_In[1],grid2d_In[0]);
  *dxz = grid2d_In[1] - grid2d_In[0];
  fprintf(stdout, "dxz caled in gd is %f\n",*dxz);
  fclose( fp );

//
// resample of input interface grid nodes
//

  int x_interp_factor = abs(grid_layer_resample_factor[0]);  // 1
  int z_interp_factor = abs(grid_layer_resample_factor[1]);  // 1

  // effective layer nx after downsampling
  if ( grid_layer_resample_factor[0] < 0 ) {
    nx_interp = floor((nx_layers              + 1) / x_interp_factor);
    nx_first  = floor((grid_layer_start[0] + 1) / x_interp_factor);
  }
  // effective layer nx after upsampling
  else
  { 
    nx_interp = (nx_layers               -1) * x_interp_factor + 1;
    nx_first  = (grid_layer_start[0]-1) * x_interp_factor + 1;
  }

  nz_interp = 1;
  if ( grid_layer_resample_factor[1] < 0 ) //=1
  {
    for ( int kk=0; kk<nLayers; kk++)
    {
      NCellPerlay[kk] = NCellPerlay_IN[kk] / z_interp_factor ;
      nz_interp = nz_interp + NCellPerlay[kk];
    }
  }
  else
  { 
    for ( int kk=0; kk<nLayers; kk++)
    {
      NCellPerlay[kk] = NCellPerlay_IN[kk] * z_interp_factor ;
      nz_interp = nz_interp + NCellPerlay[kk];
    }
  }

  nz_first = nz_interp - grid_layer_start[1] - n_total_grid_z + fdz_nghosts;
  int x_gd_first = nx_first + gni1 - fdx_nghosts; //equals gni1
  int z_gd_first = nz_first + gnk1 - fdz_nghosts;

  if (gni1== 0)
  {
    fprintf(stdout, "\n<<<<<<<<<<   Input layer info   >>>>>>>>>>\n\n");
    fprintf(stdout, "n_Interfaces = %d\n", n_Interfaces);
    fprintf(stdout, "nx_layers = %d\n", nx_layers);

    fprintf(stdout, "     resample_factor = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", grid_layer_resample_factor[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "         NCellPerlay = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", NCellPerlay_IN[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "NCellPerlay_resample = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", NCellPerlay[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "  VmapSpacingIsequal = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", VmapSpacingIsequal[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "n_input_resample = [ %d %d ]\n", nx_interp, nz_interp);
    fprintf(stdout, "          n_c3d  = [ %d %d ]\n", n_total_grid_x + fdx_nghosts * 2, 
                                                      n_total_grid_z + fdz_nghosts * 2);
    fprintf(stdout, "horizontal_index = [ %d ] --> [ %d ]\n", x_gd_first,  
                                               x_gd_first + n_total_grid_x + fdx_nghosts * 2 );
    fprintf(stdout, "  vertical_index = %d --> %d \n", z_gd_first, z_gd_first + n_total_grid_z+ 
                                                                           fdz_nghosts);
    //fprintf(stdout, "-------------------------------------------------------\n");
    fflush(stdout);
  }

  //chech interface parameters
  if (nx_first - fdx_nghosts < 0)
  {
    fprintf(stdout, "Input Parameter Error: horizontal_start_index.\n");
    fflush(stdout);
    fprintf(stdout, "horizontal_start_index is related to fdx_nghosts\n");
    fflush(stdout);
    exit(-1);
  }
  else if (nx_first + n_total_grid_x + fdx_nghosts > nx_interp)
  {
    fprintf(stdout, "Input Parameter Error:\n"); 
    fflush(stdout);
    fprintf(stdout, "please check the number_of_total_grid_points, refine_factor and in_grid_layer_file file !!\n"); 
    fflush(stdout);
    exit(-1);
  }
  else if ( z_gd_first < 0)
  {
    fprintf(stdout, "Input Parameter Error:\n"); 
    fflush(stdout);
    fprintf(stdout, "please check the vertical_FreeSurf_AfterRefine_start_index\n number_of_total_grid_point_z\n refine_factor \nin_grid_layer_file file\n"); 
    fflush(stdout);
    exit(-1);
  }

  // resample based on interp_factor on input grid layer
  size_t siz_icmp_layer_interp = nx_interp * (nLayers + 1);
  float *layer2d_interp = NULL;
  layer2d_interp = (float *)fdlib_mem_malloc_1d(siz_icmp_layer_interp * 2 * sizeof(float),"gd_curv_gen_layer"); 
  
  // these 6 variables are used for grid_layer_resample_factor>2,of no use
  float   *xi_lenX = NULL;
  float   *xn_lenX = NULL;
  float *yi_x_lenX = NULL;
  float *yn_x_lenX = NULL;
  float *yi_z_lenX = NULL;
  float *yn_z_lenX = NULL;

  xi_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  xn_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");
  yi_x_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  yn_x_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");
  yi_z_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  yn_z_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");

  // Downsampling in X 
  if (grid_layer_resample_factor[0] < 2) 
  {
    for (int kk = 0; kk < nLayers+1; kk++) 
    {
      for (int ii = 0; ii < nx_interp; ii++)
      {
        iptr1 = M_gd_INDEX(ii, kk, nx_interp );  //equal to get points index.iptr1=iptr2
        iptr2 = M_gd_INDEX(ii * x_interp_factor,  kk, nx_layers);

        layer2d_interp[ iptr1                        ] = layer2d_In[ iptr2 ];
        layer2d_interp[ iptr1 +siz_icmp_layer_interp] = layer2d_In[ iptr2 +siz_icmp_layerIn]; 
      }
    }
  }
  //Interpolating in X  
  // of no use 860-890
  else if( grid_layer_resample_factor[0] >=2 )  
  {
    for ( int ii1=0; ii1<nx_interp; ii1++) xi_lenX[ii1] = ii1;
    for ( int ii1=0; ii1<nx_layers; ii1++) xn_lenX[ii1] = ii1*x_interp_factor;

    for (int kk = 0; kk < nLayers+1; kk++) {
      for ( int ii1=0; ii1<nx_layers; ii1++)
      {
        yn_x_lenX[ii1] = layer2d_In[M_gd_INDEX(ii1, kk, nx_layers)                     ];
        yn_z_lenX[ii1] = layer2d_In[M_gd_INDEX(ii1, kk, nx_layers) + siz_icmp_layerIn ];
      }

      gd_SPL(nx_layers, xn_lenX, yn_x_lenX, nx_interp, xi_lenX, yi_x_lenX);
      gd_SPL(nx_layers, xn_lenX, yn_z_lenX, nx_interp, xi_lenX, yi_z_lenX);

      for (int ii = 0; ii < nx_interp; ii++)
      {
          iptr1 = M_gd_INDEX(ii, kk, nx_interp);
          layer2d_interp[iptr1] = yi_x_lenX[ii];
          layer2d_interp[iptr1 + siz_icmp_layer_interp] = yi_z_lenX[ii];
      }
    }
  }

  free(xi_lenX);
  free(xn_lenX);
  free(yi_x_lenX);
  free(yn_x_lenX);
  free(yi_z_lenX);
  free(yn_z_lenX);

//
// generate FD grid
//

  float *layer2d = NULL;
  layer2d = ( float * ) malloc( sizeof( float ) * nx * (nLayers+1) * 2 );

  // suffix ch means:
  float zdiff_two_interface; // thickness between interfaces
  float zdiff_two_interface_ch;

  float *xlayer2d = layer2d + 0 * nx*(nLayers+1);
  float *zlayer2d = layer2d + 1 * nx*(nLayers+1);
  
  float * zlayerpart  = NULL;
  float * xlayerpart  = NULL;
  zlayerpart = (float *)fdlib_mem_malloc_1d((nLayers+1) * sizeof(float), "gd_curv_gen_layer");
  xlayerpart = (float *)fdlib_mem_malloc_1d((nLayers+1) * sizeof(float), "gd_curv_gen_layer");

  float * z2dpart  = NULL;
  float * x2dpart  = NULL;
  z2dpart = (float *)fdlib_mem_malloc_1d((nz_interp+fdz_nghosts*2) * sizeof(float), "gd_curv_gen_layer");
  x2dpart = (float *)fdlib_mem_malloc_1d((nz_interp+fdz_nghosts*2) * sizeof(float), "gd_curv_gen_layer");

  // layer regions of input model covered by this thread
  for (int k = 0; k < (nLayers + 1); k++) {
    for (int i = 0; i < nx; i++)
    {
      iptr1 = M_gd_INDEX(i, k, nx);
      iptr2 = M_gd_INDEX(i + x_gd_first, k, nx_interp);
      xlayer2d[iptr1] = layer2d_interp[iptr2];
      zlayer2d[iptr1] = layer2d_interp[iptr2 + siz_icmp_layer_interp];
    }
  }

  // interp both z and x,y
  for (int i = 0; i < nx; i++)
  {
    for (int k = 0; k < nLayers + 1; k++)
    {
      xlayerpart[k] = xlayer2d[M_gd_INDEX(i, k, nx)];
      zlayerpart[k] = zlayer2d[M_gd_INDEX(i, k, nx)];
    }
    // Interpolating the Z coordinate of the grid ,get z2dpart[NCellPerlay+1]
    gd_grid_z_interp(z2dpart, zlayerpart, NCellPerlay, VmapSpacingIsequal,
                     nLayers);

    // Interpolating the X and Y coordinate of the grid ...
    // by cubic spline interpolation method.
    gd_SPL(nLayers + 1, zlayerpart, xlayerpart, nz_interp, z2dpart, x2dpart);

    //Grids outside the Free Surface.
    for (int k = 1; k < fdz_nghosts + 1; k++)
    {
      iptr1 = nz_interp +2 ;
      x2dpart[iptr1 + k] = x2dpart[iptr1] * 2 - x2dpart[iptr1 - k];
      z2dpart[iptr1 + k] = z2dpart[iptr1] * 2 - z2dpart[iptr1 - k];
    }

    //Grids under the down surface.
    for (int k = 1; k <= fdz_nghosts ; k++)//1,2,3
    {
      iptr1 = fdz_nghosts ;
      x2dpart[iptr1 - k] = x2dpart[iptr1] * 2 - x2dpart[iptr1 + k];
      z2dpart[iptr1 - k] = z2dpart[iptr1] * 2 - z2dpart[iptr1 + k];
    }

    for ( int k = 0; k < nk + fdz_nghosts*2; k ++)
    {
      iptr1 = z_gd_first + k;
      x2d[M_gd_INDEX(i, k, nx)] = x2dpart[iptr1];
      z2d[M_gd_INDEX(i, k, nx)] = z2dpart[iptr1];
    }
  }
  //interp cartesian grid
  for (int i = 0; i < nxx; i++)
  {
    for (int k = 0; k < nzz; k++)
    {
      xx2d[M_gd_INDEX(i, k, nxx)] =  grid2d_In[i + gnii1];
      zz2d[M_gd_INDEX(i, k, nxx)] =  grid2d_In[k + n_total_grid_car + 2*fdx_nghosts];
      //fprintf(stdout, "xx2d and zz2d of iptr %d is %f  and  %f\n",M_gd_INDEX(i, k, nxz),xx2d[M_gd_INDEX(i, k, nxz)],zz2d[M_gd_INDEX(i, k, nxz)]);
    }
  }

  free(layer2d);
  free(layer2d_In);
  free(layer2d_interp);
  free(zlayerpart);
  free(xlayerpart);
  free(z2dpart);
  free(x2dpart);
  free(grid2d_In);

  return ierr;
}

//  Interpolating the Z coordinate
int gd_grid_z_interp(float *z2dpart, float *zlayerpart, int *NCellPerlay,
                     int *VmapSpacingIsequal, int nLayers)
{
  int ierr = 0;

  // If Grid step size of Z coordinate is not equal, divide the layer into two parts.
  // N1 is first part number of this layer and N2 is second.
  int N1;
  int N2;
  float distance;  //Interface spacing
  float dmidpoint;  //The length of the N1th grid
  float N1_Isochromatic; 
  float N2_Isochromatic;
  int NCellPerlay_max = 0;
  int sumNCellPerlay = 3;
  float LayerDz[nLayers];

  for (int i = 0; i < nLayers; i++)
  {
    if (NCellPerlay_max < NCellPerlay[i])
    {
      NCellPerlay_max = NCellPerlay[i];
    }
  }

  float range1[NCellPerlay_max]; //range is used for not equal
  float range2[NCellPerlay_max];

  for (int i = 0; i < nLayers; i++)
  {
    LayerDz[i] = (zlayerpart[i + 1] - zlayerpart[i]) / NCellPerlay[i];
  }

  for (int i = 0; i < nLayers; i++)
  {
    // The grid spacing is equal
    z2dpart[sumNCellPerlay] = zlayerpart[i];
    for (int ii = sumNCellPerlay; ii < sumNCellPerlay + NCellPerlay[i] - 1; ii++)//0-349
    {
      z2dpart[ii+1] = zlayerpart[i] + (ii - sumNCellPerlay + 1) * LayerDz[i];
    }
    // The grid spacing is not equal
    if (VmapSpacingIsequal[i] < 1 && i > 0 && i < nLayers - 1)
    {
      range1[0] = zlayerpart[i];
      if ((LayerDz[i] - LayerDz[i - 1]) * (LayerDz[i + 1] - LayerDz[i]) > 0)
      {
        N1 = ((LayerDz[i] - LayerDz[i - 1]) / (LayerDz[i + 1] - LayerDz[i - 1])) * (NCellPerlay[i] + 2) + 1;
        if (N1 > NCellPerlay[i] - 1)
          N1 = NCellPerlay[i] - 1;
        N2 = NCellPerlay[i] + 2 - N1;

        distance = zlayerpart[i + 1] - zlayerpart[i] + LayerDz[i - 1] + LayerDz[i + 1];
        dmidpoint = (2 * distance - LayerDz[i - 1] * N1 - LayerDz[i + 1] * (N2 + 1)) / (N1 + N2 - 1);

        N1_Isochromatic = (dmidpoint - LayerDz[i - 1]) / (N1 - 1);
        N2_Isochromatic = (LayerDz[i + 1] - dmidpoint) / (N2);

        for (int j = 1; j < N1; j++)
        {
          range1[j] = range1[j - 1] + LayerDz[i - 1] + j * N1_Isochromatic;
        }
        for (int j = N1; j < N1 + N2; j++)
        {
          range1[j] = range1[j - 1] + LayerDz[i + 1] - (N2 + N1 - j - 1) * N2_Isochromatic;
        }
        for (int ii = sumNCellPerlay; ii < sumNCellPerlay + NCellPerlay[i]; ii++)
        {
          z2dpart[ii] = range1[ii - sumNCellPerlay];
        }
      }
    }
    sumNCellPerlay += NCellPerlay[i];
  }
  z2dpart[sumNCellPerlay] = zlayerpart[nLayers];

  return ierr;
}

float gd_seval(int ni, float u,
            int n, float x[], float y[],
            float b[], float c[], float d[],
            int *last)
{
  int i, j, k;
  float w;
  i = *last;
  if (i >= n - 1) i = 0;
  if (i < 0) i = 0;
  if ((x[i] > u) || (x[i + 1] < u))//yes
  {
    i = 0;
    j = n;
    do
    {
      k = (i + j) / 2;
      if (u < x[k]) j = k;//yes
      if (u >= x[k]) i = k;
    } while (j > i + 1);
  }
  *last = i;
  w = u - x[i];
  w = y[i] + w * (b[i] + w * (c[i] + w * d[i]));//w = y[i]
  return (w);
}

//// Cubic spline difference function
int gd_SPLine( int n, int end1, int end2,
           float slope1, float slope2,
           float x[], float y[],
           float b[], float c[], float d[],
           int *iflag)
{
  int nm1, ib, i, ascend;
  float t;
  nm1 = n - 1;
  *iflag = 0;
  if (n < 2)
  {
    *iflag = 1;
    goto Leavegd_SPLine;
  }
  ascend = 1;
  for (i = 1; i < n; ++i) if (x[i] <= x[i - 1]) ascend = 0;//no
  if (!ascend)
  {
    *iflag = 2;
    goto Leavegd_SPLine;
  }
  if (n >= 3)
  {
    d[0] = x[1] - x[0];
    c[1] = (y[1] - y[0]) / d[0];
    for (i = 1; i < nm1; ++i)
    {
      d[i] = x[i + 1] - x[i];
      b[i] = 2.0 * (d[i - 1] + d[i]);
      c[i + 1] = (y[i + 1] - y[i]) / d[i];
      c[i] = c[i + 1] - c[i];
    }
    b[0] = -d[0];
    b[nm1] = -d[n - 2];
    c[0] = 0.0;
    c[nm1] = 0.0;
    if (n != 3)
    {
      c[0] = c[2] / (x[3] - x[1]) - c[1] / (x[2] - x[0]);
      c[nm1] = c[n - 2] / (x[nm1] - x[n - 3]) - c[n - 3] / (x[n - 2] - x[n - 4]);
      c[0] = c[0] * d[0] * d[0] / (x[3] - x[0]);
      c[nm1] = -c[nm1] * d[n - 2] * d[n - 2] / (x[nm1] - x[n - 4]);
    }
    if (end1 == 1)
    {
      b[0] = 2.0 * (x[1] - x[0]);
      c[0] = (y[1] - y[0]) / (x[1] - x[0]) - slope1;
    }
    if (end2 == 1)
    {
      b[nm1] = 2.0 * (x[nm1] - x[n - 2]);
      c[nm1] = slope2 - (y[nm1] - y[n - 2]) / (x[nm1] - x[n - 2]);
    }
    // Forward elimination 
    for (i = 1; i < n; ++i)
    {
      t = d[i - 1] / b[i - 1];
      b[i] = b[i] - t * d[i - 1];
      c[i] = c[i] - t * c[i - 1];
    }
    // Back substitution 
    c[nm1] = c[nm1] / b[nm1];
    for (ib = 0; ib < nm1; ++ib)
    {
      i = n - ib - 2;
      c[i] = (c[i] - d[i] * c[i + 1]) / b[i];
    }
    b[nm1] = (y[nm1] - y[n - 2]) / d[n - 2] + d[n - 2] * (c[n - 2] + 2.0 * c[nm1]);
    for (i = 0; i < nm1; ++i)
    {
      b[i] = (y[i + 1] - y[i]) / d[i] - d[i] * (c[i + 1] + 2.0 * c[i]);
      d[i] = (c[i + 1] - c[i]) / d[i];
      c[i] = 3.0 * c[i];
    }
    c[nm1] = 3.0 * c[nm1];
    d[nm1] = d[n - 2];
  }
  else
  {
    b[0] = (y[1] - y[0]) / (x[1] - x[0]);
    c[0] = 0.0;
    d[0] = 0.0;
    b[1] = b[0];
    c[1] = 0.0;
    d[1] = 0.0;
  }
Leavegd_SPLine:
  return 0;
}

//// Cubic spline difference function in grid interpolation
void gd_SPL(int n, float *x, float *y, int ni, float *xi, float *yi)
{
  float *b, *c, *d;
  int iflag=0, last=0, i=0;
  b = (float *)fdlib_mem_malloc_1d(n * sizeof(float), "gd_SPL");
  c = (float *)fdlib_mem_malloc_1d(n * sizeof(float), "gd_SPL");
  d = (float *)fdlib_mem_malloc_1d(n * sizeof(float), "gd_SPL");

  if (!d) { printf("no enough memory for b,c,d\n"); }
  else {
    gd_SPLine(n, 0, 0, 0.0, 0.0, x, y, b, c, d, &iflag);
    for (i = 3; i<ni+3; i++)
      yi[i] = gd_seval(ni, xi[i], n, x, y, b, c, d, &last);//return xlayerpart[i]
    free(b);
    free(c);
    free(d);
  };
}

void
gd_curv_set_minmax(gdinfo_t *gdinfo, gd_t *gdcurv)
{
  float xmin = gdcurv->x2d[0], xmax = gdcurv->x2d[0];
  float zmin = gdcurv->z2d[0], zmax = gdcurv->z2d[0];
  
  for (size_t i = 0; i < gdcurv->siz_icmp; i++){
      xmin = xmin < gdcurv->x2d[i] ? xmin : gdcurv->x2d[i];
      xmax = xmax > gdcurv->x2d[i] ? xmax : gdcurv->x2d[i];
      zmin = zmin < gdcurv->z2d[i] ? zmin : gdcurv->z2d[i];
      zmax = zmax > gdcurv->z2d[i] ? zmax : gdcurv->z2d[i];
  }

  gdcurv->xmin = xmin;
  gdcurv->xmax = xmax;
  gdcurv->zmin = zmin;
  gdcurv->zmax = zmax;

  //  physics points without ghosts
  xmin = gdcurv->xmax;
  xmax = gdcurv->xmin;
  zmin = gdcurv->zmax;
  zmax = gdcurv->zmin;
  for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++) {
      for (int i = gdinfo->ni1; i <= gdinfo->ni2; i++) {
         size_t iptr = i +  k * gdinfo->siz_slice;
         xmin = xmin < gdcurv->x2d[iptr] ? xmin : gdcurv->x2d[iptr];
         xmax = xmax > gdcurv->x2d[iptr] ? xmax : gdcurv->x2d[iptr];
         zmin = zmin < gdcurv->z2d[iptr] ? zmin : gdcurv->z2d[iptr];
         zmax = zmax > gdcurv->z2d[iptr] ? zmax : gdcurv->z2d[iptr];
      }
  }
  gdcurv->xmin_phy = xmin;
  gdcurv->xmax_phy = xmax;
  gdcurv->zmin_phy = zmin;
  gdcurv->zmax_phy = zmax;

  return;
}

/*
 * convert cart coord to global index
 */

int
gd_cart_coord_to_local_indx(gd_t *gdcart,
                            float sx,
                            float sz,
                            int   *ou_si, int *ou_sk,
                            float *ou_sx_inc, float *ou_sz_inc)
{
  int ierr = 0;

  int si_glob = (int)( (sx - gdcart->x0_glob) / gdcart->dx + 0.5 );
  int sk_glob = (int)( (sz - gdcart->z0_glob) / gdcart->dz + 0.5 );
  float sx_inc = si_glob * gdcart->dx + gdcart->x0_glob - sx;
  float sz_inc = sk_glob * gdcart->dz + gdcart->z0_glob - sz;

  *ou_si = si_glob + gdcart->fdx_nghosts;
  *ou_sk = sk_glob + gdcart->fdz_nghosts;
  *ou_sx_inc = sx_inc;
  *ou_sz_inc = sz_inc;

  return ierr; 
}

/* 
 * if the nearest point in this thread then search its grid index
 *   return value:
 *      1 - in this thread
 *      0 - not in this thread
 */

int
gd_curv_coord_to_glob_indx(gdinfo_t *gdinfo,
                            gd_t *gdcurv,
                            float sx, float sz,
                            MPI_Comm comm,
                            int myid,
                            int *ou_si, int *ou_sk,
                            float *ou_sx_inc, float *ou_sz_inc) 
{
  int is_here = 0;

  //NOTE si_glob sj_glob sk_glob must less -3. due to ghost points length is 3.
  int si_glob = -1000;
  int sk_glob = -1000;
  float sx_inc = 0.0;
  float sz_inc = 0.0;
  int si = 0;
  int sk = 0;

  // if located in this thread
  is_here = gd_curv_coord_to_local_indx(gdinfo,gdcurv,sx,sz,
                                    &si, &sk, &sx_inc, &sz_inc);

  // if in this thread
  if ( is_here == 1)
  {
    // conver to global index
    si_glob = gd_info_ind_lcext2glphy_i(si, gdinfo);
    sk_glob = gd_info_ind_lcext2glphy_k(sk, gdinfo);

  } else {
    return is_here;
    //fprintf(stdout," -- not in this thread %d\n", myid);
  }

  // reduce global index and shift values
  int sendbufi = si_glob;
  MPI_Allreduce(&sendbufi, &si_glob, 1, MPI_INT, MPI_MAX, comm);//data,max

  sendbufi = sk_glob;
  MPI_Allreduce(&sendbufi, &sk_glob, 1, MPI_INT, MPI_MAX, comm);

  float sendbuf = sx_inc;
  MPI_Allreduce(&sendbuf, &sx_inc, 1, MPI_FLOAT, MPI_SUM, comm);           

  sendbuf = sz_inc;
  MPI_Allreduce(&sendbuf, &sz_inc, 1, MPI_FLOAT, MPI_SUM, comm);


  *ou_si = si_glob;
  *ou_sk = sk_glob;
  *ou_sx_inc = sx_inc;
  *ou_sz_inc = sz_inc;

  return is_here;
}

int
gd_curv_coord_to_local_indx(gdinfo_t *gdinfo,
                            gd_t *gd,
                            float sx, float sz,
                            int *si, int *sk,
                            float *sx_inc, float *sz_inc) 
{
  int is_here = 0; // default outside

  int nx = gdinfo->nx;
  int nz = gdinfo->nz;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  size_t siz_iz = gd->siz_iz;

  float *restrict x2d = gd->x2d;
  float *restrict z2d = gd->z2d;

  // outside coord range
  if ( sx < gd->xmin || sx > gd->xmax ||
       sz < gd->zmin || sz > gd->zmax)
  {
    is_here = 0;
    return is_here;
  }

  // init closest point
  float min_dist = sqrtf(  (sx - x2d[0]) * (sx - x2d[0])
      + (sz - z2d[0]) * (sz - z2d[0]) );
  int min_dist_i = 0 ;
  int min_dist_k = 0 ;

  // compute distance to each point
  for (int k=0; k<nz; k++) {
      for (int i=0; i<nx; i++)
      {
        size_t iptr = i + k * siz_iz;

        float x = x2d[iptr];
        float z = z2d[iptr];

        float DistInt = sqrtf(  (sx - x) * (sx - x)
            + (sz - z) * (sz - z) );

        // replace closest point
        if (min_dist > DistInt)
        {
          min_dist = DistInt;
          min_dist_i = i;
          min_dist_k = k;
        }
      }
  }

  // if nearest index is outside phys region, not here
  if ( min_dist_i < ni1 || min_dist_i > ni2 ||
      min_dist_k < nk1 || min_dist_k > nk2 )
  {
    is_here = 0;
    return is_here;
  }

  // in this thread
  is_here = 1;

  float points_x[4];
  float points_z[4];
  float points_i[4];
  float points_k[4];

  for (int kk=0; kk<2; kk++)
  {
      for (int ii=0; ii<2; ii++)
      {
        int cur_i = min_dist_i-1+ii;
        int cur_k = min_dist_k-1+kk;

        for (int n3=0; n3<2; n3++) {
            for (int n1=0; n1<2; n1++) {
              int iptr_cube = n1 + n3 * 2;
              int iptr = (cur_i+n1)  + (cur_k+n3) * siz_iz;
              points_x[iptr_cube] = x2d[iptr];
              points_z[iptr_cube] = z2d[iptr];
              points_i[iptr_cube] = cur_i+n1;
              points_k[iptr_cube] = cur_k+n3;
            }
        }

        if (fdlib_math_isPoint2InQuad(sx,sz,points_x,points_z) == 1)
        {
          float si_curv, sk_curv;

          gd_curv_coord2index_sample(sx,sz,
              points_x,points_z,
              points_i,points_k,
              100,100,
              &si_curv, &sk_curv);

          // convert to return values
          *si = min_dist_i;
          *sk = min_dist_k;
          *sx_inc = si_curv - min_dist_i;
          *sz_inc = sk_curv - min_dist_k;

          return is_here;
        }
      }
  }

  // if not in any cube due to bug, set default value
  //    if everything is right, should be return 10 line before
  *si = min_dist_i;
  *sk = min_dist_k;
  *sx_inc = 0.0;
  *sz_inc = 0.0;

  return is_here;
}


/*
 * convert depth to axis
 */
int
gd_curv_depth_to_axis(gdinfo_t *gdinfo,
                      gd_t *gd,
                      float sx,
                      float *sz)
{
  int ierr = 0;
  int nk2 = gdinfo->nk2;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  size_t siz_iz = gd->siz_iz;
  size_t iptr;
  size_t iptr_pt;
  float points_x[2];
  float points_z[2];
  float xmin, xmax;

  // not here if outside coord range
  if ( sx < gd->xmin || sx > gd->xmax )
  {
    return ierr;
  }


  for(int i=ni1; i<ni2; i++)
  {
    iptr = i + nk2 * siz_iz;
    xmin = gd->x2d[iptr];
    xmax = gd->x2d[iptr+1];
    if(sx>=xmin  && sx <xmax )
    {
      for (int n1=0; n1<2; n1++) 
      {
        iptr_pt = (i+n1) + nk2 * siz_iz;
        points_x[n1] = gd->x2d[iptr_pt];
        points_z[n1] = gd->z2d[iptr_pt];
      }
    }
  }

  float ztopo = linear_interp_1d(sx,points_x,points_z);
  *sz = ztopo - (*sz);

  return ierr;
}

float
linear_interp_1d(float ix, float *x, float *z)
{
  float iz;
  iz = (ix-x[1])/(x[0]-x[1])*z[0] + (ix-x[0])/(x[1]-x[0]) * z[1];

  return iz;
}


/* 
 * find curv index using sampling
 */

  int
gd_curv_coord2index_sample(float sx, float sz, 
    float *points_x, // x coord of all points
    float *points_z,
    float *points_i, // curv coord of all points
    float *points_k,
    int    nx_sample,
    int    nz_sample,
    float *si_curv, // interped curv coord
    float *sk_curv)
{
  float Lx[2], Lz[2];

  // init closest point
  float min_dist = sqrtf(  (sx - points_x[0]) * (sx - points_x[0])
      + (sz - points_z[0]) * (sz - points_z[0]) );
  int min_dist_i = 0 ;
  int min_dist_k = 0 ;

  // linear interp for all sample
  for (int n3=0; n3<nz_sample+1; n3++)
  {
    Lz[1] = (float)(n3) / (float)(nz_sample);
    Lz[0] = 1.0 - Lz[1];
      for (int n1=0; n1<nx_sample+1; n1++)
      {
        Lx[1] = (float)(n1) / (float)(nx_sample);
        Lx[0] = 1.0 - Lx[1];

        // interp
        float x_pt=0;
        float z_pt=0;
        for (int kk=0; kk<2; kk++) {
            for (int ii=0; ii<2; ii++)
            {
              int iptr_cube = ii + kk * 2;
              x_pt += Lx[ii]*Lz[kk] * points_x[iptr_cube];
              z_pt += Lx[ii]*Lz[kk] * points_z[iptr_cube];
            }
        }

        // find min dist
        float DistInt = sqrtf(  (sx - x_pt) * (sx - x_pt)
            + (sz - z_pt) * (sz - z_pt) );

        // replace closest point
        if (min_dist > DistInt)
        {
          min_dist = DistInt;
          min_dist_i = n1;
          min_dist_k = n3;
        }
      } // n1
  } // n3

  *si_curv = points_i[0] + (float)min_dist_i / (float)nx_sample;
  *sk_curv = points_k[0] + (float)min_dist_k / (float)nz_sample;

  return 0;
}

/* 
 * interp curv coord using inverse distance interp
 */

int
gd_curv_coord2index_rdinterp(float sx, float sz, 
    int num_points,
    float *points_x, // x coord of all points
    float *points_z,
    float *points_i, // curv coord of all points
    float *points_k,
    float *si_curv, // interped curv coord
    float *sk_curv)
{
  float weight[num_points];
  float total_weight = 0.0 ;

  // cal weight
  int at_point_indx = -1;
  for (int i=0; i<num_points; i++)
  {
    float dist = sqrtf ((sx - points_x[i]) * (sx - points_x[i])
        + (sz - points_z[i]) * (sz - points_z[i])
        );
    if (dist < 1e-9) {
      at_point_indx = i;
    } else {
      weight[i]   = 1.0 / dist;
      total_weight += weight[i];
    }
  }
  // if at a point
  if (at_point_indx > 0) {
    total_weight = 1.0;
    // other weight 0
    for (int i=0; i<num_points; i++) {
      weight[i] = 0.0;
    }
    // point weight 1
    weight[at_point_indx] = 1.0;
  }

  // interp

  *si_curv = 0.0;
  *sk_curv = 0.0;

  for (int i=0; i<num_points; i++)
  {
    weight[i] *= 1.0 / total_weight ;

    (*si_curv) += weight[i] * points_i[i];
    (*sk_curv) += weight[i] * points_k[i];  

    fprintf(stdout,"---- i=%d,weight=%f,points_i=%f,points_k=%f\n",
        i,weight[i],points_i[i],points_k[i]);
  }

  return 0;
}

float
gd_coord_get_x(gd_t *gd, int i, int k)
{
  float var = 0.0;

  if (gd->type == GD_TYPE_CART)
  {
    var = gd->x1d[i];
  }
  else if (gd->type == GD_TYPE_CURV)
  {
    size_t iptr = i + k * gd->siz_iz;
    var = gd->x2d[iptr];
  }

  return var;
}

float
gd_coord_get_z(gd_t *gd, int i, int k)
{
  float var = 0.0;

  if (gd->type == GD_TYPE_CART)
  {
    var = gd->z1d[k];
  }
  else if (gd->type == GD_TYPE_CURV)
  {
    size_t iptr = i + k * gd->siz_iz;
    var = gd->z2d[iptr];
  }

  return var;
}

//to get whole gd coord
int
gd_gather_global(gd_t  *gd,gdinfo_t  *gdinfo,mympi_t *mympi)
{

  int ni = gdinfo->ni;
  int nk = gdinfo->nk;
  int nii = gdinfo->nii;
  int nkk = gdinfo->nkk;
  int n_ghost = gd->npoint_ghosts;
  int nproc = mympi->nproc;
  int *displs_polar   = mympi-> displs_polar;
  int *displs_car     = mympi-> displs_car; //displs has ni*nk
  int *allCount_polar = mympi->allCount_polar;
  int *allCount_car   = mympi->allCount_car;  //contains num_point of each block

  mympi->each_ni_polar  = ( int * ) malloc( sizeof( int ) * nproc );
  mympi->each_nii_car  = ( int * ) malloc( sizeof( int ) * nproc );
  mympi->displs_polar_ni  = ( int * ) malloc( sizeof( int ) * nproc );
  mympi->displs_car_nii  = ( int * ) malloc( sizeof( int ) * nproc );//displs only has ni
  int *each_ni_polar  = mympi->each_ni_polar;
  int *each_nii_car  = mympi->each_nii_car;
  int *displs_polar_ni  = mympi->displs_polar_ni;
  int *displs_car_nii  = mympi->displs_car_nii;

  //cal displs
  int sendnum_polar,sendnum_car;
  sendnum_polar = ni *nk; 
  sendnum_car   = nii *nkk;
  
  MPI_Allgather(&sendnum_polar, 1, MPI_INT, allCount_polar, 1, MPI_INT, MPI_COMM_WORLD);
  MPI_Allgather(&sendnum_car  , 1, MPI_INT, allCount_car  , 1, MPI_INT, MPI_COMM_WORLD);

  MPI_Allgather(&ni,  1, MPI_INT, each_ni_polar, 1, MPI_INT, MPI_COMM_WORLD);
  MPI_Allgather(&nii, 1, MPI_INT, each_nii_car , 1, MPI_INT, MPI_COMM_WORLD);
  
  displs_polar[0] =0; 
  displs_car  [0] =0;  
  displs_polar_ni [0] =0; 
  displs_car_nii  [0] =0;  
  for(int i=1 ; i<nproc; i++){
    //cal displs
    displs_polar[i] = displs_polar[i-1] + allCount_polar[i-1] ;
    displs_car  [i] = displs_car  [i-1] + allCount_car  [i-1] ;
    displs_polar_ni[i] = displs_polar_ni[i-1] + each_ni_polar[i-1] ;
    displs_car_nii [i] = displs_car_nii [i-1] + each_nii_car [i-1] ;
  }
  
  gd->global_x2d  = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_x * gdinfo->num_total_grid_z );
  gd->global_z2d  = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_x * gdinfo->num_total_grid_z );
  gd->global_xx2d = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_car * gdinfo->num_total_grid_car );
  gd->global_zz2d = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_car * gdinfo->num_total_grid_car );
  
  float * g_x2d  = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_x * gdinfo->num_total_grid_z );
  float * g_z2d  = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_x * gdinfo->num_total_grid_z );
  float * g_xx2d = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_car * gdinfo->num_total_grid_car );
  float * g_zz2d = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_car * gdinfo->num_total_grid_car );
  
  float *g_x2d_ordered = gd->global_x2d;
  float *g_z2d_ordered = gd->global_z2d;
  float *g_xx2d_ordered = gd->global_xx2d;
  float *g_zz2d_ordered = gd->global_zz2d;

  //gather polar gd
  float *local_x2d = ( float * ) malloc( sizeof( float ) * ni * nk );
  float *local_z2d = ( float * ) malloc( sizeof( float ) * ni * nk ); //exclude ghost points of mpi block
  for (int i = 0; i < ni; i++)
  {
    for (int k = 0; k < nk; k++)
    {
      int iptr1 = n_ghost*(ni +2*n_ghost) + n_ghost*(2*k +1) + i + k*ni;
      local_x2d[i+k*ni] = gd->x2d[iptr1];
      local_z2d[i+k*ni] = gd->z2d[iptr1];
    }
  }
  
  MPI_Allgatherv(local_x2d , ni*nk , MPI_FLOAT , g_x2d  ,allCount_polar ,displs_polar, MPI_FLOAT , MPI_COMM_WORLD);
  MPI_Allgatherv(local_z2d , ni*nk , MPI_FLOAT , g_z2d  ,allCount_polar ,displs_polar, MPI_FLOAT , MPI_COMM_WORLD);

  //gather cartesian gd
  float *local_xx2d = ( float * ) malloc( sizeof( float ) * nii * nkk );
  float *local_zz2d = ( float * ) malloc( sizeof( float ) * nii * nkk ); //exclude ghost points of mpi block
  for (int i = 0; i < nii; i++)
  {
    for (int k = 0; k < nkk; k++)
    {
      
      int iptr2 = n_ghost*(nii +2*n_ghost) + n_ghost*(2*k +1) + i + k*nii;
      local_xx2d[i+k*nii] = gd->xx2d[iptr2];
      local_zz2d[i+k*nii] = gd->zz2d[iptr2];
    }
  }
  
  MPI_Allgatherv(local_xx2d , nii*nkk , MPI_FLOAT , g_xx2d  ,allCount_car ,displs_car, MPI_FLOAT , MPI_COMM_WORLD);
  MPI_Allgatherv(local_zz2d , nii*nkk , MPI_FLOAT , g_zz2d  ,allCount_car ,displs_car, MPI_FLOAT , MPI_COMM_WORLD);

  //sort polar_global in right order(g_~2d -> g_~2d_ordered)
  for(int k=0 ; k<nk ; k++)
  {
    for(int p=0 ; p<nproc ; p++)
    {
      //start pointer of each block_line_piece
      float *g_x2d_block_line = g_x2d_ordered + k * gdinfo->num_total_grid_x + displs_polar_ni[p];
      float *g_z2d_block_line = g_z2d_ordered + k * gdinfo->num_total_grid_x + displs_polar_ni[p];

      for(int i=0 ; i<each_ni_polar[p] ; i++)
      {
        g_x2d_block_line [i] = g_x2d [ displs_polar[p] + k * each_ni_polar[p] +i];
        g_z2d_block_line [i] = g_z2d [ displs_polar[p] + k * each_ni_polar[p] +i];
      }
    }
  }

  //sort car_global in right order(g_~2d -> g_~2d_ordered)
  for(int k=0 ; k<nkk ; k++)
  {
    for(int p=0 ; p<nproc ; p++)
    {
      //start pointer of each block_line_piece
      float *g_xx2d_block_line = g_xx2d_ordered + k * gdinfo->num_total_grid_car + displs_car_nii[p];
      float *g_zz2d_block_line = g_zz2d_ordered + k * gdinfo->num_total_grid_car + displs_car_nii[p];

      for(int i=0 ; i<each_nii_car[p] ; i++)
      {
        g_xx2d_block_line [i] = g_xx2d[ displs_car[p] + k * each_nii_car[p] +i];
        g_zz2d_block_line [i] = g_zz2d[ displs_car[p] + k * each_nii_car[p] +i];
      }
    }
  }
  
  //give polar_global_gd 6 nghost layers for interp
  int num_total_nx = gdinfo->num_total_grid_x + 2*n_ghost;
  gd->global_x2d_ghost  = ( float * ) malloc( sizeof( float ) * num_total_nx * gdinfo->num_total_grid_z );
  gd->global_z2d_ghost  = ( float * ) malloc( sizeof( float ) * num_total_nx * gdinfo->num_total_grid_z );
  for (int i = n_ghost; i < gdinfo->num_total_grid_x + n_ghost; i++)
  {
    for (int k = 0; k < gdinfo->num_total_grid_z; k++)
    {
      int iptr = i + k*num_total_nx;
      int iptr1 = i-3+ k*gdinfo->num_total_grid_x;
      gd->global_x2d_ghost[iptr] =  g_x2d_ordered[iptr1];
      gd->global_z2d_ghost[iptr] =  g_z2d_ordered[iptr1];
    }
  }
  
  //x2d left/right 3 layers for mirror,z2d for copy
  for (size_t k = 0; k < gdinfo->num_total_grid_z; k++)
  {
      //left
      for (size_t i = 0; i < n_ghost; i++)
      {
        size_t iptr = i + k * num_total_nx;
        gd->global_x2d_ghost[iptr] = 2*gd->global_x2d_ghost[iptr- i + n_ghost] - gd->global_x2d_ghost[iptr -2*(i- n_ghost)];
        gd->global_z2d_ghost[iptr] = gd->global_z2d_ghost[iptr+ gdinfo->num_total_grid_x ] ;
      }
      //right
      for (size_t i = num_total_nx - n_ghost; i < num_total_nx; i++)
      {
        size_t iptr = i + k * num_total_nx;
        gd->global_x2d_ghost[iptr] = 2*gd->global_x2d_ghost[iptr -i + num_total_nx -4] - gd->global_x2d_ghost[iptr -2*(i+ 4 -num_total_nx)];
        gd->global_z2d_ghost[iptr] = gd->global_z2d_ghost[iptr- gdinfo->num_total_grid_x ] ;
      }
  }

  //check if global_gd is complete
  /*if (mympi->myid==1) {
    for (int iii=0;iii<num_total_nx * gdinfo->num_total_grid_z;iii++)
  fprintf(stdout,"myid of %d polar_global_ghost of %d is xx= %f ,zz= %f\n",mympi->myid,iii,gd->global_x2d_ghost[iii],gd->global_z2d_ghost[iii]); }
  */

  return 0;
}

//find nearby cartesian points of polar ghost points
int 
polar_ghost_neighbor(mympi_t *mympi,gd_t *gd,gdinfo_t  *gdinfo)
{
  int size = gdinfo->size_of_interp;

  gd->p_ghost_lociptr = (int **) fdlib_mem_calloc_2l_int(
                   gd->nx * gd->npoint_ghosts  ,size*size, -1, "polar_ghost_neighbor_init");
  
  gd->p_ghost_block = (int **) fdlib_mem_calloc_2l_int(
                   gd->nx * gd->npoint_ghosts  ,size*size, -1, "polar_ghost_neighbor_init");

  gd->p_ghostxx = ( float * ) malloc( sizeof( float ) * gd->nx * gd->npoint_ghosts );
  gd->p_ghostzz = ( float * ) malloc( sizeof( float ) * gd->nx * gd->npoint_ghosts ); 
  gd->p_ghostx = ( int * ) malloc( sizeof( int ) * gd->nx * gd->npoint_ghosts );
  gd->p_ghostz = ( int * ) malloc( sizeof( int ) * gd->nx * gd->npoint_ghosts );

  float * c2x2d  = ( float * ) malloc( sizeof( float ) * gd->nx * gd->npoint_ghosts );
  float * r2z2d  = ( float * ) malloc( sizeof( float ) * gd->nx * gd->npoint_ghosts );
  int *ghost_glob_x =  ( int * ) malloc( sizeof( int ) * size );//use for each polar point
  int *ghost_glob_z =  ( int * ) malloc( sizeof( int ) * size );
  


  for (size_t k = 0; k < gdinfo->nk1; k++) 
  {
      for (size_t i = gdinfo->ni1; i <= gdinfo->ni2; i++) 
      {
        //get ghost global_indx
        size_t iptr = i + k * gd->nx;
        c2x2d[iptr] = gd->z2d[iptr] * cos(gd->x2d[iptr]);
        r2z2d[iptr] = gd->z2d[iptr] * sin(gd->x2d[iptr]);

        for (size_t ii =0; ii < gdinfo->num_total_grid_car ;ii++)
        {
          if (c2x2d[iptr] <= gd->global_xx2d[ii])//seem ii as line
          {
            gd->p_ghostx[iptr] = ii;
            for (int m =0; m< size; m++) {
            ghost_glob_x[m] = ii-size/2+m;}
            break;
          }
          
        }
        for (size_t kk =0; kk < gdinfo->num_total_grid_car ;kk++)
        {
          if (r2z2d[iptr] <= gd->global_zz2d[kk*gdinfo->num_total_grid_car])//seem kk as cow
          {
            gd->p_ghostz[iptr] = kk;
            for (int n =0; n< size; n++) {
            ghost_glob_z[n] = kk-size/2+n;}
            break;
          }
        }

        //change ghost_global to ghost_local and get block indx for each size*size point
        int nproc = mympi->nproc;
        for (int m =0; m< size; m++)  {
            for (int n =0; n< size; n++) {
              //search block
              for(int i=1 ; i<nproc; i++){
                  if (ghost_glob_x[m] < mympi->displs_car_nii[i]){
                  gd->p_ghost_block[iptr][m+size*n] = i-1;
                  break;}
                  else{
                  gd->p_ghost_block[iptr][m+size*n] = nproc-1; }
                }
              
              //find local iptr to size*size,this iptr contains ghost points
              gd->p_ghost_lociptr[iptr][m+size*n] =\
                              ghost_glob_x[m] - mympi->displs_car_nii[gd->p_ghost_block[iptr][m+size*n]] + gd->npoint_ghosts \
                              + (ghost_glob_z[n]+gd->npoint_ghosts)* \
                              (mympi-> each_nii_car[gd->p_ghost_block[iptr][m+size*n]] +2*gd->npoint_ghosts);
  
            }
        }

      }
  }
    //save xx and zz value
    for (size_t k = 0; k < gdinfo->nk1; k++) 
    {
        for (size_t i = 0; i < gd->nx; i++) 
        {
          size_t iptr = i + k * gd->nx;
          gd->p_ghostxx[iptr] = c2x2d[iptr] ;
          gd->p_ghostzz[iptr] = r2z2d[iptr] ;
        }
    } 
  
  //check polar_neigh block != -1
    for (size_t k = 0; k < gdinfo->nk1; k++) 
    {
        for (size_t i = gdinfo->ni1; i <= gdinfo->ni2; i++)
        {
          //get ghost global_indx
          size_t iptr = i + k * gd->nx;
          for (int m =0; m< size; m++)  {
            for (int n =0; n< size; n++) {
                if(gd->p_ghost_block[iptr][m+size*n] ==-1 ){
                  fprintf(stdout,"!!!!!!!  error   !!!!! \n polar_ghost_neigh block can't equal -1 in mpi %d and iptr %d\n",mympi->myid,iptr);// error
                  exit(-1);
                }
            }
          }
        }
    }
 
  free(c2x2d);
  free(r2z2d);
  free(ghost_glob_x);
  free(ghost_glob_z);
  return 0;
}


//find nearby polar points of cartesian ghost points
int 
cartesian_ghost_neighbor(mympi_t *mympi, gd_t *gd,gdinfo_t  *gdinfo)
{
  int size = gdinfo->size_of_interp;

  gd->c_ghost_lociptr = (int **) fdlib_mem_calloc_2l_int(
                   gd->nxx * gd->nzz  ,size*size, -1, "car_ghost_neighbor_init");
  
  gd->c_ghost_block = (int **) fdlib_mem_calloc_2l_int(
                   gd->nxx * gd->nzz  ,size*size, -1, "car_ghost_neighbor_init");
  
  gd->c_ghostxx = ( float * ) malloc( sizeof( float ) * gdinfo->nxx * gdinfo->nzz );
  gd->c_ghostzz = ( float * ) malloc( sizeof( float ) * gdinfo->nxx * gdinfo->nzz );
  gd->c_ghostx = ( int * ) malloc( sizeof( int ) * gdinfo->nxx * gdinfo->nzz );
  gd->c_ghostz = ( int * ) malloc( sizeof( int ) * gdinfo->nxx * gdinfo->nzz );

  
  //left block,contains 3 part
  if (mympi->topoid[0]==0)
  {
    //x1 part
    for (size_t k = 0; k < gd->nzz; k++) 
    {
        for (size_t i = 0; i < gd->npoint_ghosts; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

    //z1 refion
    for (size_t k = 0; k < gd->npoint_ghosts; k++) 
    {
        for (size_t i = gdinfo->nii1 ; i <= gdinfo->nii2; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

    //z2 refion
    for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
    {
        for (size_t i = gdinfo->nii1 ; i <= gdinfo->nii2; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

  }
  
  //right block,also contains 3 part
  else if (mympi->topoid[0]==mympi->nproc-1)
  {
    //x2 part
    for (size_t k = 0; k < gd->nzz; k++) 
    {
        for (size_t i = gd->nxx - gd->npoint_ghosts; i < gd->nxx; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

    //z1 refion
    for (size_t k = 0; k < gd->npoint_ghosts; k++) 
    {
        for (size_t i = gdinfo->nii1 ; i <= gdinfo->nii2; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

    //z2 refion
    for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
    {
        for (size_t i = gdinfo->nii1 ; i <= gdinfo->nii2; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

  }

//other mpi block
  //z1 refion
  else{
    for (size_t k = 0; k < gd->npoint_ghosts; k++) 
    {
        for (size_t i = gdinfo->nii1 ; i <= gdinfo->nii2; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }

    //z2 refion
    for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
    {
        for (size_t i = gdinfo->nii1 ; i <= gdinfo->nii2; i++) 
        {
          size_t iptr = i + k * gd->nxx;//iptr of cartesian grid
          gd_func_for_cartesian_ghost_neighbor(mympi , gd , gdinfo , iptr , size);
        }
    }
  }


  return 0;
}

//this func get c_ghostxx/zz and block and iptr_loacl for each point(no matter x/z_1/2 region) in car_mpi_point 
int 
gd_func_for_cartesian_ghost_neighbor( mympi_t *mympi,gd_t *gd,gdinfo_t  *gdinfo,int iptr,int size)
{

  int *ghost_glob_x =  ( int * ) malloc( sizeof( int ) * size );//use for each car point
  int *ghost_glob_z =  ( int * ) malloc( sizeof( int ) * size );

  gd->c_ghostxx[iptr] = atan2(gd->zz2d[iptr],gd->xx2d[iptr]);
  if (gd->c_ghostxx[iptr] < 0)   //because atan2 range is -pi~pi;ci of cartesian ghost points don't equal 0
  gd->c_ghostxx[iptr] += 2*PI;

  gd->c_ghostzz[iptr]  = sqrt( gd->xx2d[iptr] * gd->xx2d[iptr] + gd->zz2d[iptr] * gd->zz2d[iptr]);

  for (size_t ii =0; ii < gdinfo->num_total_grid_x + 2* gd->npoint_ghosts ;ii++)
  {
    if (gd->c_ghostxx[iptr] <= gd->global_x2d_ghost[ii])
    {
        gd->c_ghostx[iptr] = ii;
        for (int m =0; m< size; m++) {
            ghost_glob_x[m] = ii-size/2+m;}
        break;
    }
    
  }

  //find kk only in c_ghostx cow
  for (size_t kk =0; kk < gdinfo->num_total_grid_z ;kk++)
  {
      size_t iptr_polar = ghost_glob_x[size/2] + kk * (gdinfo->num_total_grid_x + 2* gd->npoint_ghosts);
      if (gd->c_ghostzz[iptr] <= gd->global_z2d_ghost[iptr_polar])//
      {
        gd->c_ghostz[iptr] = kk;
        for (int n =0; n< size; n++) {
            ghost_glob_z[n] = kk-size/2+n;}
        break;
      }                
  }

  //change ghost_global to ghost_local and get block indx for each size*size point
  int nproc = mympi->nproc;
  for (int m =0; m< size; m++)  {
      for (int n =0; n< size; n++) {
        //search block
        for(int i=1 ; i<nproc; i++){
            if (ghost_glob_x[m] < mympi->displs_polar_ni[i] + gd->npoint_ghosts){
            gd->c_ghost_block[iptr][m+size*n] = i-1;
            break;}
            else{
            gd->c_ghost_block[iptr][m+size*n] = nproc-1; }
          }
        
        //find local iptr to size*size,this iptr contains ghost points.NOTE ghost_glob_x contains 6 cow ghost at both ends
        gd->c_ghost_lociptr[iptr][m+size*n] =ghost_glob_x[m] - mympi->displs_polar_ni[gd->c_ghost_block[iptr][m+size*n]]  
                        + (ghost_glob_z[n]+gd->npoint_ghosts)* 
                        (mympi-> each_ni_polar[gd->c_ghost_block[iptr][m+size*n]] +2*gd->npoint_ghosts);

      }
  }
  //check car_neigh block != -1
  for (int m =0; m< size; m++)  {
    for (int n =0; n< size; n++) {
        if(gd->c_ghost_block[iptr][m+size*n] ==-1 ){
          fprintf(stdout,"!!!!!!!  error   !!!!! \n car_ghost_neigh block can't equal -1 in mpi %d and iptr %d\n",mympi->myid,iptr);// error
          exit(-1);
        }
    }
  }

  free(ghost_glob_x);
  free(ghost_glob_z);
  return 0;
}

//to get whole gd_ghost ,include mpi ghost, contains recv from which block and iptr, 
//also cal every glob_recv_from belong to which block(for mpi send)  
//also mpi_pack to get send,recv indx
int
gd_gather_ghost_global(gd_t  *gd,gdinfo_t  *gdinfo,mympi_t *mympi)
{

  int size = gdinfo->size_of_interp;
  int nghost = gdinfo->npoint_ghosts;
  int nproc = mympi->nproc;
  int num_x = gdinfo->num_total_grid_x + 2*nghost*nproc;
  int num_xx = gdinfo->num_total_grid_car + 2*nghost*nproc;
  int ni  = gdinfo->ni;
  int nii = gdinfo->nii;
  int nk  = gdinfo->nk;
  int nkk = gdinfo->nkk;
  int nzz = gdinfo->nzz;
  int *displs_polar   = ( int * ) malloc( sizeof( int ) * nproc );
  int *displs_car    = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count_polar = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count_car  = ( int * ) malloc( sizeof( int ) * nproc );

  for(int i=0 ; i<nproc; i++){
    Count_polar[i] = (mympi->allCount_polar[i] /nk + 2*nghost)* nghost *size *size;
    Count_car[i]  = (mympi->allCount_car[i] /nkk + 2*nghost)* nzz *size *size; 
    displs_polar[i] = (mympi->displs_polar[i] /nk + 2*nghost*i)* nghost *size *size;
    displs_car[i]  = (mympi->displs_car[i] /nkk + 2*nghost*i)* nzz *size *size; 
  }


  //gather polar ghost grid
  gd->p_glob_ghost_need_lociptr = (int *) fdlib_mem_calloc_1d_int(
                   num_x * gd->npoint_ghosts * size*size, -1, "polar_ghost_glob_init");
  
  gd->p_glob_ghost_need_block = (int *) fdlib_mem_calloc_1d_int(
                   num_x * gd->npoint_ghosts * size*size, -1, "polar_ghost_glob_init");

  gd->p_glob_ghost_belong = (int *) fdlib_mem_calloc_1d_int(
                   num_x * gd->npoint_ghosts * size*size, -1, "polar_ghost_glob_init");
   
  int *p_loc_block = ( int * ) malloc( sizeof( int ) * gd->nx * nghost *size *size );//change from 2D to 1D
  int *p_loc_iptr  = ( int * ) malloc( sizeof( int ) * gd->nx * nghost *size *size);
  for (size_t k = 0; k < gdinfo->nk1; k++) {
      for (size_t i = 0; i < gd->nx; i++) { 
        int iptr = i + k * gd->nx;
        for (int m =0; m< size; m++)  {
            for (int n =0; n< size; n++) {
              p_loc_block[size*size*iptr + m+size*n ] = gd->p_ghost_block[iptr][m+size*n];
              p_loc_iptr [size*size*iptr + m+size*n ] = gd->p_ghost_lociptr[iptr][m+size*n];
            }
        }
      }
  }
        
  MPI_Allgatherv(p_loc_block , gd->nx*nghost*size*size , MPI_INT , gd->p_glob_ghost_need_block  ,
                 Count_polar ,displs_polar, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(p_loc_iptr , gd->nx*nghost*size*size , MPI_INT , gd->p_glob_ghost_need_lociptr  ,
                 Count_polar ,displs_polar, MPI_INT , MPI_COMM_WORLD);
    //get block belongs of iptr in glob_ghost
  for(int iptr =0;iptr <num_x * gd->npoint_ghosts * size*size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs_polar[i]){
      gd->p_glob_ghost_belong[iptr] = i-1;
      break;}
      else{
      gd->p_glob_ghost_belong[iptr] = nproc-1; }
    }
  }
  

  //gather car ghost grid
  gd->c_glob_ghost_need_lociptr = (int *) fdlib_mem_calloc_1d_int(
                   num_xx * nzz * size*size, -1, "car_ghost_glob_init");
  
  gd->c_glob_ghost_need_block = (int *) fdlib_mem_calloc_1d_int(
                   num_xx * nzz * size*size, -1, "car_ghost_glob_init");
                   
  gd->c_glob_ghost_belong = (int *) fdlib_mem_calloc_1d_int(
                   num_xx * nzz * size*size, -1, "car_ghost_glob_init");

  int *c_loc_block = ( int * ) malloc( sizeof( int ) * gd->nxx * nzz *size *size );//change from 2D to 1D
  int *c_loc_iptr  = ( int * ) malloc( sizeof( int ) * gd->nxx * nzz *size *size );
  for (size_t k = 0; k < nzz; k++) {
      for (size_t i = 0; i < gd->nxx; i++) { 
        int iptr = i + k * gd->nxx;
        for (int m =0; m< size; m++)  {
            for (int n =0; n< size; n++) {
              c_loc_block[size*size*iptr + m+size*n ] = gd->c_ghost_block[iptr][m+size*n];
              c_loc_iptr [size*size*iptr + m+size*n ] = gd->c_ghost_lociptr[iptr][m+size*n];
            }
        }
      }
  }

  MPI_Allgatherv(c_loc_block , gd->nxx * nzz *size *size , MPI_INT , gd->c_glob_ghost_need_block  ,
                 Count_car ,displs_car, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(c_loc_iptr ,  gd->nxx * nzz *size *size , MPI_INT , gd->c_glob_ghost_need_lociptr  ,
                 Count_car ,displs_car, MPI_INT , MPI_COMM_WORLD);
  
    //get block belongs of iptr in glob_ghost
  for(int iptr =0;iptr <num_xx * nzz * size*size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs_car[i]){
      gd->c_glob_ghost_belong[iptr] = i-1;
      break;}
      else{
      gd->c_glob_ghost_belong[iptr] = nproc-1; }
    }
  }



  //for mpi_package, find send_recv package of this block and num_iptr to each block
  int *p_myblock2block_all   = ( int * ) malloc( sizeof( int ) * nproc );
  int *p_myblock2block_niptr_all   = ( int * ) malloc( sizeof( int ) * nproc );
  int *c_myblock2block_all   = ( int * ) malloc( sizeof( int ) * nproc );
  int *c_myblock2block_niptr_all   = ( int * ) malloc( sizeof( int ) * nproc );

  int *p_block2myblock_all   = ( int * ) malloc( sizeof( int ) * nproc );
  int *p_block2myblock_niptr_all   = ( int * ) malloc( sizeof( int ) * nproc );
  int *c_block2myblock_all   = ( int * ) malloc( sizeof( int ) * nproc );
  int *c_block2myblock_niptr_all   = ( int * ) malloc( sizeof( int ) * nproc );

   //polar send
  for(int iptr =0;iptr <num_xx * nzz * size*size;iptr ++)
  {
    if (gd->c_glob_ghost_need_block[iptr]==mympi->myid){ //need myblock
      p_myblock2block_all[gd->c_glob_ghost_belong[iptr]] = 1;
      p_myblock2block_niptr_all[gd->c_glob_ghost_belong[iptr]] ++ ;
    }
  }
      //remove block of not send to
  gd->nblock_psend=0;
  for(int i=0 ; i<nproc; i++)
  {
     if (p_myblock2block_all[i] ==1 )
     {
      gd->nblock_psend++;
     }
  }

  gd->p_myblock2block = (int *) fdlib_mem_calloc_1d_int(
                   gd->nblock_psend, -1, "indx of polar_myblock send to block");
  gd->p_myblock2block_niptr = (int *) fdlib_mem_calloc_1d_int(
                   gd->nblock_psend, -1, "indx of polar_myblock send to block");

  int j=0;
  for(int i=0 ; i<nproc; i++)
  {
     if (p_myblock2block_all[i] ==1 )
     {
       gd->p_myblock2block[j] =i;
       gd->p_myblock2block_niptr[j] = p_myblock2block_niptr_all[i];
       j++;
     }
  }

   //polar recv
    for (size_t k = 0; k < gdinfo->nk1; k++) 
    {
        for (size_t i =  0; i < gdinfo->nx; i++) 
        {
          int iptr = i + k*gd->nx;
          for (int m =0; m< size; m++)  {
            for (int n =0; n< size; n++) { //for each point in p_ghost_block
              for(int i=0 ; i<nproc; i++)
                {
                  if (gd->p_ghost_block[iptr][m+size*n] ==i)
                  {
                    p_block2myblock_all[i] = 1;
                    p_block2myblock_niptr_all[i] ++ ;
                  }
                }
            }
          }
        }
    }

       //remove block of not recv from
    gd->nblock_precv=0;
    for(int i=0 ; i<nproc; i++)
    {
      if (p_block2myblock_all[i] ==1 )
      {
        gd->nblock_precv++;
      }
    }

    gd->p_block2myblock = (int *) fdlib_mem_calloc_1d_int(
                    gd->nblock_precv, -1, "indx of polar_myblock recv from block");
    gd->p_block2myblock_niptr = (int *) fdlib_mem_calloc_1d_int(
                    gd->nblock_precv, -1, "indx of polar_myblock recv from block");

    j=0;
    for(int i=0 ; i<nproc; i++)
    {
      if (p_block2myblock_all[i] ==1 )
      {
        gd->p_block2myblock[j] =i;
        gd->p_block2myblock_niptr[j] = p_block2myblock_niptr_all[i];
        j++;
      }
    }

   /* //check polar_0 recvive
    if (mympi->myid == 0)
    for(int i=0 ; i<gd->nblock_precv; i++)
    {
      fprintf(stdout,"%d indx in block0_polar recv from block %d of %d points\n",i,gd->p_block2myblock[i],gd->p_block2myblock_niptr[i]);
    }*/


   //cartesian send
  for(int iptr =0;iptr <num_x * gd->npoint_ghosts * size*size;iptr ++)
  {
    if (gd->p_glob_ghost_need_block[iptr]==mympi->myid){ //need myblock
      c_myblock2block_all[gd->p_glob_ghost_belong[iptr]] = 1;
      c_myblock2block_niptr_all[gd->p_glob_ghost_belong[iptr]] ++ ;
    }
  }
      //remove block of not send to
  gd->nblock_csend=0;
  for(int i=0 ; i<nproc; i++)
  {
     if (c_myblock2block_all[i] ==1 )
     {
      gd->nblock_csend++;
     }
  }
  

  gd->c_myblock2block = (int *) fdlib_mem_calloc_1d_int(
                   gd->nblock_csend, -1, "indx of car_myblock send to block");
  gd->c_myblock2block_niptr = (int *) fdlib_mem_calloc_1d_int(
                   gd->nblock_csend, -1, "indx of car_myblock send to block");

  j=0;
  for(int i=0 ; i<nproc; i++)
  {
     if (c_myblock2block_all[i] ==1 )
     {
       gd->c_myblock2block[j] =i;
       gd->c_myblock2block_niptr[j] = c_myblock2block_niptr_all[i];
       j++;
     }
  }
  

  //cartesian recv
    for (size_t k = 0; k < nzz; k++) 
    {
      for (size_t i = 0; i < gd->nxx; i++) 
      { 
        int iptr = i + k * gd->nxx;
          for (int m =0; m< size; m++)  {
            for (int n =0; n< size; n++) { //for each point in c_ghost_block
              for(int i=0 ; i<nproc; i++)
                {
                  if (gd->c_ghost_block[iptr][m+size*n] ==i)
                  {
                    c_block2myblock_all[i] = 1;
                    c_block2myblock_niptr_all[i] ++ ;
                  }
                }
            }
          }
        }
    }

        //remove block of not recv from
    gd->nblock_crecv=0;
    for(int i=0 ; i<nproc; i++)
    {
      if (c_block2myblock_all[i] ==1 )
      {
        gd->nblock_crecv++;
      }
    }

    gd->c_block2myblock = (int *) fdlib_mem_calloc_1d_int(
                    gd->nblock_crecv, -1, "indx of car_myblock recv from block");
    gd->c_block2myblock_niptr = (int *) fdlib_mem_calloc_1d_int(
                    gd->nblock_crecv, -1, "indx of car_myblock recv from block");

    j=0;
    for(int i=0 ; i<nproc; i++)
    {
      if (c_block2myblock_all[i] ==1 )
      {
        gd->c_block2myblock[j] =i;
        gd->c_block2myblock_niptr[j] = c_block2myblock_niptr_all[i];
        j++;
      }
    }
  
 
  free(p_loc_block);
  free(p_loc_iptr);
  free(c_loc_block);
  free(c_loc_iptr);
  free(displs_polar);
  free(displs_car);
  free(Count_polar);
  free(Count_car);
  free(p_myblock2block_niptr_all);
  free(p_myblock2block_all);
  free(c_myblock2block_niptr_all);
  free(c_myblock2block_all);
  free(p_block2myblock_niptr_all);
  free(p_block2myblock_all);
  free(c_block2myblock_niptr_all);
  free(c_block2myblock_all);
  return 0;
}


//to find which iptr is send to which block's which iptrmn
int
gd_find_local_send(mympi_t *mympi,gd_t  *gd,gdinfo_t  *gdinfo)
{

  int size = gdinfo->size_of_interp;
  int nghost = gdinfo->npoint_ghosts;
  int nproc = mympi->nproc;
  int ni  = gdinfo->ni;
  int nii = gdinfo->nii;
  int nx  = gd->nx;
  int nz  = gd->nz;
  int nk  = gdinfo->nk;
  int nkk = gdinfo->nkk;
  int nxx = gd->nxx;
  int nzz = gd->nzz;
  int num_x = gdinfo->num_total_grid_x + 2*nghost*nproc;
  int num_xx = gdinfo->num_total_grid_car + 2*nghost*nproc;

  //find polar send
  int psend_niptr_max = 1;

  for (int iblock = 0; iblock < gd->nblock_psend; iblock++)
  {
    if (gd->p_myblock2block_niptr[iblock] >= psend_niptr_max)
    psend_niptr_max = gd->p_myblock2block_niptr[iblock];
  }

  gd->p_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   gd->nblock_psend ,psend_niptr_max, -1, "polar_local_send_init");
  gd->p_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   gd->nblock_psend ,psend_niptr_max, -1, "polar_local_send_init");
  int **p_send = (int **) fdlib_mem_calloc_2l_int(
                   gd->nblock_psend ,psend_niptr_max, -1, "polar_local_send_init");//temporary,need change to block+iptr+m+n


  for (int iblock = 0; iblock < gd->nblock_psend; iblock++)
  {

    size_t iptr_p = 0;
    for (size_t i = 0;i < num_xx * nzz * size*size;i++)
    {
      if(gd->c_glob_ghost_need_block[i] == mympi->myid && gd->c_glob_ghost_belong[i] == gd->p_myblock2block[iblock])
      {
        p_send[iblock][iptr_p] = i;
        gd->p_myiptr_send[iblock][iptr_p] = gd->c_glob_ghost_need_lociptr[i];
        iptr_p ++;
      }
    }
    
    //check if all points are found
    if (iptr_p != gd->p_myblock2block_niptr[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find polar send error when block %d to car_%d,only send %d points, not enough of %d points\n",
              mympi->myid,gd->p_myblock2block[iblock],iptr_p,gd->p_myblock2block_niptr[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd->p_myblock2block_niptr[iblock]; iptr++) 
    {
      //find block
      int p_send2block;
      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (p_send[iblock][iptr]< (mympi->displs_car[iproc] /nkk + 2*nghost*iproc)* nzz *size *size){
          p_send2block = iproc-1;
          break;}
        else{
          p_send2block = nproc-1; }
      }
      //find iptr
      int iptrmn = p_send[iblock][iptr]- (mympi->displs_car[p_send2block] /nkk + 2*nghost* p_send2block)* nzz*size*size;
      gd->p_send2iptrmn[iblock][iptr] = iptrmn;

    }
  }

  //find car send
  int csend_niptr_max = 1;

  for (int iblock = 0; iblock < gd->nblock_csend; iblock++)
  {
    if (gd->c_myblock2block_niptr[iblock] >= csend_niptr_max)
    csend_niptr_max = gd->c_myblock2block_niptr[iblock];
  }

  gd->c_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   gd->nblock_csend ,csend_niptr_max, -1, "car_local_send_init");
  gd->c_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   gd->nblock_csend ,csend_niptr_max, -1, "car_local_send_init");
  int **c_send = (int **) fdlib_mem_calloc_2l_int(
                   gd->nblock_csend ,csend_niptr_max, -1, "car_local_send_init");//temporary,need change to block+iptr+m+n


  for (int iblock = 0; iblock < gd->nblock_csend; iblock++)
  {

    size_t iptr_c = 0;
    for (size_t i = 0;i < num_x * gd->npoint_ghosts * size*size;i++)
    {
      if(gd->p_glob_ghost_need_block[i] == mympi->myid && gd->p_glob_ghost_belong[i] == gd->c_myblock2block[iblock])
      {
        c_send[iblock][iptr_c] = i;
        gd->c_myiptr_send[iblock][iptr_c] = gd->p_glob_ghost_need_lociptr[i];
        iptr_c ++;
      }
    }
    
    //check if all points are found
    if (iptr_c != gd->c_myblock2block_niptr[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find car send error when block %d to polar_%d,only send %d points, not enough of %d points\n",
              mympi->myid,gd->c_myblock2block[iblock],iptr_c,gd->c_myblock2block_niptr[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd->c_myblock2block_niptr[iblock]; iptr++) 
    {
      //find block
      int c_send2block;
      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (c_send[iblock][iptr]< (mympi->displs_polar[iproc] /nk + 2*nghost*iproc)* nghost *size *size){
          c_send2block = iproc-1;
          break;}
        else{
          c_send2block = nproc-1; }
      }
      //find iptr
      int iptrmn = c_send[iblock][iptr]- (mympi->displs_polar[c_send2block] /nk + 2*nghost* c_send2block)* nghost *size*size;
      gd->c_send2iptrmn[iblock][iptr] = iptrmn;

    }
  }
  
  for(int i=0;i<gd->nblock_psend;i++)
	{
		free(p_send[i]);
	}
	free(p_send);

  for(int i=0;i<gd->nblock_csend;i++)
	{
		free(c_send[i]);
	}
	free(c_send);

                    
  return 0;
}  


/*
 * print for QC
 */

int
gd_print(gdinfo_t *gdinfo)
{  
  fprintf(stdout, "\n");  
  fprintf(stdout, "<<<<<<<<<<   gd info   >>>>>>>>>>\n");
  fprintf(stdout, "\n");
  fprintf(stdout, " ntheta    = %-10d\n", gdinfo->nx);
  fprintf(stdout, " nrho    = %-10d\n", gdinfo->nz);
  fprintf(stdout, " nxx    = %-10d\n", gdinfo->nxx);
  fprintf(stdout, " nzz    = %-10d\n", gdinfo->nzz);
  fprintf(stdout, " ni    = %-10d\n", gdinfo->ni);
  fprintf(stdout, " nk    = %-10d\n", gdinfo->nk);

  fprintf(stdout, " ni1   = %-10d\n", gdinfo->ni1);
  fprintf(stdout, " ni2   = %-10d\n", gdinfo->ni2);
  fprintf(stdout, " nk1   = %-10d\n", gdinfo->nk1);
  fprintf(stdout, " nk2   = %-10d\n", gdinfo->nk2);

  fprintf(stdout, " ni1_to_glob_phys0   = %-10d\n", gdinfo->gni1);
  fprintf(stdout, " ni2_to_glob_phys0   = %-10d\n", gdinfo->gni2);
  fprintf(stdout, " nii1_to_glob_phys0   = %-10d\n", gdinfo->gnii1);
  fprintf(stdout, " nii2_to_glob_phys0   = %-10d\n", gdinfo->gnii2);

  return 0;
}



