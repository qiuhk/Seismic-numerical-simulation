#ifndef WF_EL_1ST_H
#define WF_EL_1ST_H

#include "gd_t.h"
#include "gd_info.h"

/*************************************************
 * structure
 *************************************************/

/*
 * wavefield structure
 */

// wavefield variables elastic 1st eqn: vel + stress
typedef struct {
  float *v4d; // allocated mpi_block var include 4 times
  float *global_v4d; // allocated whole var in 1 time
  float **storage_for_polar_interp;
  float **storage_for_car_interp;//only allocate var used for interp

  int n1, n2, n3, n4, n5;
  int nx, nz, nxx, nzz, ncmp, nlevel, nmaxwell;
  int visco_type;

  size_t siz_iz;
  size_t siz_icmp;
  size_t siz_ilevel;

  size_t *cmp_pos;
  char  **cmp_name;
  size_t *level_pos;

  size_t Vx_pos;
  size_t Vz_pos;
  size_t Txx_pos;
  size_t Tzz_pos;
  size_t Txz_pos;

  // sequential index 0-based
  size_t Vx_seq;
  size_t Vz_seq;
  size_t Txx_seq;
  size_t Tzz_seq;
  size_t Txz_seq;

  // vis 
  size_t *Jxx_pos;
  size_t *Jzz_pos;
  size_t *Jxz_pos;

  size_t *Jxx_seq;
  size_t *Jzz_seq;
  size_t *Jxz_seq;

} wav_t;

/*************************************************
 * function prototype
 *************************************************/

int 
wav_init(gdinfo_t *gdinfo,
         wav_t *V,
         int number_of_levels,
         int visco_type,
         int nmaxwell);


int
wav_check_value(float *restrict w, wav_t *wav,int it);

int
wav_gather_global(gd_t  *gd,gdinfo_t  *gdinfo,wav_t *wav, float *restrict w4d, mympi_t *mympi);

float 
Distance2D_polar(float x, float y, float *xArr, float *yArr, float *zArr, int size,size_t iptr);

float 
Distance2D_cartesian(float x, float y, float *xArr, float *yArr, float *zArr, int size,size_t iptr);

float 
lagrange2D(float x, float y, float *xArr, float *yArr, float *zArr, int size,size_t iptr); 

int
wav_zero_edge(gdinfo_t *gdinfo,wav_t *wav,
              float *restrict w4d);

int
wave_changevalue_ghost(gdinfo_t *gdinfo,gd_t  *gd, wav_t *wav, float *restrict w4d, mympi_t *mympi);

int
wav_mpi_change_ghostvalue_car(gd_t *gd,wav_t *wav,float *restrict var,mympi_t *mympi,int iptr,int size,int icmp,int tag_coeff);

int
wav_get_interp_value(gd_t  *gd,gdinfo_t  *gdinfo,wav_t *wav, float *restrict w4d, mympi_t *mympi);

int
get_carghost_neigh(gd_t* gd,gdinfo_t* gdinfo,wav_t *wav,float *restrict w4d,float *restrict xArr,float *restrict zArr,
                  float *restrict value,int iptr,int size,int icmp);

int 
wav_ac_init(gd_t *gd,
            wav_t *V,
            int number_of_levels);

#endif
