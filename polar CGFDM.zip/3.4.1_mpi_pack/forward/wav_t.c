/*********************************************************************
 * wavefield for 3d elastic 1st-order equations
 **********************************************************************/
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "constants.h"
#include "fdlib_mem.h"
#include "wav_t.h"

int 
wav_init(gdinfo_t *gdinfo,
         wav_t *V,
         int number_of_levels,
         int visco_type,
         int nmaxwell)  //number_of_levels=num_rk_stages
{
  int ierr = 0;

  // Vx,Vz,Txx,Tzz,Txz
  V->ncmp = 5;

  V->nx   = gdinfo->nx;
  V->nz   = gdinfo->nz;
  V->nxx   = gdinfo->nxx;
  V->nzz   = gdinfo->nzz;
  V->nlevel = number_of_levels;//number_of_levels=4

  V->siz_iz   = V->nx;
  V->siz_icmp  = V->nx * V->nz + V->nxx*V->nzz;

  V->nmaxwell = nmaxwell;//nmaxwell=3
  V->visco_type = visco_type ;

  if(visco_type == CONST_VISCO_GMB)//yes
  {
    V->ncmp += 3*nmaxwell;  // Jxx Jzz Jxz
  }

  V->siz_ilevel = V->siz_icmp * V->ncmp;

  // vars
  // 2 Vi, 3 Tij, 4 rk stages
  V->v4d = (float *) fdlib_mem_calloc_1d_float(V->siz_ilevel * V->nlevel,
                        0.0, "v4d, wf_el3d_1st");

  int num_gd_polar = (gdinfo->num_total_grid_x +2*gdinfo->fdx_nghosts) * gdinfo->num_total_grid_z ; //NOTE : polar gd contians 6 ghost layer
  int num_gd_car   = gdinfo->num_total_grid_car * gdinfo->num_total_grid_car;
  int size = gdinfo->size_of_interp;

  V->global_v4d = (float *) fdlib_mem_calloc_1d_float( (num_gd_polar + num_gd_car) * V->ncmp,   
                        0.0, "v4d, wf_el3d_glob_1st");
  V->storage_for_polar_interp = (float **) fdlib_mem_calloc_2l_float( V->ncmp, gdinfo->nx*gdinfo->fdx_nghosts*
                        size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");
  V->storage_for_car_interp   = (float **) fdlib_mem_calloc_2l_float( V->ncmp, gdinfo->nxx*gdinfo->nzz*
                        size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");

  // position of each var
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                      V->ncmp, 0, "w3d_pos, wf_el3d_1st");
  // name of each var
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(
                      V->ncmp, CONST_MAX_STRLEN, "w3d_name, wf_el3d_1st");
  if (visco_type == CONST_VISCO_GMB)
  {
    V->Jxx_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                nmaxwell, 0, "Jxx_pos, wf_el3d_1st");
    V->Jzz_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                nmaxwell, 0, "Jzz_pos, wf_el3d_1st");
    V->Jxz_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                nmaxwell, 0, "Jxz_pos, wf_el3d_1st");
    V->Jxx_seq = (size_t *) fdlib_mem_calloc_1d_sizet(
                nmaxwell, 0, "Jxx_seq, wf_el3d_1st");
    V->Jzz_seq = (size_t *) fdlib_mem_calloc_1d_sizet(
                nmaxwell, 0, "Jzz_seq, wf_el3d_1st");
    V->Jxz_seq = (size_t *) fdlib_mem_calloc_1d_sizet(
                nmaxwell, 0, "Jxz_seq, wf_el3d_1st");
  }

  // set value,means every pointer's position
  for (int icmp=0; icmp < V->ncmp; icmp++)
  {
    cmp_pos[icmp] = icmp * V->siz_icmp;
  }

  // set values
  int icmp = 0;

  /*
   * 0-3: Vx,Vy,Vz
   * 4-9: Txx,Tyy,Tzz,Txz,Tyz,Txy
   */

  sprintf(cmp_name[icmp],"%s","Vx");
  V->Vx_pos = cmp_pos[icmp];
  V->Vx_seq = 0;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Vz");
  V->Vz_pos = cmp_pos[icmp];
  V->Vz_seq = 1;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Txx");
  V->Txx_pos = cmp_pos[icmp];
  V->Txx_seq = 2;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Tzz");
  V->Tzz_pos = cmp_pos[icmp];
  V->Tzz_seq = 3;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Txz");
  V->Txz_pos = cmp_pos[icmp];
  V->Txz_seq = 4;
  icmp += 1;

  if (visco_type == CONST_VISCO_GMB) 
  {
    for(int i=0; i < nmaxwell; i++)
    {
      sprintf(cmp_name[icmp],"%s%d","Jxx",i+1);
      V->Jxx_pos[i] = cmp_pos[icmp];//icmp counts from 5
      V->Jxx_seq[i] = icmp;
      icmp += 1;
  
      sprintf(cmp_name[icmp],"%s%d","Jzz",i+1);
      V->Jzz_pos[i] = cmp_pos[icmp];
      V->Jzz_seq[i] = icmp;
      icmp += 1;
  
      sprintf(cmp_name[icmp],"%s%d","Jxz",i+1);
      V->Jxz_pos[i] = cmp_pos[icmp];
      V->Jxz_seq[i] = icmp;
      icmp += 1;
    }
  }
  // set pointer;
  V->cmp_pos  = cmp_pos;
  V->cmp_name = cmp_name;

  return ierr;
}

int 
wav_ac_init(gd_t *gd,
            wav_t *V,
            int number_of_levels)
{
  int ierr = 0;

  // Vx,Vz,P
  V->ncmp = 3;

  V->nx   = gd->nx;
  V->nz   = gd->nz;
  V->nlevel = number_of_levels;

  V->siz_iz   = V->nx;
  V->siz_icmp  = V->nx * V->nz;
  V->siz_ilevel = V->siz_icmp * V->ncmp;

  // vars
  // 2 Vi, 1 P, 4 rk stages
  V->v4d = (float *) fdlib_mem_calloc_1d_float(V->siz_ilevel * V->nlevel,
                        0.0, "v5d, wf_ac3d_1st");
  // position of each var
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                      V->ncmp, 0, "w3d_pos, wf_ac3d_1st");
  // name of each var
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(
                      V->ncmp, CONST_MAX_STRLEN, "w3d_name, wf_ac3d_1st");
  
  // set value
  for (int icmp=0; icmp < V->ncmp; icmp++)
  {
    cmp_pos[icmp] = icmp * V->siz_icmp;
  }

  // set values
  int icmp = 0;

  /*
   * 0-1: Vx,Vz
   * 2: P
   */

  sprintf(cmp_name[icmp],"%s","Vx");
  V->Vx_pos = cmp_pos[icmp];
  V->Vx_seq = 0;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Vz");
  V->Vz_pos = cmp_pos[icmp];
  V->Vz_seq = 1;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","P");
  V->Txx_pos = cmp_pos[icmp];
  V->Txx_seq = 2;
  icmp += 1;

  // set pointer
  V->cmp_pos  = cmp_pos;
  V->cmp_name = cmp_name;

  return ierr;
}

int
wav_check_value(float *restrict w, wav_t *wav,int it)
{
  int ierr = 0;

  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    float *ptr = w + icmp * wav->siz_icmp;
    for (size_t iptr=0; iptr < wav->siz_icmp; iptr++)
    {
      if (ptr[iptr] != ptr[iptr])
      {
        fprintf(stderr, "ERROR: NaN occurs at time=%d , point_iptr=%d ,variable_icmp=%d\n",it, iptr, icmp);
        fflush(stderr);
        exit(-1);
      }
    }
  }

  return ierr;
}

//to get whole gd's wave in 1 time
int
wav_gather_global(gd_t  *gd,gdinfo_t  *gdinfo,wav_t *wav, float *restrict w4d, mympi_t *mympi)
{

  int ni = gdinfo->ni;
  int nk = gdinfo->nk;
  int n_ghost = gd->npoint_ghosts;
  int nii = gdinfo->nii;
  int nkk = gdinfo->nkk;  
  int nproc = mympi->nproc;
  int num_total_nx = gdinfo->num_total_grid_x + 2*n_ghost;
  int num_gd_polar = num_total_nx * gdinfo->num_total_grid_z;
  int num_gd_2gd = num_gd_polar + gdinfo->num_total_grid_car * gdinfo->num_total_grid_car;
  
  //pointers don't finnal
  float *local_polar = ( float * ) malloc( sizeof( float ) * ni * nk ); //exclude ghost points of mpi block
  float *local_car = ( float * ) malloc( sizeof( float ) * nii * nkk ); //exclude ghost points of mpi block
  float *var_glob_polar = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_x * gdinfo->num_total_grid_z ); 
  float *var_glob_car = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_car * gdinfo->num_total_grid_car); //unordered global
  float *var_glob_polar_oedered = ( float * ) malloc( sizeof( float ) * gdinfo->num_total_grid_x * gdinfo->num_total_grid_z ); 
  
  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    //block pointer
    float *restrict var        = w4d + wav->cmp_pos[icmp]; //block has 2 gd
    float *restrict var_polar  = var;
    float *restrict var_car    = var + gdinfo->nx * gdinfo->nz;
    
    //global pointer
    float *restrict var_glob       =  wav->global_v4d + num_gd_2gd *icmp;
    float *restrict var_glob_polar_ordered_ghost =  var_glob;
    float *restrict var_glob_car_ordered   =  var_glob + num_gd_polar ; //global_car don't need ghost

    //gather polar gd
    for (int i = 0; i < ni; i++)
    {
      for (int k = 0; k < nk; k++)
      {
        int iptr1 = n_ghost*(ni +2*n_ghost) + n_ghost*(2*k +1) + i+ k*ni;
        local_polar[i+k*ni] = var_polar[iptr1];
      }
    }
    MPI_Allgatherv(local_polar , ni*nk , MPI_FLOAT , var_glob_polar , mympi->allCount_polar ,mympi->displs_polar, MPI_FLOAT , MPI_COMM_WORLD);

    //gather cartesian gd
    for (int i = 0; i < nii; i++)
    {
      for (int k = 0; k < nkk; k++)
      {
        int iptr2 = n_ghost*(nii +2*n_ghost) + n_ghost*(2*k +1) + i+ k*nii;
        local_car[i+k*nii] = var_car[iptr2];
      }
    }
    MPI_Allgatherv(local_car , nii*nkk , MPI_FLOAT , var_glob_car , mympi->allCount_car , mympi->displs_car, MPI_FLOAT , MPI_COMM_WORLD);

    //sort var_glob_polar in right order(var_glob_polar -> var_glob_polar_oedered)
    for(int k=0 ; k<nk ; k++)
    {
      for(int p=0 ; p<nproc ; p++)
      {
        //start pointer of each block_line_piece
        float *var_polar_block_line = var_glob_polar_oedered + k * gdinfo->num_total_grid_x + mympi->displs_polar_ni[p];
        for(int i=0 ; i< mympi->each_ni_polar[p] ; i++)
        {
          var_polar_block_line [i] = var_glob_polar [ mympi->displs_polar[p] + k * mympi->each_ni_polar[p] +i];
        }
      }
    }

    //sort var_glob_car in right order(var_glob_car -> var_glob_car_ordered)
    for(int k=0 ; k<nkk ; k++)
    {
      for(int p=0 ; p<nproc ; p++)
      {
        //start pointer of each block_line_piece
        float *var_car_block_line = var_glob_car_ordered + k * gdinfo->num_total_grid_car + mympi->displs_car_nii[p];
        for(int i=0 ; i< mympi->each_nii_car[p] ; i++)
        {
          var_car_block_line [i] = var_glob_car[ mympi->displs_car[p] + k * mympi->each_nii_car[p] +i];
        }
      }
    }

    //give var_glob_polar_oedered 6 nghost layers to var_glob_polar_ordered_ghost for interp
    for (int i = n_ghost; i < gdinfo->num_total_grid_x + n_ghost; i++)
    {
      for (int k = 0; k < gdinfo->num_total_grid_z; k++)
      {
        int iptr = i + k*num_total_nx;
        int iptr1 = i-3+ k*gdinfo->num_total_grid_x;
        var_glob_polar_ordered_ghost[iptr] =  var_glob_polar_oedered[iptr1];
      }
    }

    for (size_t k = 0; k < gdinfo->num_total_grid_z; k++)
    {
        //left
        for (size_t i = 0; i < n_ghost; i++)
        {
          size_t iptr = i + k * num_total_nx;
          var_glob_polar_ordered_ghost[iptr] = var_glob_polar_ordered_ghost[iptr+ gdinfo->num_total_grid_x ] ;
        }
        //right
        for (size_t i = num_total_nx - n_ghost; i < num_total_nx; i++)
        {
          size_t iptr = i + k * num_total_nx;
          var_glob_polar_ordered_ghost[iptr] = var_glob_polar_ordered_ghost[iptr- gdinfo->num_total_grid_x ] ;
        }
    }

  }
  
  free(local_polar);
  free(local_car);
  free(var_glob_polar);
  free(var_glob_car);
  free(var_glob_polar_oedered);

  return 0;
}

int
wav_mpi_change_ghostvalue_car(gd_t *gd,wav_t *wav,float *restrict var,mympi_t *mympi,int iptr,int size,int icmp,int num_2gd)
{
  
  for (int m =0; m< size; m++)  {
      for (int n =0; n< size; n++) {
          int tag = num_2gd*gd->c_ghost_block[iptr][n*size +m] + gd->c_ghost_lociptr[iptr][n*size +m];
          MPI_Irecv(&wav->storage_for_car_interp[icmp][iptr*size*size+m+size*n], 1 , MPI_FLOAT, gd->c_ghost_block[iptr][m+size*n], 
                    tag, MPI_COMM_WORLD,&mympi->pair_car_ghost_r_reqs[m+n*size]);
          MPI_Wait(&mympi->pair_car_ghost_r_reqs[m+n*size], MPI_STATUS_IGNORE);

       }
  }

  return 0;
}

//get size*size value using MPI ,first send then recv
int
wav_get_interp_value(gd_t *gd,gdinfo_t  *gdinfo,wav_t *wav, float *restrict w4d, mympi_t *mympi)
{
  
  int nghost = gdinfo->npoint_ghosts;
  int size = gdinfo->size_of_interp;
  int nproc = mympi->nproc;
  int nzz = gdinfo->nzz;
  int num_x = gdinfo->num_total_grid_x + 2*nghost*nproc;
  int num_xx = gdinfo->num_total_grid_car + 2*nghost*nproc;
  int num_gd_polar = (gdinfo->num_total_grid_x+2*gdinfo->npoint_ghosts)*gdinfo->num_total_grid_z; 
  int num_gd_2gd =num_gd_polar + gdinfo->num_total_grid_car*gdinfo->num_total_grid_car;
  mympi->pair_polar_ghost_r_reqs = (MPI_Request *)malloc(size *size * sizeof(MPI_Request ));
  mympi->pair_polar_ghost_s_reqs = (MPI_Request *)malloc(1 * sizeof(MPI_Request ));
  mympi->pair_car_ghost_r_reqs = (MPI_Request *)malloc(size *size * sizeof(MPI_Request ));
  mympi->pair_car_ghost_s_reqs = (MPI_Request *)malloc(1 * sizeof(MPI_Request ));
  
  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    float *restrict var = w4d + wav->cmp_pos[icmp] ;
    //send polar (car recv)
    for (size_t i = 0;i < num_xx * nzz * size*size;i++)
    {
      if(gd->c_glob_ghost_need_block[i] == mympi->myid)
      {
        int iptr = gd->c_glob_ghost_need_lociptr[i];//iptr in this block is need
        int tag = num_gd_2gd*mympi->myid + iptr ;//needed
        MPI_Isend(&var[iptr] ,1, MPI_FLOAT, gd->c_glob_ghost_belong[i], tag, 
                  MPI_COMM_WORLD,mympi->pair_polar_ghost_s_reqs);
        MPI_Wait(mympi->pair_polar_ghost_s_reqs, MPI_STATUS_IGNORE);
      }
    }
    
/*  //send polar
    for (size_t k = 0; k < gdinfo->nz; k++) 
    {
        for (size_t i = 0; i < gd->nx; i++) 
        {
          size_t iptr = i + k * gd->nx;
          if(gd->p_glob_ghost_need_block != -1)
          {
            if (mympi->myid==0) fprintf(stdout,"iprtr %d of polar of myid 0 send to block %d and iptr %d,m %d,n%d \n",
                    iptr,gd->p_send2block[iptr],gd->p_send2iptr[iptr],gd->p_send2m[iptr],gd->p_send2n[iptr]);
            int tag = num_gd_2gd*gd->p_send2block[iptr] +2*size*size*gd->p_send2iptr[iptr] +
                      2*size*gd->p_send2m[iptr] + gd->p_send2n[iptr];//block,iptr,m,n
            MPI_Isend(&var[iptr] ,1, MPI_FLOAT, gd->p_send2block[iptr], tag, 
                      MPI_COMM_WORLD,mympi->pair_polar_ghost_s_reqs);
            MPI_Wait(mympi->pair_polar_ghost_s_reqs, MPI_STATUS_IGNORE);
          }
        }
    } */
    //if (mympi->myid==0 &&icmp==0) fprintf(stdout,"polar send ok\n");
    
    //recv car

    //left block,contains 3 part
    if (mympi->topoid[0]==0)
    {
      //x1
      for (size_t k = 0; k < gd->nzz; k++) 
      {
        for (size_t i = 0; i < gd->npoint_ghosts; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
        }
      }

      //z1
      for (size_t k = 0; k < gd->npoint_ghosts; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
        }
      }

      //z2
      for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
          
        }
      }
    }

    //right block,also contains 3 part
    else if (mympi->topoid[0]==mympi->nproc-1)
    {
      //x2
      for (size_t k = 0; k < gd->nzz; k++) 
      {
        for (size_t i = gd->nxx - gd->npoint_ghosts ; i < gd->nxx; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
        }
      }

      //z1
      for (size_t k = 0; k < gd->npoint_ghosts; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++)  
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
        }
      }

      //z2
      for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++)  
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
          
        }
      }
    }
    
    //middle block
    else{
    //z1
      for (size_t k = 0; k < gd->npoint_ghosts; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
        }
      }

      //z2
      for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            wav_mpi_change_ghostvalue_car(gd,wav,var,mympi,iptr,size,icmp,num_gd_2gd);
          
        }
      }
     }
      
    //if (mympi->myid==0 &&icmp==0) fprintf(stdout,"car recv ok\n");

    //send car
    for (size_t i = 0;i < num_x * nghost * size*size;i++)
    {
      if(gd->p_glob_ghost_need_block[i] == mympi->myid)
      {
        int iptr = gd->p_glob_ghost_need_lociptr[i];//iptr in this block is need
        int tag = num_gd_2gd*mympi->myid + iptr ;//needed
        MPI_Isend(&var[iptr + gd->nx*gd->nz] ,1, MPI_FLOAT, gd->p_glob_ghost_belong[i], tag, 
                  MPI_COMM_WORLD,mympi->pair_car_ghost_s_reqs);
        MPI_Wait(mympi->pair_car_ghost_s_reqs, MPI_STATUS_IGNORE);
      }
    }
    //if (mympi->myid==0 &&icmp==0) fprintf(stdout,"car send ok\n");

    //recv polar
    for (size_t k = 0; k < gdinfo->nk1; k++) 
    {
        for (size_t i =  gdinfo->ni1; i < gdinfo->ni2; i++) 
        {
          size_t iptr = i + k * gd->nx;
          for (int m =0; m< size; m++)  {
              for (int n =0; n< size; n++) {
                  int tag = num_gd_2gd*gd->p_ghost_block[iptr][n*size +m] + gd->p_ghost_lociptr[iptr][n*size +m];
                  MPI_Irecv(&wav->storage_for_polar_interp[iptr*size*size+m+size*n], 1 , MPI_FLOAT, gd->p_ghost_block[iptr][m+size*n], 
                           tag, MPI_COMM_WORLD,&mympi->pair_polar_ghost_r_reqs[m+size*n]);
                  MPI_Wait(&mympi->pair_polar_ghost_r_reqs[m+size*n], MPI_STATUS_IGNORE);

              }
          }

        }
    }
    //if (mympi->myid==0 &&icmp==0) fprintf(stdout,"polar recv ok\n");
  
  }


  return 0;
}


//interp for ploar ghost points
float 
Distance2D_polar(float x, float y, float *xArr, float *yArr, float *zArr, int size,size_t iptr)
{
  float w = 0.0;
  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size );//-2 power of diatance
  for (int i = 0; i < size; i++) 
    {
      for (int j = 0; j < size; j++)
      {
        di[i + j*size] = (x - xArr[i + j*size])*(x - xArr[i + j*size]) + (y - yArr[i + j*size])*(y - yArr[i + j*size]);
        if (di[i + j*size] > 1e-10) {
        di[i + j*size] =1/di[i + j*size];
        }
        else{
        di[i + j*size] =1e10;
        }
        d_sum = d_sum + di[i + j*size];
      }
    }

  for (int i = 0; i < size; i++) 
    {
      for (int j = 0; j < size; j++)
      {
        w = w + di[i + j*size] / d_sum * zArr[i + j*size];
      }
    }
  return w;
  free(di);
} 

//interp for cartesian ghost points
float 
Distance2D_cartesian(float x, float y, float *xArr, float *yArr, float *zArr, int size,size_t iptr)
{
  float w = 0.0;
  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size );//-2 power of diatance
  for (int i = 0; i < size; i++) 
    {
      for (int j = 0; j < size; j++)
      {
        di[i + j*size] = y*y + yArr[i + j*size] * yArr[i + j*size]  -2* y* yArr[i + j*size]*cos(x-xArr[i + j*size]);
        if (di[i + j*size] > 1e-10) {
        di[i + j*size] =1/di[i + j*size];
        }
        else{
        di[i + j*size] =1e10;
        }
        d_sum = d_sum + di[i + j*size];
      }
    }

  for (int i = 0; i < size; i++) 
    {
      for (int j = 0; j < size; j++)
      {
        w = w + di[i + j*size] / d_sum * zArr[i + j*size];
      }
    }
  return w;
  free(di);
} 

float 
lagrange2D(float x, float y, float *xArr, float *yArr, float *zArr, int size,size_t iptr) 
{
    for (int i = 0; i < size; i++) 
    {
      for (int j = 0; j < size; j++)
      {
       for(int m = 0;m<size ; m++)
        if (m!=i && xArr[i+j*size]==xArr[m+j*size])
        {
          for (int ii = 0; ii < size; ii++) fprintf(stdout, "xArr[%d] (a line)is %f\n",ii+j*size,xArr[ii+j*size]);
          fprintf(stderr, "ERROR: lagrange interp at point %zd occurs xArr[%d] equals xArr[%d]\n",iptr,i+j*size,m+j*size);
          exit(-1);
        }
       for(int n = 0;n<size ; n++)
        if (n!=j && yArr[i+j*size]==yArr[i+n*size])
        {
          for (int jj = 0; jj < size; jj++) fprintf(stdout, "yArr[%d] (a column)is %f\n",i+jj*size,yArr[i+jj*size]);
          fprintf(stderr, "ERROR: lagrange interp at point %zd occurs yArr[%d] equals yArr[%d]\n",iptr,i+j*size,i+n*size);
          exit(-1);
        }
      }
    } 

    float z = 0.0;
    for (int i = 0; i < size; i++) 
    {
      for (int j = 0; j < size; j++)
      {
        float numerator = 1.0;
        float denominator = 1.0;
        //call Lij
        for (int m = 0; m < size; m++) 
        {         
            if (m != i) 
            {
                numerator *= (x - xArr[m + j*size]) ;
                denominator *= (xArr[i + j*size] - xArr[m + j*size]);
            }          
        }
        for (int n = 0; n < size; n++) 
        {         
            if (n != j) 
            {
                numerator *= (y - yArr[i + n*size]);
                denominator *= (yArr[i + j*size] - yArr[i + n*size]);
            }          
        }
        z += zArr[i + j*size] * numerator / denominator;
      }
    }
    return z;
}


//translate value of rc in polar_36_points to xz
//CAUTION : order of change and interp between car and polar differ, car change first so car use global_var when change
float
cal_polar2xz(gd_t *gd, gdinfo_t* gdinfo, wav_t *wav, float *restrict w4d,int icmp,int iptr_local,size_t iptr)//iptr is 36_points_in_polar(global gd)
{
  int num_gd_2gd =(gdinfo->num_total_grid_x+2*gdinfo->npoint_ghosts)*gdinfo->num_total_grid_z+gdinfo->num_total_grid_car*gdinfo->num_total_grid_car;

  float  var0 = wav->storage_for_car_interp[0][iptr_local];
  float  var1 = wav->storage_for_car_interp[1][iptr_local];
  float  var2 = wav->storage_for_car_interp[2][iptr_local];
  float  var3 = wav->storage_for_car_interp[3][iptr_local];
  float  var4 = wav->storage_for_car_interp[4][iptr_local];

  float value=0.0;
  if(icmp == 0)//wanna Vx
  {
   value = cos(gd->global_x2d_ghost[iptr])*var1 - sin(gd->global_x2d_ghost[iptr])*var0;
  }
  if(icmp == 1)//wanna Vz
  {
   value = sin(gd->global_x2d_ghost[iptr])*var1 + cos(gd->global_x2d_ghost[iptr])*var0;
  }
  if(icmp == 2)//wanna Txx
  {
   value = (var2+var3)/2 + (var3-var2)/2*cos(2*gd->global_x2d_ghost[iptr]) \
            - var4*sin(2*gd->global_x2d_ghost[iptr]);
  }
  if(icmp == 3)//wanna Tzz
  {
   value = (var2+var3)/2 - (var3-var2)/2*cos(2*gd->global_x2d_ghost[iptr]) \
            + var4*sin(2*gd->global_x2d_ghost[iptr]);
  }
  if(icmp == 4)//wanna Txz
  {
   value = (var3-var2)/2*sin(2*gd->global_x2d_ghost[iptr]) + var4*cos(2*gd->global_x2d_ghost[iptr]);
  }
  
  return value;
}


//change wav_value(of w4d,from storage_for_(c)polar_interp) in ghost regions
int
wave_changevalue_ghost(gdinfo_t *gdinfo,gd_t  *gd, wav_t *wav, float *restrict w4d ,mympi_t *mympi)
{
  int ierr = 0;
  int size =gdinfo->size_of_interp;//length of lagrange

  //gd vars
  int num_gd_x =gdinfo->num_total_grid_x;
  int num_gd_z =gdinfo->num_total_grid_z;
  int num_gd_xz =gdinfo->num_total_grid_car;
  int nghosts = gdinfo->npoint_ghosts;
  
  float *xArr = ( float * ) malloc( sizeof( float ) * size *size );
  float *zArr  = ( float * ) malloc( sizeof( float ) * size *size );
  float *value = ( float * ) malloc( sizeof( float ) * size * size ); //for cartesian
  float *value0 = ( float * ) malloc( sizeof( float ) * size * size );
  float *value1 = ( float * ) malloc( sizeof( float ) * size * size );
  float *value2 = ( float * ) malloc( sizeof( float ) * size * size );
  float *value3 = ( float * ) malloc( sizeof( float ) * size * size );
  float *value4 = ( float * ) malloc( sizeof( float ) * size * size );

  float *transvar0 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *transvar1 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *transvar2 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *transvar3 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *transvar4 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  
  float *interpvar0 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *interpvar1 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *interpvar2 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *interpvar3 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  float *interpvar4 = ( float * ) malloc( sizeof( float ) * gdinfo->nk1 * gd->nx );
  
  float *restrict var0 = w4d + wav->cmp_pos[0];
  float *restrict var1 = w4d + wav->cmp_pos[1];
  float *restrict var2 = w4d + wav->cmp_pos[2];
  float *restrict var3 = w4d + wav->cmp_pos[3];
  float *restrict var4 = w4d + wav->cmp_pos[4];
  int num_gd_2gd = (num_gd_x + 2*nghosts) *num_gd_z  + num_gd_xz*num_gd_xz;

  //interp for polar
  for (size_t k = 0; k < gdinfo->nk1; k++) 
  {
      for (size_t i = gdinfo->ni1; i < gdinfo->ni2; i++) 
      {
      size_t iptr = i + k * gd->nx;

      for (int ii =0; ii< size; ii++)  {
        for (int jj =0; jj< size; jj++) {
          xArr[ii + jj * size] = gd->global_xx2d[gd->p_ghostx[iptr] -size/2+ (gd->p_ghostz[iptr]-size/2)* num_gd_xz +ii +jj*num_gd_xz];
          zArr[ii + jj * size] = gd->global_zz2d[gd->p_ghostx[iptr] -size/2+ (gd->p_ghostz[iptr]-size/2)* num_gd_xz +ii +jj*num_gd_xz];

          value0[ii+jj*size] = wav->storage_for_polar_interp[0][iptr*size*size+ii+jj*size];
          value1[ii+jj*size] = wav->storage_for_polar_interp[1][iptr*size*size+ii+jj*size];
          value2[ii+jj*size] = wav->storage_for_polar_interp[2][iptr*size*size+ii+jj*size];
          value3[ii+jj*size] = wav->storage_for_polar_interp[3][iptr*size*size+ii+jj*size];
          value4[ii+jj*size] = wav->storage_for_polar_interp[4][iptr*size*size+ii+jj*size];
        }
      }
      //var[iptr] = Distance2D_polar(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr], xArr, zArr, value, size,iptr) ;
      //var[iptr] =Average2D(value,size);

      //now is still VT of xz
      interpvar0[iptr] = lagrange2D(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr], xArr, zArr, value0, size,iptr) ;
      interpvar1[iptr] = lagrange2D(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr], xArr, zArr, value1, size,iptr) ;
      interpvar2[iptr] = lagrange2D(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr], xArr, zArr, value2, size,iptr) ;
      interpvar3[iptr] = lagrange2D(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr], xArr, zArr, value3, size,iptr) ;
      interpvar4[iptr] = lagrange2D(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr], xArr, zArr, value4, size,iptr) ;
      
      //translate to rc,transvar is xz
      transvar0[iptr] = -1*sin(gd->x2d[iptr])*interpvar0[iptr] + cos(gd->x2d[iptr])*interpvar1[iptr];
      transvar1[iptr] = sin(gd->x2d[iptr])*interpvar1[iptr] + cos(gd->x2d[iptr])*interpvar0[iptr];
      transvar2[iptr] = (interpvar2[iptr]+interpvar3[iptr])/2-(interpvar2[iptr]-interpvar3[iptr])/2*cos(2*gd->x2d[iptr]) - interpvar4[iptr]*sin(2*gd->x2d[iptr]);
      transvar3[iptr] = (interpvar2[iptr]+interpvar3[iptr])/2 + (interpvar2[iptr]-interpvar3[iptr])/2*cos(2*gd->x2d[iptr]) + interpvar4[iptr]*sin(2*gd->x2d[iptr]);
      transvar4[iptr] = -1*(interpvar2[iptr]-interpvar3[iptr])/2*sin(2*gd->x2d[iptr]) + interpvar4[iptr]*cos(2*gd->x2d[iptr]);

      var0[iptr] = transvar0[iptr];
      var1[iptr] = transvar1[iptr];
      var2[iptr] = transvar2[iptr];
      var3[iptr] = transvar3[iptr];
      var4[iptr] = transvar4[iptr];

    }
  }  
  

  //interp for cartesian
  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    float *restrict var = w4d + wav->cmp_pos[icmp];

    //left block,contains 3 part
    if (mympi->topoid[0]==0)
    {
      //x1
      for (size_t k = 0; k < gd->nzz; k++) 
      {
        for (size_t i = 0; i < gd->npoint_ghosts; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz);
        }
      }

      //z1
      for (size_t k = 0; k < gd->npoint_ghosts; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
            //var[iptr + gd->nx * gd->nz] =Average2D(value,size);
        }
      }

      //z2
      for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            //var[iptr+gd->nx*gd->nz] =Distance2D_cartesian(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr],xArr,zArr,value,size,iptr+gd->nx*gd->nz);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
            //var[iptr + gd->nx * gd->nz] =Average2D(value,size);
          
        }
      }
    }

    //right block,also contains 3 part
    else if (mympi->topoid[0]==mympi->nproc-1)
    {
      //x2
      for (size_t k = 0; k < gd->nzz; k++) 
      {
        for (size_t i = gd->nxx - gd->npoint_ghosts ; i < gd->nxx; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
        }
      }

      //z1
      for (size_t k = 0; k < gd->npoint_ghosts; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
            //var[iptr + gd->nx * gd->nz] =Average2D(value,size);
        }
      }

      //z2
      for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            //var[iptr+gd->nx*gd->nz] =Distance2D_cartesian(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr],xArr,zArr,value,size,iptr+gd->nx*gd->nz);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
            //var[iptr + gd->nx * gd->nz] =Average2D(value,size);
          
        }
      }
    }
    
    //middle block
    //z1
    else{
      for (size_t k = 0; k < gd->npoint_ghosts; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++) 
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
            //var[iptr + gd->nx * gd->nz] =Average2D(value,size);
        }
      }

      //z2
      for (size_t k = gd->nzz - gd->npoint_ghosts; k < gd->nzz; k++) 
      {
        for (size_t i = gdinfo->nii1 ; i < gdinfo->nii2; i++)  
        {
            size_t iptr = i + k * gd->nxx;
            get_carghost_neigh(gd,gdinfo,wav,w4d,xArr,zArr,value,iptr,size,icmp);
            //var[iptr+gd->nx*gd->nz] =Distance2D_cartesian(gd->p_ghostxx[iptr], gd->p_ghostzz[iptr],xArr,zArr,value,size,iptr+gd->nx*gd->nz);
            var[iptr+gd->nx*gd->nz] = lagrange2D(gd->c_ghostxx[iptr], gd->c_ghostzz[iptr], xArr, zArr, value, size,iptr+gd->nx*gd->nz) ;
            //var[iptr + gd->nx * gd->nz] =Average2D(value,size);
          
        }
      }
    }
  }

  free(xArr);
  free(zArr);
  free(value);
  free(value0);
  free(value1);
  free(value2);
  free(value3);
  free(value4);
  free(transvar0);
  free(transvar1);
  free(transvar2);
  free(transvar3);
  free(transvar4);
  free(interpvar0);
  free(interpvar1);
  free(interpvar2);
  free(interpvar3);
  free(interpvar4);

  return ierr;
}


//get neigh_coord/value pointer of cartesian ghost point iptr
int
get_carghost_neigh(gd_t* gd,gdinfo_t* gdinfo,wav_t *wav,float *restrict w4d,float *restrict xArr,float *restrict zArr,
                   float *restrict value,int iptr,int size,int icmp)
{

  int num_gd_x =gdinfo->num_total_grid_x ;
  int num_gd_z =gdinfo->num_total_grid_z;
  int num_gd_xz =gdinfo->num_total_grid_car;
  int nghosts = gdinfo->npoint_ghosts;

  size_t iptr_start = gd->c_ghostx[iptr] -size/2+ (gd->c_ghostz[iptr]-size/2)*(num_gd_x+2*nghosts);//iptr of cartesian start in polr(global)
  
  for (int ii =0; ii< size; ii++)  
  {
    for (int jj =0; jj< size; jj++) 
    {
      xArr[ii + jj * size] =  gd->global_x2d_ghost[iptr_start +ii +jj*(num_gd_x+2*nghosts)];
      zArr[ii + jj * size] =  gd->global_z2d_ghost[iptr_start +ii +jj*(num_gd_x+2*nghosts)];
      value[ii + jj * size] = cal_polar2xz(gd,gdinfo,wav,w4d,icmp,iptr*size*size+ii + jj * size,iptr_start + ii+jj*(num_gd_x+2*nghosts));
    }
  }
  return 0;

}


int
wav_zero_edge(gdinfo_t *gdinfo,wav_t *wav, float *restrict w4d)//make 4 ghost regions equal 0 
{
  int ierr = 0;

  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    float *restrict var = w4d + wav->cmp_pos[icmp];

    // z1
    for (int k=0; k < gdinfo->nk1; k++)
    {
      size_t iptr_k = k * gdinfo->siz_iz;
        for (int i=0; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_k + i;
          var[iptr] = 0.0; 
        }
    }

    // z2
    for (int k=gdinfo->nk2+1; k < gdinfo->nz; k++)
    {
      size_t iptr_k = k * gdinfo->siz_iz;
        for (int i=0; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_k + i;
          var[iptr] = 0.0; 
        }
    }

    // x1
    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      size_t iptr_k = k * gdinfo->siz_iz;
        for (int i=0; i < gdinfo->ni1; i++)
        {
          size_t iptr = iptr_k + i;
          var[iptr] = 0.0; 
        }
    } 

    // x2
    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      size_t iptr_k = k * gdinfo->siz_iz;
        for (int i = gdinfo->ni2+1; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_k + i;
          var[iptr] = 0.0; 
        }
    } 

    //xx1
    for (size_t k = 0; k < gdinfo->nzz; k++) 
    {
      size_t iptr_k = gdinfo->nx * gdinfo->nz + k * gdinfo->nxx;
      for (size_t i = 0; i < gdinfo->npoint_ghosts; i++) 
      {
        size_t iptr = iptr_k + i;
        var[iptr] = 0.0;
      }
    }

    //xx2
      for (size_t k = 0; k < gdinfo->nzz; k++) 
    {
      size_t iptr_k = gdinfo->nx * gdinfo->nz + k * gdinfo->nxx;
      for (size_t i = gdinfo->nxx - gdinfo->npoint_ghosts; i < gdinfo->nxx; i++) 
      {
        size_t iptr = iptr_k + i;
        var[iptr] = 0.0;
      }
    }
    //zz1
    for (size_t k = 0; k < gdinfo->npoint_ghosts; k++) 
    {
      size_t iptr_k = gdinfo->nx * gdinfo->nz + k * gdinfo->nxx;
      for (size_t i = 0; i < gdinfo->nxx; i++) 
      {
        size_t iptr = iptr_k + i;
        var[iptr] = 0.0;
      }
    }

    //zz2
    for (size_t k = gdinfo->nzz - gdinfo->npoint_ghosts; k < gdinfo->nzz; k++) 
    {
      size_t iptr_k = gdinfo->nx * gdinfo->nz + k * gdinfo->nxx;
      for (size_t i = 0; i < gdinfo->nxx; i++) 
      {
        size_t iptr = iptr_k + i;
        var[iptr] = 0.0;
      }
    }
    

  } // icmp

  return ierr;
}
