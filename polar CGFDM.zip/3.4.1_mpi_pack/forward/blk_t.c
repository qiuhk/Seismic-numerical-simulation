/*********************************************************************
 * setup fd operators
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "fdlib_mem.h"
#include "fdlib_math.h"
#include "blk_t.h"

//
// malloc inner vars
//

int
blk_init(blk_t *blk, const int verbose)
{
  int ierr = 0;

  // alloc struct vars
  blk->fd            = (fd_t *)malloc(sizeof(fd_t));
  blk->mympi         = (mympi_t *)malloc(sizeof(mympi_t));
  blk->gdinfo            = (gdinfo_t        *)malloc(sizeof(gdinfo_t     ));
  blk->gd            = (gd_t        *)malloc(sizeof(gd_t     ));
  blk->gdcurv_metric = (gdcurv_metric_t *)malloc(sizeof(gdcurv_metric_t));
  blk->md            = (md_t      *)malloc(sizeof(md_t     ));
  blk->wav           = (wav_t      *)malloc(sizeof(wav_t     ));
  blk->src           = (src_t      *)malloc(sizeof(src_t     ));
  blk->bdry          = (bdry_t     *)malloc(sizeof(bdry_t ));
  blk->iorecv        = (iorecv_t   *)malloc(sizeof(iorecv_t ));
  blk->ioline        = (ioline_t   *)malloc(sizeof(ioline_t ));
  blk->iosnap        = (iosnap_t   *)malloc(sizeof(iosnap_t ));

  sprintf(blk->name, "%s", "single");

  return ierr;
}

// set str
int
blk_set_output(blk_t *blk,
               mympi_t *mympi,
               char *output_dir,
               char *grid_export_dir,
               char *media_export_dir,
               const int verbose)
{
  // set name
  //sprintf(blk->name, "%s", name);
  sprintf(blk->output_fname_part,"NO.%d", mympi->topoid[0]);
  // output
  sprintf(blk->output_dir, "%s", output_dir);
  sprintf(blk->grid_export_dir, "%s", grid_export_dir);
  sprintf(blk->media_export_dir, "%s", media_export_dir);

  return 0;
}

int
blk_print(blk_t *blk)
{    
  int ierr = 0;
  fprintf(stdout, "\n-------------------------------------------------------\n");
  fprintf(stdout, "print blk %s:\n", blk->name);
  fprintf(stdout, "-------------------------------------------------------\n\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "--> ESTIMATE MEMORY INFO.\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "total memory size Byte: %20.5f  B\n", PSV->total_memory_size_Byte);
  //fprintf(stdout, "total memory size KB  : %20.5f KB\n", PSV->total_memory_size_KB  );
  //fprintf(stdout, "total memory size MB  : %20.5f MB\n", PSV->total_memory_size_MB  );
  //fprintf(stdout, "total memory size GB  : %20.5f GB\n", PSV->total_memory_size_GB  );
  //fprintf(stdout, "\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "--> FOLDER AND FILE INFO.\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "   OutFolderName: %s\n", OutFolderName);
  //fprintf(stdout, "       EventName: %s\n", OutPrefix);
  //fprintf(stdout, "     LogFilename: %s\n", LogFilename);
  //fprintf(stdout, " StationFilename: %s\n", StationFilename);
  //fprintf(stdout, "  SourceFilename: %s\n", SourceFilename);
  //fprintf(stdout, "   MediaFilename: %s\n", MediaFilename);
  //fprintf(stdout, "\n");

  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "--> media info.\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //if (blk->media_type == MEDIA_TYPE_LAYER)
  //{
  //    strcpy(str, "layer");
  //}
  //else if (blk->media_type == MEDIA_TYPE_GRID)
  //{
  //    strcpy(str, "grid");
  //}
  //fprintf(stdout, " media_type = %s\n", str);
  //if(blk->media_type == MEDIA_TYPE_GRID)
  //{
  //    fprintf(stdout, "\n --> the media filename is:\n");
  //    fprintf(stdout, " velp_file  = %s\n", blk->fnm_velp);
  //    fprintf(stdout, " vels_file  = %s\n", blk->fnm_vels);
  //    fprintf(stdout, " rho_file   = %s\n", blk->fnm_rho);
  //}
  //fprintf(stdout, "\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "--> source info.\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, " number_of_force  = %d\n", blk->number_of_force);
  //if(blk->number_of_force > 0)
  //{
  //    fprintf(stdout, " force_source           x           z     x_shift     z_shift           i           k:\n");
  //    for(n=0; n<blk->number_of_force; n++)
  //    {
  //        indx = 2*n;
  //        fprintf(stdout, "         %04d  %10.4e  %10.4e  %10.4e  %10.4e  %10d  %10d\n", n+1, 
  //                blk->force_coord[indx], blk->force_coord[indx+1],
  //                blk->force_shift[indx], blk->force_shift[indx+1],
  //                blk->force_indx [indx], blk->force_indx [indx+1]);
  //    }
  //    fprintf(stdout, "\n");
  //}

  //fprintf(stdout, "\n");
  //fprintf(stdout, " number_of_moment = %d\n", blk->number_of_moment);
  //if(blk->number_of_moment > 0)
  //{
  //    fprintf(stdout, " moment_source          x           z     x_shift     z_shift           i           k:\n");
  //    for(n=0; n<blk->number_of_moment; n++)
  //    {
  //        indx = 2*n;
  //        fprintf(stdout, "         %04d  %10.4e  %10.4e  %10.4e  %10.4e  %10d  %10d\n", n+1, 
  //                blk->moment_coord[indx], blk->moment_coord[indx+1],
  //                blk->moment_shift[indx], blk->moment_shift[indx+1],
  //                blk->moment_indx [indx], blk->moment_indx [indx+1]);
  //    }
  //    fprintf(stdout, "\n");
  //}

  //fprintf(stdout, "-------------------------------------------------------\n");
  //fprintf(stdout, "--> boundary layer information:\n");
  //fprintf(stdout, "-------------------------------------------------------\n");
  //ierr = boundary_id2type(type1, blk->boundary_type[0], errorMsg);
  //ierr = boundary_id2type(type2, blk->boundary_type[1], errorMsg);
  //ierr = boundary_id2type(type3, blk->boundary_type[2], errorMsg);
  //ierr = boundary_id2type(type4, blk->boundary_type[3], errorMsg);
  //fprintf(stdout, " boundary_type         = %10s%10s%10s%10s\n", 
  //        type1, type2, type3, type4);
  //fprintf(stdout, " boundary_layer_number = %10d%10d%10d%10d\n", 
  //        blk->boundary_layer_number[0], blk->boundary_layer_number[1], 
  //        blk->boundary_layer_number[2], blk->boundary_layer_number[3]);
  //fprintf(stdout, "\n");
  //fprintf(stdout, " absorb_velocity       = %10.2f%10.2f%10.2f%10.2f\n", 
  //        blk->absorb_velocity[0], blk->absorb_velocity[1], blk->absorb_velocity[2], 
  //        blk->absorb_velocity[3]);
  //fprintf(stdout, "\n");
  //fprintf(stdout, " CFS_alpha_max         = %10.2f%10.2f%10.2f%10.2f\n", 
  //        blk->CFS_alpha_max[0], blk->CFS_alpha_max[1], blk->CFS_alpha_max[2], 
  //        blk->CFS_alpha_max[3]);
  //fprintf(stdout, " CFS_beta_max          = %10.2f%10.2f%10.2f%10.2f\n", 
  //        blk->CFS_beta_max[0], blk->CFS_beta_max[1], blk->CFS_beta_max[2], 
  //        blk->CFS_beta_max[3]);
  
  return ierr;
}



/*********************************************************************
 * mpi message for macdrp scheme with rk
 *********************************************************************/
void
blk_macdrp_mesg_init(mympi_t *mympi,
                fd_t *fd,
                int ni,
                int nk,
                int num_of_vars)
{
  // alloc
  mympi->pair_siz_sbuff_x1 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_siz_sbuff_x2 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_siz_rbuff_x1 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_siz_rbuff_x2 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_s_reqs       = (MPI_Request ***)malloc(fd->num_of_pairs * sizeof(MPI_Request **));
  mympi->pair_r_reqs       = (MPI_Request ***)malloc(fd->num_of_pairs * sizeof(MPI_Request **));
  for (int ipair = 0; ipair < fd->num_of_pairs; ipair++)
  {
    mympi->pair_siz_sbuff_x1[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_siz_sbuff_x2[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_siz_rbuff_x1[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_siz_rbuff_x2[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_s_reqs[ipair] = (MPI_Request **)malloc(fd->num_rk_stages * sizeof(MPI_Request *));
    mympi->pair_r_reqs[ipair] = (MPI_Request **)malloc(fd->num_rk_stages * sizeof(MPI_Request *));

    for (int istage = 0; istage < fd->num_rk_stages; istage++)
    {
      mympi->pair_s_reqs[ipair][istage] = (MPI_Request *)malloc(4 * sizeof(MPI_Request));
      mympi->pair_r_reqs[ipair][istage] = (MPI_Request *)malloc(4 * sizeof(MPI_Request));
    }
  }

  // mpi mesg
  mympi->siz_sbuff = 0;
  mympi->siz_rbuff = 0;
  for (int ipair = 0; ipair < fd->num_of_pairs; ipair++)
  {
    for (int istage = 0; istage < fd->num_rk_stages; istage++)
    {
      fd_op_t *fdx_op = fd->pair_fdx_op[ipair][istage];

      // to x1, depends on right_len of x1 proc
      mympi->pair_siz_sbuff_x1[ipair][istage] = (nk * fdx_op->right_len) * num_of_vars;
      // to x2, depends on left_len of x2 proc
      mympi->pair_siz_sbuff_x2[ipair][istage] = (nk * fdx_op->left_len ) * num_of_vars;

      // from x1, depends on left_len of cur proc
      mympi->pair_siz_rbuff_x1[ipair][istage] = (nk * fdx_op->left_len ) * num_of_vars;
      // from x2, depends on right_len of cur proc
      mympi->pair_siz_rbuff_x2[ipair][istage] = (nk * fdx_op->right_len) * num_of_vars;


      size_t siz_s =  mympi->pair_siz_sbuff_x1[ipair][istage]
                    + mympi->pair_siz_sbuff_x2[ipair][istage];
      size_t siz_r =  mympi->pair_siz_rbuff_x1[ipair][istage]
                    + mympi->pair_siz_rbuff_x2[ipair][istage];

      if (siz_s > mympi->siz_sbuff) mympi->siz_sbuff = siz_s;
      if (siz_r > mympi->siz_rbuff) mympi->siz_rbuff = siz_r;
    }
  }

  mympi->sbuff = (float *) fdlib_mem_malloc_1d(mympi->siz_sbuff * sizeof(MPI_FLOAT),"alloc sbuff");
  mympi->rbuff = (float *) fdlib_mem_malloc_1d(mympi->siz_rbuff * sizeof(MPI_FLOAT),"alloc rbuff");

  //set new var to replace neigh to realize connect in 0 and nproc block
  int front = (mympi->nproc + mympi->topoid[0] - 1) % mympi->nproc;
  int next  = (mympi->topoid[0] + 1) % mympi->nproc;
  
  // set up pers communication
  for (int ipair = 0; ipair < fd->num_of_pairs; ipair++)
  {
    for (int istage = 0; istage < fd->num_rk_stages; istage++)
    {//fill r/sbuff
      size_t siz_s_x1 = mympi->pair_siz_sbuff_x1[ipair][istage];
      size_t siz_s_x2 = mympi->pair_siz_sbuff_x2[ipair][istage];

      float *sbuff_x1 = mympi->sbuff;
      float *sbuff_x2 = sbuff_x1 + siz_s_x1;

      // npair: xx, nstage: x, 
      int tag_pair_stage = ipair * 1000 + istage * 100;
      int tag[2] = { tag_pair_stage+11, tag_pair_stage+12 };

      // send
      MPI_Send_init(sbuff_x1, siz_s_x1, MPI_FLOAT, front, tag[0], mympi->topocomm, &(mympi->pair_s_reqs[ipair][istage][0]));
      MPI_Send_init(sbuff_x2, siz_s_x2, MPI_FLOAT, next , tag[1], mympi->topocomm, &(mympi->pair_s_reqs[ipair][istage][1]));

      // recv
      size_t siz_r_x1 = mympi->pair_siz_rbuff_x1[ipair][istage];
      size_t siz_r_x2 = mympi->pair_siz_rbuff_x2[ipair][istage];

      float *rbuff_x1 = mympi->rbuff;
      float *rbuff_x2 = rbuff_x1 + siz_r_x1;


      // recv
      MPI_Recv_init(rbuff_x1, siz_r_x1, MPI_FLOAT, front, tag[1], mympi->topocomm, &(mympi->pair_r_reqs[ipair][istage][0]));
      MPI_Recv_init(rbuff_x2, siz_r_x2, MPI_FLOAT, next , tag[0], mympi->topocomm, &(mympi->pair_r_reqs[ipair][istage][1]));

    }
  }

  return;
}

void
blk_macdrp_mesg_init_car(mympi_t *mympi,
                fd_t *fd,
                int nii,
                int nkk,
                int num_of_vars)
{
  // alloc
  mympi->pair_siz_sbuff_xx1 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_siz_sbuff_xx2 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_siz_rbuff_xx1 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_siz_rbuff_xx2 = (size_t **)malloc(fd->num_of_pairs * sizeof(size_t *));
  mympi->pair_ss_reqs       = (MPI_Request ***)malloc(fd->num_of_pairs * sizeof(MPI_Request **));
  mympi->pair_rr_reqs       = (MPI_Request ***)malloc(fd->num_of_pairs * sizeof(MPI_Request **));
  for (int ipair = 0; ipair < fd->num_of_pairs; ipair++)
  {
    mympi->pair_siz_sbuff_xx1[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_siz_sbuff_xx2[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_siz_rbuff_xx1[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_siz_rbuff_xx2[ipair] = (size_t *)malloc(fd->num_rk_stages * sizeof(size_t));
    mympi->pair_ss_reqs[ipair] = (MPI_Request **)malloc(fd->num_rk_stages * sizeof(MPI_Request *));
    mympi->pair_rr_reqs[ipair] = (MPI_Request **)malloc(fd->num_rk_stages * sizeof(MPI_Request *));

    for (int istage = 0; istage < fd->num_rk_stages; istage++)
    {
      mympi->pair_ss_reqs[ipair][istage] = (MPI_Request *)malloc(4 * sizeof(MPI_Request));
      mympi->pair_rr_reqs[ipair][istage] = (MPI_Request *)malloc(4 * sizeof(MPI_Request));
    }
  }

  // mpi mesg
  mympi->siz_ssbuff = 0;
  mympi->siz_rrbuff = 0;
  for (int ipair = 0; ipair < fd->num_of_pairs; ipair++)
  {
    for (int istage = 0; istage < fd->num_rk_stages; istage++)
    {
      fd_op_t *fdx_op = fd->pair_fdx_op[ipair][istage];

      // to x1, depends on right_len of x1 proc
      mympi->pair_siz_sbuff_xx1[ipair][istage] = (nkk * fdx_op->right_len) * num_of_vars;
      // to x2, depends on left_len of x2 proc
      mympi->pair_siz_sbuff_xx2[ipair][istage] = (nkk * fdx_op->left_len ) * num_of_vars;

      // from x1, depends on left_len of cur proc
      mympi->pair_siz_rbuff_xx1[ipair][istage] = (nkk * fdx_op->left_len ) * num_of_vars;
      // from x2, depends on right_len of cur proc
      mympi->pair_siz_rbuff_xx2[ipair][istage] = (nkk * fdx_op->right_len) * num_of_vars;


      size_t siz_s =  mympi->pair_siz_sbuff_xx1[ipair][istage]
                    + mympi->pair_siz_sbuff_xx2[ipair][istage];
      size_t siz_r =  mympi->pair_siz_rbuff_xx1[ipair][istage]
                    + mympi->pair_siz_rbuff_xx2[ipair][istage];

      if (siz_s > mympi->siz_ssbuff) mympi->siz_ssbuff = siz_s;
      if (siz_r > mympi->siz_rrbuff) mympi->siz_rrbuff = siz_r;
    }
  }

  mympi->ssbuff = (float *) fdlib_mem_malloc_1d(mympi->siz_ssbuff * sizeof(MPI_FLOAT),"alloc sbuff");
  mympi->rrbuff = (float *) fdlib_mem_malloc_1d(mympi->siz_rrbuff * sizeof(MPI_FLOAT),"alloc rbuff");
  
  // set up pers communication
  for (int ipair = 0; ipair < fd->num_of_pairs; ipair++)
  {
    for (int istage = 0; istage < fd->num_rk_stages; istage++)
    {//fill r/sbuff
      size_t siz_s_xx1 = mympi->pair_siz_sbuff_xx1[ipair][istage];
      size_t siz_s_xx2 = mympi->pair_siz_sbuff_xx2[ipair][istage];

      float *sbuff_xx1 = mympi->ssbuff;
      float *sbuff_xx2 = sbuff_xx1 + siz_s_xx1;

      // npair: xx, nstage: x, 
      int tag_pair_stage = ipair * 100 + istage * 10;
      int tag[2] = { tag_pair_stage+11, tag_pair_stage+12 };

      // send
      MPI_Send_init(sbuff_xx1, siz_s_xx1, MPI_FLOAT, mympi->neighid[0], tag[0], mympi->topocomm, &(mympi->pair_ss_reqs[ipair][istage][0]));
      MPI_Send_init(sbuff_xx2, siz_s_xx2, MPI_FLOAT, mympi->neighid[1], tag[1], mympi->topocomm, &(mympi->pair_ss_reqs[ipair][istage][1]));

      // recv
      size_t siz_r_xx1 = mympi->pair_siz_rbuff_xx1[ipair][istage];
      size_t siz_r_xx2 = mympi->pair_siz_rbuff_xx2[ipair][istage];

      float *rbuff_xx1 = mympi->rrbuff;
      float *rbuff_xx2 = rbuff_xx1 + siz_r_xx1;


      // recv
      MPI_Recv_init(rbuff_xx1, siz_r_xx1, MPI_FLOAT, mympi->neighid[0], tag[1], mympi->topocomm, &(mympi->pair_rr_reqs[ipair][istage][0]));
      MPI_Recv_init(rbuff_xx2, siz_r_xx2, MPI_FLOAT, mympi->neighid[1], tag[0], mympi->topocomm, &(mympi->pair_rr_reqs[ipair][istage][1]));

    }
  }

  return;
}

//include polar init and car init
void
blk_macdrp_mesg_interp_init(mympi_t *mympi,
                gd_t *gd,
                int num_of_vars)
{
  
  // alloc
  mympi->pair_s_reqs_polar    = (MPI_Request *)malloc(gd->nblock_psend * sizeof(MPI_Request));
  mympi->pair_r_reqs_polar    = (MPI_Request *)malloc(gd->nblock_precv * sizeof(MPI_Request));
  mympi->pair_s_reqs_car    = (MPI_Request *)malloc(gd->nblock_csend * sizeof(MPI_Request));
  mympi->pair_r_reqs_car    = (MPI_Request *)malloc(gd->nblock_crecv * sizeof(MPI_Request));

  // mpi mesg size
  int siz_sbuff_polar = 0;
  int siz_rbuff_polar = 0;
  for(int i=0 ; i< gd->nblock_psend; i++)
  {
    siz_sbuff_polar = siz_sbuff_polar + gd->p_myblock2block_niptr[i] * (num_of_vars+1);// the +1 is message of send
  }
  for(int i=0 ; i< gd->nblock_precv; i++)
  {
    siz_rbuff_polar = siz_rbuff_polar + gd->p_block2myblock_niptr[i] * (num_of_vars+1);
  }

  int siz_sbuff_car = 0;
  int siz_rbuff_car = 0;
  for(int i=0 ; i< gd->nblock_csend; i++)
  {
    siz_sbuff_car = siz_sbuff_car + gd->c_myblock2block_niptr[i] * (num_of_vars+1);
  }
  for(int i=0 ; i< gd->nblock_crecv; i++)
  {
    siz_rbuff_car = siz_rbuff_car + gd->c_block2myblock_niptr[i] * (num_of_vars+1);
  }

  mympi->sbuff_polar = (float *) fdlib_mem_calloc_1d_float(siz_sbuff_polar * sizeof(MPI_FLOAT),-1.0,"alloc sbuff");//container of mpi_package
  mympi->rbuff_polar = (float *) fdlib_mem_calloc_1d_float(siz_rbuff_polar * sizeof(MPI_FLOAT),-1.0,"alloc rbuff");
  mympi->sbuff_car = (float *) fdlib_mem_calloc_1d_float(siz_sbuff_car * sizeof(MPI_FLOAT),-1.0,"alloc sbuff");
  mympi->rbuff_car = (float *) fdlib_mem_calloc_1d_float(siz_rbuff_car * sizeof(MPI_FLOAT),-1.0,"alloc rbuff");
  
  // polar send and car recv
  //polar send
  float *sbuff_p;
  for (int iblock = 0; iblock < gd->nblock_psend; iblock++)
  {
    sbuff_p = mympi->sbuff_polar;
    if (iblock!=0){
      for (int j = 0; j < iblock; j++)
      sbuff_p = sbuff_p + gd->p_myblock2block_niptr[j] * (num_of_vars+1) ;
    }

    MPI_Send_init(sbuff_p, gd->p_myblock2block_niptr[iblock] * (num_of_vars+1) , MPI_FLOAT, gd->p_myblock2block[iblock],
                  gd->p_myblock2block[iblock]*10000 + mympi->myid*10 + 3, mympi->topocomm, &(mympi->pair_s_reqs_polar[iblock]));
  }
  
  //car recv
  float *rbuff_c;
  for (int iblock = 0; iblock < gd->nblock_crecv; iblock++)
  {
    rbuff_c = mympi->rbuff_car;
    if (iblock!=0){
      for (int j = 0; j < iblock; j++)
      rbuff_c = rbuff_c + gd->c_block2myblock_niptr[j] * (num_of_vars+1) ;
    }

    MPI_Recv_init(rbuff_c, gd->c_block2myblock_niptr[iblock] * (num_of_vars+1), MPI_FLOAT, gd->c_block2myblock[iblock],
                  mympi->myid*10000 + gd->c_block2myblock[iblock]*10 + 3, mympi->topocomm, &(mympi->pair_r_reqs_car[iblock]));
  }

  // car send and polar recv
  //car send
  float *sbuff_c;
  for (int iblock = 0; iblock < gd->nblock_csend; iblock++)
  {
    sbuff_c = mympi->sbuff_car;
    if (iblock!=0){
      for (int j = 0; j < iblock; j++)
      sbuff_c = sbuff_c + gd->c_myblock2block_niptr[j] * (num_of_vars+1);
    }

    MPI_Send_init(sbuff_c, gd->c_myblock2block_niptr[iblock] * (num_of_vars+1), MPI_FLOAT, gd->c_myblock2block[iblock],
                  gd->c_myblock2block[iblock]*10000 + mympi->myid*10 + 5, mympi->topocomm, &(mympi->pair_s_reqs_car[iblock]));
  }
  
  //polar recv
  float *rbuff_p;
  for (int iblock = 0; iblock < gd->nblock_precv; iblock++)
  {
    rbuff_p = mympi->rbuff_polar;
    if (iblock!=0){
      for (int j = 0; j < iblock; j++)
      rbuff_p = rbuff_p + gd->p_block2myblock_niptr[j] * (num_of_vars+1);
    }

    MPI_Recv_init(rbuff_p, gd->p_block2myblock_niptr[iblock] * (num_of_vars+1), MPI_FLOAT, gd->p_block2myblock[iblock],
                  mympi->myid*10000 + gd->p_block2myblock[iblock]*10 + 5, mympi->topocomm, &(mympi->pair_r_reqs_polar[iblock]));
  }


  return;
}

void
blk_macdrp_pack_mesg_interp(float *restrict w_cur,float *restrict sbuff_polar,float *restrict sbuff_car,
                 int num_of_vars, gd_t *gd, gdinfo_t *gdinfo, mympi_t *mympi)
{
  int nghost = gdinfo->npoint_ghosts;
  int size = gdinfo->size_of_interp;
  int nproc = mympi->nproc;
  int nzz = gdinfo->nzz;
  int num_x = gdinfo->num_total_grid_x + 2*nghost*nproc;
  int num_xx = gdinfo->num_total_grid_car + 2*nghost*nproc;

  size_t siz_volume = gdinfo->siz_volume;
  size_t siz_volume_car = gdinfo->nxx * gdinfo->nzz;

  size_t iptr_b = 0;
  size_t iptr_bb = 0;

  //polar
  for (int iblock = 0; iblock < gd->nblock_psend; iblock++)
  {
    //coordinate
    for (size_t i = 0;i < gd->p_myblock2block_niptr[iblock];i++)
    {
        sbuff_polar[iptr_b] = gd->p_send2iptrmn[iblock][i];//iptr is destination include mn
        iptr_b++;

        //check coord value
       // if (mympi->myid == 2 && iblock==2 )
       // fprintf(stdout,"NO.%d in %d of send_polar_block3 is myiptr %d, to c_%d of iptrmn %d \n",
       // i,gd->p_myblock2block_niptr[iblock], gd->p_myiptr_send[iblock][i], gd->p_myblock2block[iblock],gd->p_send2iptrmn[iblock][i]);
    }
    //wav value
    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      size_t iptr_var = ivar * (siz_volume +  siz_volume_car);
      for (size_t i = 0;i < gd->p_myblock2block_niptr[iblock];i++)
      {
          int iptr = gd->p_myiptr_send[iblock][i] + iptr_var;//iptr in this block is need
          sbuff_polar[iptr_b] = w_cur[iptr];
          iptr_b++;
      } 
    }
  }


  //car
  for (int iblock = 0; iblock < gd->nblock_csend; iblock++)
  {
    //coordinate
    for (size_t i = 0;i < gd->c_myblock2block_niptr[iblock];i++)
    {
        sbuff_car[iptr_bb] =gd->c_send2iptrmn[iblock][i];//iptr in destination include mn
        iptr_bb++;

    }
    //wav value
    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      size_t iptr_var = ivar * (siz_volume +  siz_volume_car);
      for (size_t i = 0;i < gd->c_myblock2block_niptr[iblock];i++)
      {
          int iptr = gd->c_myiptr_send[iblock][i] + iptr_var + gd->nx*gd->nz;//iptr in this block is need
          sbuff_car[iptr_bb] = w_cur[iptr];
          iptr_bb++;
      }
    }
  }


  return;
}

void
blk_macdrp_unpack_mesg_interp(float *restrict rbuff_polar,float *restrict rbuff_car,
                 int num_of_vars, gd_t *gd, gdinfo_t *gdinfo, wav_t *wav, mympi_t *mympi)
{
  //polar
  int size = gdinfo->size_of_interp;
  int num_polar_recv = 0;//check num_recv

  float *rbuff_p = NULL;
  for (int iblock = 0; iblock < gd->nblock_precv; iblock++)
  {
    int niptr_recv = gd->p_block2myblock_niptr[iblock];
    
    rbuff_p = rbuff_polar;
    if (iblock!=0){
      for (int j = 0; j < iblock; j++)
      rbuff_p = rbuff_p + gd->p_block2myblock_niptr[j] * (num_of_vars+1);
    }

    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      for (size_t irecv = 0;irecv < niptr_recv ;irecv++)//iptr of recv
      {

        wav->storage_for_polar_interp[ivar][(int)rbuff_p[irecv]] = rbuff_p[niptr_recv + ivar*niptr_recv + irecv ];
        num_polar_recv++;

        if ((int)rbuff_p[irecv] - rbuff_p[irecv] != 0)
        {
          fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
          fprintf(stdout,"coord place in p_rbuff has error in %d block from block %d,irecv = %d,rbuff_p[irecv]= %f\n",
                  mympi->myid, gd->p_block2myblock[iblock] ,irecv,rbuff_p[irecv]);// error
          exit(-1);
        }
        if (rbuff_p[irecv] >= gd->npoint_ghosts * gd->nx *size*size )
        {
          fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
          fprintf(stdout,"recv %d place equals %f has over 3*nx in polar \n",irecv,rbuff_p[irecv]);// error
          exit(-1);
        }
      }
    }
  }

   //check if all polar_recv_points has recved
  if(num_polar_recv != num_of_vars * gd->npoint_ghosts *gdinfo->ni*size*size )
  {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
    fprintf(stdout,"ghost points  %d in polar_gd has not all recv mpi_interp value,only recv %d points(ncmp_wav = %d)\n",
            gd->npoint_ghosts *gdinfo->ni,  num_polar_recv/size/size, num_of_vars );// error
    exit(-1);
  }

  //car
  float *rbuff_c = NULL;
  for (int iblock = 0; iblock < gd->nblock_crecv; iblock++)
  {
    int niptr_recv = gd->c_block2myblock_niptr[iblock];

    rbuff_c = rbuff_car;
    if (iblock!=0){
      for (int j = 0; j < iblock; j++)
      rbuff_c = rbuff_c + gd->c_block2myblock_niptr[j] * (num_of_vars+1);
    }

    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      for (size_t irecv = 0;irecv < niptr_recv ;irecv++)//iptr of recv
      {
    //    if (mympi->myid == 2 && ivar==0 && iblock==1 )
    //    fprintf(stdout,"block%d_car_unpack's recv(from block%d) NO. %d of %d is %f  \n", 
    //           mympi->myid,gd->c_block2myblock[iblock],irecv, niptr_recv , rbuff_c[irecv]);

        wav->storage_for_car_interp[ivar][(int)rbuff_c[irecv]] = rbuff_c[niptr_recv + ivar*niptr_recv + irecv ];
      }
    }
  }

  
  return;
}


void
blk_macdrp_pack_mesg(float *restrict w_cur,float *restrict sbuff,float *restrict ssbuff,
                 int num_of_vars, gdinfo_t *gdinfo,
                 fd_op_t *fdx_op)
{
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nii1 = gdinfo->nii1;
  int nii2 = gdinfo->nii2;
  int nkk1 = gdinfo->nkk1;
  int nkk2 = gdinfo->nkk2;

  size_t siz_slice  = gdinfo->siz_slice;
  size_t siz_volume = gdinfo->siz_volume;
  size_t siz_slice_car  = gdinfo->nxx;
  size_t siz_volume_car = gdinfo->nxx * gdinfo->nzz;

  size_t iptr_b = 0;
  size_t iptr_bb = 0;

  //polar
  // to x1
  for (int ivar=0; ivar<num_of_vars; ivar++)
  {
    size_t iptr_var = ivar * (siz_volume +  siz_volume_car);

    for (int k=nk1; k<=nk2; k++)
    {
      size_t iptr_k = iptr_var + k * siz_slice;
        for (int i=ni1; i<ni1+fdx_op->right_len; i++)
        {
          sbuff[iptr_b] = w_cur[iptr_k + i];
          iptr_b++;
        }
    }
  }

  // to x2
  for (int ivar=0; ivar<num_of_vars; ivar++)
  {
    size_t iptr_var = ivar * (siz_volume +  siz_volume_car);

    for (int k=nk1; k<=nk2; k++)
    {
      size_t iptr_k = iptr_var + k * siz_slice;

        for (int i=ni2- fdx_op->left_len +1; i<=ni2; i++)
        {
          sbuff[iptr_b] = w_cur[iptr_k + i];
          iptr_b++;
        }
    }
  }

  //car
  // to x1
  for (int ivar=0; ivar<num_of_vars; ivar++)
  {
    size_t iptr_var = ivar * (siz_volume +  siz_volume_car) + siz_volume;

    for (int k=nkk1; k<=nkk2; k++)
    {
      size_t iptr_k = iptr_var + k * siz_slice_car;
        for (int i=nii1; i<nii1+fdx_op->right_len; i++)
        {
          ssbuff[iptr_bb] = w_cur[iptr_k + i];
          iptr_bb++;
        }
    }
  }

  // to x2
  for (int ivar=0; ivar<num_of_vars; ivar++)
  {
    size_t iptr_var = ivar * (siz_volume +  siz_volume_car) + siz_volume;

    for (int k=nkk1; k<=nkk2; k++)
    {
      size_t iptr_k = iptr_var + k * siz_slice_car;

        for (int i=nii2- fdx_op->left_len +1; i<=nii2; i++)
        {
          ssbuff[iptr_bb] = w_cur[iptr_k + i];
          iptr_bb++;
        }
    }
  }

  return;
}


void
blk_macdrp_unpack_mesg(float *restrict rbuff,float *restrict rrbuff,float *restrict w_cur,
                 int num_of_vars, gdinfo_t *gdinfo,
                 fd_op_t *fdx_op, 
                 size_t siz_x1, size_t siz_xx1, int *neighid)
{
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nii1 = gdinfo->nii1;
  int nii2 = gdinfo->nii2;
  int nkk1 = gdinfo->nkk1;
  int nkk2 = gdinfo->nkk2;

  size_t siz_slice  = gdinfo->siz_slice;
  size_t siz_volume = gdinfo->siz_volume;
  size_t siz_slice_car  = gdinfo->nxx;
  size_t siz_volume_car = gdinfo->nxx * gdinfo->nzz;

  size_t iptr_b = 0;
  size_t iptr_bb = 0;
  
  //polar
  // to x1
  float *restrict rbuff_x1 = rbuff;
  //if (neighid[0] != MPI_PROC_NULL) {
    iptr_b = 0;
    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      size_t iptr_var = ivar * (siz_volume +  siz_volume_car);

      for (int k=nk1; k<=nk2; k++)
      {
        size_t iptr_k = iptr_var + k * siz_slice;
          for (int i=ni1- fdx_op->left_len; i<ni1; i++)
          {
            w_cur[iptr_k + i] = rbuff_x1[iptr_b];
            iptr_b++;
          }      
      }
    }
  //}

  // to x2
  float *restrict rbuff_x2 = rbuff_x1 + siz_x1;
  //if (neighid[1] != MPI_PROC_NULL) {
    iptr_b = 0;
    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      size_t iptr_var = ivar * (siz_volume +  siz_volume_car);

      for (int k=nk1; k<=nk2; k++)
      {
        size_t iptr_k = iptr_var + k * siz_slice;
          for (int i=ni2+1; i<=ni2+ fdx_op->right_len; i++)
          {
            w_cur[iptr_k + i] = rbuff_x2[iptr_b];
            iptr_b++;
          }
        }
      }
    //}

  //cartesian
  // to x1
  float *restrict rbuff_xx1 = rrbuff;
  //if (neighid[0] != MPI_PROC_NULL) {
    iptr_bb = 0;
    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      size_t iptr_var = ivar * (siz_volume +  siz_volume_car) + siz_volume;

      for (int k=nkk1; k<=nkk2; k++)
      {
        size_t iptr_k = iptr_var + k * siz_slice_car;
          for (int i=nii1- fdx_op->left_len; i<nii1; i++)
          {
            w_cur[iptr_k + i] = rbuff_xx1[iptr_bb];
            iptr_bb++;
          }      
      }
    }
  //}

  // to x2
  float *restrict rbuff_xx2 = rbuff_xx1 + siz_xx1;
  //if (neighid[1] != MPI_PROC_NULL) {
    iptr_bb = 0;
    for (int ivar=0; ivar<num_of_vars; ivar++)
    {
      size_t iptr_var = ivar * (siz_volume +  siz_volume_car) + siz_volume;

      for (int k=nkk1; k<=nkk2; k++)
      {
        size_t iptr_k = iptr_var + k * siz_slice_car;
          for (int i=nii2+1; i<=nii2+ fdx_op->right_len; i++)
          {
            w_cur[iptr_k + i] = rbuff_xx2[iptr_bb];
            iptr_bb++;
          }
        }
      }
    //}

  return;
}

/*********************************************************************
 * estimate dt
 *********************************************************************/

int
blk_dt_esti_curv(gdinfo_t *gdinfo, gd_t *gdcurv, md_t *md,
                 float CFL, float *dtmax, float *dtmaxVp, float *dtmaxL,
                 int *dtmaxi, int *dtmaxk, int  *whichregion)
{
  int ierr = 0;

  float dtmax_local = 1.0e10;
  float Vp;

  float *restrict x2d = gdcurv->x2d;
  float *restrict z2d = gdcurv->z2d;
  float *restrict xx2d = gdcurv->xx2d;
  float *restrict zz2d = gdcurv->zz2d;
//circle region
  for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
  {
      for (int i = gdinfo->ni1; i <= gdinfo->ni2; i++)
      {
        size_t iptr = i + k * gdinfo->siz_iz;

        if (md->medium_type == CONST_MEDIUM_ELASTIC_ISO) {
          Vp = sqrt( (md->lambda[iptr] + 2.0 * md->mu[iptr]) / md->rho[iptr] );
          if (md->visco_type == CONST_VISCO_GMB) {
              float Ymax = md->Ylam[0][iptr];
              for (int n = 0; n < md->nmaxwell; n++)
              {
                  Ymax = Ymax > md->Ylam[n][iptr] ? Ymax : md->Ylam[n][iptr];
                  Ymax = Ymax > md->Ymu[n][iptr] ? Ymax : md->Ymu[n][iptr];
              }
              float V_vis = Vp*(1+sqrt(md->nmaxwell*Ymax));
              Vp = V_vis > Vp ? V_vis : Vp;
          }
        } else if (md->medium_type == CONST_MEDIUM_ELASTIC_VTI) {
          float Vpv = sqrt( md->c33[iptr] / md->rho[iptr] );
          float Vph = sqrt( md->c11[iptr] / md->rho[iptr] );
          Vp = Vph > Vpv ? Vph : Vpv;
        } else if (md->medium_type == CONST_MEDIUM_ELASTIC_ANISO) {
          // need to implement accurate solution
          Vp = sqrt( md->c11[iptr] / md->rho[iptr] );
        } else if (md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO) {
          Vp = sqrt( md->kappa[iptr] / md->rho[iptr] );
        }

        float dtLe = 1.0e20;
        float x0 = x2d[iptr];
        float z0 = z2d[iptr];

        // min L to 8 adjacent planes(9-1)
        for (int kk = -1; kk <=1; kk++) {
            for (int ii = -1; ii <= 1; ii++) {
              if (ii != 0 && kk != 0)
              {
                float p1[] = { x2d[iptr-ii], z2d[iptr-ii] };
                float p2[] = { x2d[iptr-kk*gdinfo->siz_iz],
                               z2d[iptr-kk*gdinfo->siz_iz] };

                float L = fdlib_math_dist_point2line_polar(x0, z0, p1, p2);

                if (dtLe > L) dtLe = L;//find min L
              }
          }
        }

        // convert to dt,
        float dt_point = CFL / Vp * dtLe;

        // get min dtmin;min dt satisfy stability
        if (dt_point < dtmax_local) {
          dtmax_local = dt_point;
          *dtmaxi = i;
          *dtmaxk = k;
          *dtmaxVp = Vp;
          *dtmaxL  = dtLe;
        }
      } // i
  } //k

//cartesian region
  for (int k = 3; k <= gdcurv->nzz-4; k++)
  {
      for (int i = 3; i <= gdcurv->nxx-4; i++)
      {
        size_t iptr = i + k * gdcurv->nxx;
        size_t iptr_media = iptr + gdcurv->nx *gdcurv->nz;

        if (md->medium_type == CONST_MEDIUM_ELASTIC_ISO) {
          Vp = sqrt( (md->lambda[iptr_media] + 2.0 * md->mu[iptr_media]) / md->rho[iptr_media] );
        } 

        float dtLe = 1.0e20;
        float x0 = xx2d[iptr];
        float z0 = zz2d[iptr];

        // min L to 8 adjacent planes(9-1)
        for (int kk = -1; kk <=1; kk++) {
            for (int ii = -1; ii <= 1; ii++) {
              if (ii != 0 && kk != 0)
              {
                float p1[] = { xx2d[iptr-ii], zz2d[iptr-ii] };
                float p2[] = { xx2d[iptr-kk*gdcurv->nxx],
                               zz2d[iptr-kk*gdcurv->nxx] };

                float L = fdlib_math_dist_point2line(x0, z0, p1, p2);

                if (dtLe > L) dtLe = L;//find min L
              }
          }
        }

        // convert to dt,
        float dt_point = CFL / Vp * dtLe;

        // get min dtmin;min dt satisfy stability
        if (dt_point < dtmax_local) {
          dtmax_local = dt_point;
          *dtmaxi = i;
          *dtmaxk = k;
          *dtmaxVp = Vp;
          *dtmaxL  = dtLe;
          *whichregion = 1;
        }
      } // i
  } 
  *dtmax = dtmax_local;

  return ierr;
}


float
blk_keep_two_digi(float dt)
{
  char str[40];
  float dt_2;

  sprintf(str, "%4.2e", dt);

  str[3] = '0';

  sscanf(str, "%f", &dt_2);
  
  return dt_2;
}
