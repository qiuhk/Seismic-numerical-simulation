#ifndef MY_MPI_H
#define MY_MPI_H

#include <mpi.h>

#include "constants.h"

/*******************************************************************************
 * structure
 ******************************************************************************/

typedef struct {
  int       nproc;
  int       myid;
  MPI_Comm  comm;
  
  int *displs_polar;
  int *displs_car ;//pointer of each block_gd in whole gd,to gather whole_gd/wav,regarding 6 ghost layer
  int *allCount_polar;
  int *allCount_car;//contains every size of block,only used for gather func
  
  int *displs_polar_ni;
  int *displs_car_nii;
  int *each_ni_polar;
  int *each_nii_car;
  

  int     topoid[1];
  //int    neighid[4];
  int    neighid[CONST_NDIM_2];
  MPI_Comm    topocomm;

  size_t siz_sbuff;
  size_t siz_rbuff;
  float *sbuff;
  float *rbuff;

  size_t siz_ssbuff;
  size_t siz_rrbuff;
  float *ssbuff;
  float *rrbuff;

  // for col scheme
  MPI_Request r_reqs[2];
  MPI_Request s_reqs[2];

  // for macdrp of polar
  size_t **pair_siz_sbuff_x1;
  size_t **pair_siz_sbuff_x2;
  size_t **pair_siz_rbuff_x1;
  size_t **pair_siz_rbuff_x2;
  MPI_Request ***pair_r_reqs;
  MPI_Request ***pair_s_reqs;

  MPI_Request *pair_polar_ghost_r_reqs;
  MPI_Request *pair_polar_ghost_s_reqs;
  MPI_Request *pair_car_ghost_r_reqs;
  MPI_Request *pair_car_ghost_s_reqs;

  // for macdrp of car
  size_t **pair_siz_sbuff_xx1;
  size_t **pair_siz_sbuff_xx2;
  size_t **pair_siz_rbuff_xx1;
  size_t **pair_siz_rbuff_xx2;
  MPI_Request ***pair_rr_reqs;
  MPI_Request ***pair_ss_reqs;

  //for mpi_interp_package
  MPI_Request *pair_s_reqs_polar;
  MPI_Request *pair_s_reqs_car;
  MPI_Request *pair_r_reqs_polar;
  MPI_Request *pair_r_reqs_car;
  float *sbuff_polar;
  float *sbuff_car;
  float *rbuff_polar;
  float *rbuff_car;

} mympi_t;

/*******************************************************************************
 * function prototype
 ******************************************************************************/

int
mympi_set(mympi_t *mympi,
          int number_of_mpiprocs,
          MPI_Comm comm, 
          const int myid, const int verbose);



#endif
