/*******************************************************************************
 * solver of isotropic elastic 1st-order eqn using curv grid and macdrp schem
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mpi.h>

#include "fdlib_mem.h"
#include "fdlib_math.h"
#include "blk_t.h"
#include "drv_rk_curv_col.h"
#include "sv_curv_col_el.h"
#include "sv_curv_col_el_vis.h"
#include "sv_curv_col_el_iso.h"
#include "sv_curv_col_el_vti.h"
#include "sv_curv_col_el_aniso.h"
#include "sv_curv_col_ac_iso.h"

/*******************************************************************************
 * one simulation over all time steps, could be used in imaging or inversion
 ******************************************************************************/

int
drv_rk_curv_col_allstep(
  fd_t        *fd,
  gd_t        *gd,
  gdinfo_t    *gdinfo,
  gdcurv_metric_t *metric,
  md_t      *md,
  src_t      *src,
  bdry_t *bdry,
  wav_t  *wav,
  mympi_t    *mympi,
  iorecv_t   *iorecv,
  ioline_t   *ioline,
  iosnap_t   *iosnap,
  // time
  float dt, int nt_total, float t0,
  char *output_fname_part,
  char *output_dir,
  int qc_check_nan_num_of_step,
  const int output_all, // qc all var
  const int verbose)
{
  // retrieve from struct
  int num_rk_stages = fd->num_rk_stages;
  float *rk_a = fd->rk_a;
  float *rk_b = fd->rk_b;

  int num_of_pairs     = fd->num_of_pairs;
  int fdx_max_half_len = fd->fdx_max_half_len;
  int fdz_max_len      = fd->fdz_max_len;
  int num_of_fdz_op    = fd->num_of_fdz_op;

  // mpi
  int myid = mympi->myid;
  int *topoid = mympi->topoid;
  MPI_Comm comm = mympi->comm;
  float *restrict sbuff = mympi->sbuff;
  float *restrict rbuff = mympi->rbuff;
  float *restrict ssbuff = mympi->ssbuff;
  float *restrict rrbuff = mympi->rrbuff;
  float *restrict sbuff_polar = mympi->sbuff_polar;//for package
  float *restrict rbuff_polar = mympi->rbuff_polar;
  float *restrict sbuff_car = mympi->sbuff_car;
  float *restrict rbuff_car = mympi->rbuff_car;

  // local allocated array
  char ou_file[CONST_MAX_STRLEN];

  // local pointer
  float *restrict w_cur;
  float *restrict w_pre;
  float *restrict w_rhs;
  float *restrict w_end;
  float *restrict w_tmp;

  int   ipair, istage;
  float t_cur;
  float t_end; // time after this loop for nc output
  // for mpi message
  int   ipair_mpi, istage_mpi;

  // create snapshot nc output files
  if (myid==0 && verbose>0) fprintf(stdout,"prepare snap nc output ...\n"); 
  iosnap_nc_t  iosnap_nc;
  if (md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO) {
    io_snap_nc_create_ac(iosnap, &iosnap_nc);
  } else {
    io_snap_nc_create(iosnap, &iosnap_nc, gdinfo,topoid);
  }

  // only x mpi
  int num_of_r_reqs = CONST_NDIM;
  int num_of_s_reqs = CONST_NDIM;

  // get wavefield
  w_pre = wav->v4d + wav->siz_ilevel * 0; // previous level at n
  w_tmp = wav->v4d + wav->siz_ilevel * 1; // intermidate value
  w_rhs = wav->v4d + wav->siz_ilevel * 2; // for rhs
  w_end = wav->v4d + wav->siz_ilevel * 3; // end level at n+1

  // set pml for rk
  if(bdry->is_enable_pml == 1)
  {
    for (int idim=0; idim<CONST_NDIM; idim++) {
      for (int iside=0; iside<2; iside++) {
        if (bdry->is_sides_pml[idim][iside]==1) {
          bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
          auxvar->pre = auxvar->var + auxvar->siz_ilevel * 0;
          auxvar->tmp = auxvar->var + auxvar->siz_ilevel * 1;
          auxvar->rhs = auxvar->var + auxvar->siz_ilevel * 2;
          auxvar->end = auxvar->var + auxvar->siz_ilevel * 3;
        }
      }
    }
  }

  // calculate conversion matrix for free surface
  if (bdry->is_sides_free[CONST_NDIM-1][1] == 1)
  {
    if(md->medium_type == CONST_MEDIUM_ELASTIC_ISO)
    {
      if (md->visco_type == CONST_VISCO_GMB) 
      {
        sv_curv_col_el_vis_dvh2dvz(gdinfo,metric,md,bdry,verbose);
      } else {
        sv_curv_col_el_iso_dvh2dvz(gd,gdinfo,metric,md,bdry,verbose);
      }
    } 
    else if(md->medium_type == CONST_MEDIUM_ELASTIC_ANISO) 
    {
      sv_curv_col_el_aniso_dvh2dvz(gdinfo,metric,md,bdry,verbose);
    }
    else if(md->medium_type == CONST_MEDIUM_ELASTIC_VTI)
    {
      sv_curv_col_el_vti_dvh2dvz(gdinfo,metric,md,bdry,verbose);
    } 
    else if(md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO) 
    {
      // no need
    }
  }

  //if (myid!=0) {
  //  for (int iii=0;iii<gdinfo->num_total_grid_car * gdinfo->num_total_grid_car;iii++)
  //  fprintf(stdout,"car_global of %d is xx= %f ,zz= %f\n",iii,gd->global_xx2d[iii],gd->global_zz2d[iii]); }

  //--------------------------------------------------------
  // time loop
  //--------------------------------------------------------

  if (myid==0 && verbose>0) fprintf(stdout,"  start time loop ...\n"); 

  for (int it=0; it<nt_total; it++)
  {
    t_cur  = it * dt + t0;
    t_end = t_cur +dt;// time after this loop for nc output

    if (myid==0 && verbose>10) fprintf(stdout,"-> it=%d, t=%f\n", it, t_cur);

    // mod to get ipair
    ipair = it % num_of_pairs;
    if (myid==0 && verbose>10) fprintf(stdout, " -> ipair=%d\n",ipair);

    // loop RK stages for one step
    for (istage=0; istage<num_rk_stages; istage++)
    {
      if (myid==0 && verbose>10) fprintf(stdout, " --> istage=%d\n",istage);
      
      // for mesg,ipair/stage_mpi is next time's serial number               
      if (istage != num_rk_stages-1) {
        ipair_mpi = ipair;
        istage_mpi = istage + 1;
      } else {
        ipair_mpi = (it + 1) % num_of_pairs;
        istage_mpi = 0; 
      }

      // use pointer to avoid 1 copy for previous level value
      if (istage==0) {
        w_cur = w_pre;
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              bdry->auxvar[idim][iside].cur = bdry->auxvar[idim][iside].pre;
            }
          }
        }
      }
      else
      {
        w_cur = w_tmp;
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              bdry->auxvar[idim][iside].cur = bdry->auxvar[idim][iside].tmp;
            }
          }
        }
      }

      // set src_t time
      src_set_time(src, it, istage);

      wave_changevalue_ghost(gdinfo,gd, wav, w_cur, mympi);

        //gather whole wave and change info of 2 grid
        //wav_gather_global(gd,gdinfo,wav,w_cur,mympi);
      //wav_get_interp_value(gd,gdinfo,wav,w_cur,mympi);//use MPI to get size*size value for ghost points

      // compute rhs
      switch (md->medium_type)
      {
        case CONST_MEDIUM_ELASTIC_ISO : {
          if (md->visco_type == CONST_VISCO_GMB) 
          {
            sv_curv_col_el_vis_onestage(
                w_cur,w_rhs,wav,
                gdinfo, gd, metric, md, bdry, src,
                fd->num_of_fdx_op, fd->pair_fdx_op[ipair][istage],
                fd->num_of_fdz_op, fd->pair_fdz_op[ipair][istage],
                fd->fdz_max_len,
                verbose);
          } else {
            sv_curv_col_el_iso_onestage(
                w_cur,w_rhs,wav,
                gdinfo, gd, metric, md, bdry, src,
                fd->num_of_fdx_op, fd->pair_fdx_op[ipair][istage],
                fd->num_of_fdz_op, fd->pair_fdz_op[ipair][istage],
                fd->fdz_max_len,
                verbose);
          }

          break;
        }

        case CONST_MEDIUM_ELASTIC_VTI : {
          sv_curv_col_el_vti_onestage(
              w_cur,w_rhs,wav,
              gdinfo, gd, metric, md, bdry, src,
              fd->num_of_fdx_op, fd->pair_fdx_op[ipair][istage],
              fd->num_of_fdz_op, fd->pair_fdz_op[ipair][istage],
              fd->fdz_max_len,
              verbose);

          break;
        }

        case CONST_MEDIUM_ELASTIC_ANISO : {
          sv_curv_col_el_aniso_onestage(
              w_cur,w_rhs,wav,
              gdinfo, gd, metric, md, bdry, src,
              fd->num_of_fdx_op, fd->pair_fdx_op[ipair][istage],
              fd->num_of_fdz_op, fd->pair_fdz_op[ipair][istage],
              fd->fdz_max_len,
              verbose);

          break;
        }

        case CONST_MEDIUM_ACOUSTIC_ISO : {
          sv_curv_col_ac_iso_onestage(
              w_cur,w_rhs,wav,
              gdinfo, gd, metric, md, bdry, src,
              fd->num_of_fdx_op, fd->pair_fdx_op[ipair][istage],
              fd->num_of_fdz_op, fd->pair_fdz_op[ipair][istage],
              fd->fdz_max_len,
              verbose);

          break;
        }
      }

      // recv mesg
      MPI_Startall(num_of_r_reqs, mympi->pair_r_reqs[ipair_mpi][istage_mpi]);
      MPI_Startall(num_of_r_reqs, mympi->pair_rr_reqs[ipair_mpi][istage_mpi]);
 
      MPI_Startall(gd->nblock_crecv, mympi->pair_r_reqs_car);
      MPI_Startall(gd->nblock_precv, mympi->pair_r_reqs_polar);

      // rk start
      if (istage==0)
      {
        float coef_a = rk_a[istage] * dt;
        float coef_b = rk_b[istage] * dt;

        // wavefield
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_tmp[iptr] = w_pre[iptr] + coef_a * w_rhs[iptr];
        }

        // apply Qs
        //if (md->visco_type == CONST_VISCO_GRAVES) {
        //  sv_curv_graves_Qs(w_tmp, wave->ncmp, gd, md);
        //}

        // pack and isend
        blk_macdrp_pack_mesg(w_tmp, sbuff, ssbuff, wav->ncmp, gdinfo,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]));
        blk_macdrp_pack_mesg_interp(w_tmp, sbuff_polar, sbuff_car, wav->ncmp, gd, gdinfo, mympi);

        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi]);

        MPI_Startall(gd->nblock_psend, mympi->pair_s_reqs_polar);
        MPI_Startall(gd->nblock_csend, mympi->pair_s_reqs_car);
        
        // pml_tmp
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              if (bdry->is_sides_pml[idim][iside]==1) {
                bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
                for (size_t iptr=0; iptr < auxvar->siz_ilevel; iptr++) {
                  auxvar->tmp[iptr] = auxvar->pre[iptr] + coef_a * auxvar->rhs[iptr];
                }
              }
            }
          }
        }

        // w_end
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_end[iptr] = w_pre[iptr] + coef_b * w_rhs[iptr];
        }
        // pml_end
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              if (bdry->is_sides_pml[idim][iside]==1) {
                bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
                for (size_t iptr=0; iptr < auxvar->siz_ilevel; iptr++) {
                  auxvar->end[iptr] = auxvar->pre[iptr] + coef_b * auxvar->rhs[iptr];
                }
              }
            }
          }
        }
      }
      else if (istage<num_rk_stages-1)
      {
        float coef_a = rk_a[istage] * dt;
        float coef_b = rk_b[istage] * dt;

        // wavefield
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_tmp[iptr] = w_pre[iptr] + coef_a * w_rhs[iptr];
        }

        // apply Qs
        //if (md->visco_type == CONST_VISCO_GRAVES) {
        //  sv_curv_graves_Qs(w_tmp, wave->ncmp, gd, md);
        //}
        
        // pack and isend
        blk_macdrp_pack_mesg(w_tmp, sbuff, ssbuff, wav->ncmp, gdinfo,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]));
        blk_macdrp_pack_mesg_interp(w_tmp, sbuff_polar, sbuff_car, wav->ncmp, gd, gdinfo, mympi);

        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi]);

        MPI_Startall(gd->nblock_psend, mympi->pair_s_reqs_polar);
        MPI_Startall(gd->nblock_csend, mympi->pair_s_reqs_car);

        // pml_tmp
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              if (bdry->is_sides_pml[idim][iside]==1) {
                bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
                for (size_t iptr=0; iptr < auxvar->siz_ilevel; iptr++) {
                  auxvar->tmp[iptr] = auxvar->pre[iptr] + coef_a * auxvar->rhs[iptr];
                }
              }
            }
          }
        }

        // w_end
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_end[iptr] += coef_b * w_rhs[iptr];
        }
        // pml_end
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              if (bdry->is_sides_pml[idim][iside]==1) {
                bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
                for (size_t iptr=0; iptr < auxvar->siz_ilevel; iptr++) {
                  auxvar->end[iptr] += coef_b * auxvar->rhs[iptr];
                }
              }
            }
          }
        }
      }
      else // last stage
      {
        float coef_b = rk_b[istage] * dt;

        // wavefield
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_end[iptr] += coef_b * w_rhs[iptr];
        }

        // apply Qs
        if (md->visco_type == CONST_VISCO_GRAVES_QS) {
          sv_curv_graves_Qs(w_end, wav->ncmp, dt, gdinfo, md);
        }
        
        // pack and isend
        blk_macdrp_pack_mesg(w_end, sbuff, ssbuff, wav->ncmp, gdinfo,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]));
        blk_macdrp_pack_mesg_interp(w_end, sbuff_polar, sbuff_car, wav->ncmp, gd, gdinfo, mympi);

        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi]);

        MPI_Startall(gd->nblock_psend, mympi->pair_s_reqs_polar);
        MPI_Startall(gd->nblock_csend, mympi->pair_s_reqs_car);

        // pml_end
        if(bdry->is_enable_pml == 1)
        {
          for (int idim=0; idim<CONST_NDIM; idim++) {
            for (int iside=0; iside<2; iside++) {
              if (bdry->is_sides_pml[idim][iside]==1) {
                bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
                for (size_t iptr=0; iptr < auxvar->siz_ilevel; iptr++) {
                  auxvar->end[iptr] += coef_b * auxvar->rhs[iptr];
                }
              }
            }
          }
        }
      }

      MPI_Waitall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_r_reqs, mympi->pair_r_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_r_reqs, mympi->pair_rr_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);

      MPI_Waitall(gd->nblock_psend, mympi->pair_s_reqs_polar, MPI_STATUS_IGNORE);
      MPI_Waitall(gd->nblock_precv, mympi->pair_r_reqs_polar, MPI_STATUS_IGNORE);
      MPI_Waitall(gd->nblock_csend, mympi->pair_s_reqs_car, MPI_STATUS_IGNORE);
      MPI_Waitall(gd->nblock_crecv, mympi->pair_r_reqs_car, MPI_STATUS_IGNORE);

      if (istage != num_rk_stages-1) {
        blk_macdrp_unpack_mesg(rbuff, rrbuff, w_tmp,  wav->ncmp, gdinfo,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         mympi->pair_siz_rbuff_x1[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_xx1[ipair_mpi][istage_mpi],
                         mympi->neighid);//unpack func need pair_siz to divide rbuff
     } else {
        blk_macdrp_unpack_mesg(rbuff, rrbuff, w_end,  wav->ncmp, gdinfo,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         mympi->pair_siz_rbuff_x1[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_xx1[ipair_mpi][istage_mpi],
                         mympi->neighid);
      }
      
      blk_macdrp_unpack_mesg_interp(rbuff_polar, rbuff_car, wav->ncmp, gd, gdinfo,wav, mympi);

    } // RK stages

    //--------------------------------------------
    // QC
    //--------------------------------------------

    if (qc_check_nan_num_of_step >0  && (it % qc_check_nan_num_of_step) == 0) {
      if (myid==0 && verbose>10) fprintf(stdout,"-> check value nan\n");
                    wav_check_value(w_end,wav,it);
     }

    //--------------------------------------------
    // apply ablexp
    //--------------------------------------------
    if (bdry->is_enable_ablexp == 1) {
       bdry_ablexp_apply(bdry, w_end, wav->ncmp, wav->siz_icmp);
    }

    //--------------------------------------------
    // save results
    //--------------------------------------------

    //-- recv by interp
    io_recv_keep(iorecv, w_end, it, wav->ncmp, wav->siz_icmp);

    //-- line values
    io_line_keep(ioline, w_end, it, wav->ncmp, wav->siz_icmp);

    // snapshot
    if (md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO) {
      io_snap_nc_put_ac(iosnap, &iosnap_nc, gd, md, wav, 
                     w_end, w_rhs, nt_total, it, t_end, 1,1,1);
    } else {
      io_snap_nc_put(iosnap, &iosnap_nc, gd, md, wav, 
                     w_end, w_rhs, nt_total, it, t_end, 1,1,1);
    }

    // set ghost region value =0
    wav_zero_edge(gdinfo, wav, w_rhs);

    // swap w_pre and w_end, avoid copying
    w_cur = w_pre; w_pre = w_end; w_end = w_cur;

    if(bdry->is_enable_pml == 1)
    {
      for (int idim=0; idim<CONST_NDIM; idim++) {
        for (int iside=0; iside<2; iside++) {
          bdrypml_auxvar_t *auxvar = &(bdry->auxvar[idim][iside]);
          auxvar->cur = auxvar->pre;
          auxvar->pre = auxvar->end;
          auxvar->end = auxvar->cur;
        }
      }
    }

  } // time loop

  // postproc

  // close nc
  io_snap_nc_close(&iosnap_nc);

  return 0;
}

